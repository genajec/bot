#!/usr/bin/env python
"""
Скрипт для запуска бота в режиме polling 
"""

import logging
import telebot
from bot import FaceShapeBot
from config import TELEGRAM_API_TOKEN

# Настраиваем логирование
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    """
    Запуск бота в режиме polling
    """
    logger.info("Запуск бота в режиме polling")
    
    # Удаляем старый webhook перед запуском polling
    try:
        bot = telebot.TeleBot(TELEGRAM_API_TOKEN)
        bot.delete_webhook()
        logger.info("Webhook удален")
    except Exception as e:
        logger.error(f"Ошибка при удалении webhook: {e}")
    
    # Создаем экземпляр бота
    face_shape_bot = FaceShapeBot(use_webhook=False)
    
    # Выводим информацию о запуске
    logger.info("Бот запущен. Нажмите Ctrl+C для остановки")
    
    try:
        # Запускаем бота в режиме polling
        face_shape_bot.run()
    except Exception as e:
        logger.error(f"Ошибка при запуске бота: {e}")
    except KeyboardInterrupt:
        logger.info("Бот остановлен по запросу пользователя")

if __name__ == "__main__":
    main()