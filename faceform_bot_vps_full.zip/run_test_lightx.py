import os
import sys
import logging
import time
from lightx_client import LightXClient

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_lightx_api_direct():
    """
    Directly test LightX API functionality without using face_analyzer
    """
    try:
        # Initialize LightX client
        lightx_client = LightXClient()
        
        # Test getting upload URL
        logger.info("Testing image upload URL API...")
        upload_url, image_url = lightx_client.get_image_upload_url(1024, content_type="image/jpeg")
        
        if not upload_url or not image_url:
            logger.error("Failed to get upload URL")
            return False
        
        logger.info(f"Successfully obtained upload URL: {image_url}")
        
        # Test hairstyle prompt generation for a face shape
        logger.info("Testing hairstyle prompt generation...")
        face_shape = "ROUND"
        hairstyle_prompts = lightx_client.get_hairstyle_prompts_by_face_shape(face_shape)
        
        if not hairstyle_prompts:
            logger.error("Failed to get hairstyle prompts")
            return False
        
        logger.info(f"Successfully generated {len(hairstyle_prompts)} hairstyle prompts for {face_shape}")
        for i, prompt in enumerate(hairstyle_prompts):
            logger.info(f"Prompt {i+1}: {prompt.get('name')} - {prompt.get('prompt')}")
        
        return True
        
    except Exception as e:
        logger.error(f"Error testing LightX API: {e}")
        return False

if __name__ == "__main__":
    logger.info("=== Direct testing of LightX API ===")
    result = test_lightx_api_direct()
    
    if result:
        logger.info("✅ Tests passed successfully!")
        sys.exit(0)
    else:
        logger.error("❌ Tests failed!")
        sys.exit(1)