import os
import requests
import time
from pathlib import Path
from dotenv import load_dotenv

# Загружаем переменные окружения из .env файла, если он существует
env_path = Path('.') / '.env'
if env_path.exists():
    load_dotenv(dotenv_path=env_path)

# Telegram Bot API Token
# Установите переменную окружения TELEGRAM_API_TOKEN на Render.com
TELEGRAM_API_TOKEN = os.environ.get("TELEGRAM_API_TOKEN", "7586536261:AAFeFBLykpizjms9H9Mnboym3x_-N4UQ-uc")

# LightX API Key
LIGHTX_API_KEY = os.environ.get("LIGHTX_API_KEY", "5bf93ecbebf740c592ed2ad0d0c992f3_ca6160cc72394be7b9ebc13f66a53925_andoraitools")

# Crypto Bot API Token
CRYPTO_BOT_TOKEN = os.environ.get("CRYPTO_BOT_TOKEN")

# Временно остановим webhook, чтобы избежать конфликта с другими экземплярами
try:
    print("Удаляем webhook для предотвращения конфликтов...")
    response = requests.get(f"https://api.telegram.org/bot{TELEGRAM_API_TOKEN}/deleteWebhook")
    print(f"Ответ API: {response.status_code} - {response.text}")
    time.sleep(2)  # Даем время API для обновления
except Exception as e:
    print(f"Ошибка при удалении webhook: {e}")

# Сообщения о премиум-функциях
PREMIUM_MESSAGES = {
    "premium_features": "🔒 *Премиум-функции FaceForm Bot* 🔒\n\n"
                       "Виртуальная примерка причесок и создание изображений с помощью LightX AI доступны за кредиты.\n\n"
                       "💡 1 кредит = 1 виртуальная примерка прически\n"
                       "💰 Стоимость кредитов (банковская карта):\n"
                       "• 5 кредитов - 0.40$\n"
                       "• 10 кредитов - 0.9$\n"
                       "• 20 кредитов - 1.7$\n\n"
                       "💰 Стоимость кредитов (криптовалюта):\n"
                       "• 10 кредитов - 1.0$\n"
                       "• 20 кредитов - 1.7$\n"
                       "• 40 кредитов - 3.0$\n\n"
                       "Для просмотра баланса кредитов используйте команду /credits\n"
                       "Для покупки кредитов используйте команду /buy",
    "not_enough_credits": "⚠️ *У вас недостаточно кредитов* ⚠️\n\n"
                         "Для использования этой функции требуется 1 кредит.\n"
                         "Ваш текущий баланс: {credits} кредитов.\n\n"
                         "Используйте команду /buy для покупки кредитов.",
    "credits_info": "💰 *Ваш баланс кредитов* 💰\n\n"
                   "У вас {credits} кредитов\n\n"
                   "Как использовать кредиты:\n"
                   "• 1 кредит = 1 виртуальная примерка прически\n\n"
                   "Для покупки дополнительных кредитов используйте команду /buy",
    "buy_credits": "🛒 *Покупка кредитов* 🛒\n\n"
                  "Выберите пакет кредитов:\n\n"
                  "1️⃣ *Базовый*: 5 кредитов - 0.40$\n"
                  "2️⃣ *Стандарт*: 10 кредитов - 0.9$\n"
                  "3️⃣ *Премиум*: 20 кредитов - 1.7$\n\n"
                  "Для покупки ответьте номер пакета (1, 2 или 3)",
    "buy_credits_crypto": "🛒 *Покупка кредитов (криптовалюта)* 🛒\n\n"
                  "Выберите пакет кредитов:\n\n"
                  "1️⃣ *Базовый*: 10 кредитов - 1.0$\n"
                  "2️⃣ *Стандарт*: 20 кредитов - 1.7$\n"
                  "3️⃣ *Премиум*: 40 кредитов - 3.0$\n\n"
                  "Для покупки ответьте номер пакета (1, 2 или 3)",
    "choose_payment_method": "💳 *Выберите способ оплаты* 💳\n\n"
                  "1️⃣ *Криптовалюта* - оплата через Crypto Bot (USDT/TON)\n"
                  "2️⃣ *Банковская карта* - оплата через Stripe\n\n"
                  "Для выбора ответьте номер способа оплаты (1 или 2)",
    "payment_created_card": "💳 *Оплата банковской картой* 💳\n\n"
                      "Для завершения покупки {credits} кредитов нажмите на ссылку ниже:\n\n"
                      "Сумма к оплате: {amount}$\n\n"
                      "{payment_url}",
    "payment_created_card_test": "💳 *Оплата банковской картой (тестовый режим)* 💳\n\n"
                      "Для завершения покупки {credits} кредитов нажмите на ссылку ниже:\n\n"
                      "Сумма к оплате: {amount}$\n\n"
                      "⚠️ *Тестовый режим активен* ⚠️\n"
                      "Используйте следующие тестовые карты:\n"
                      "- 4242 4242 4242 4242 (Visa, успешная оплата)\n"
                      "- 4000 0000 0000 0002 (Visa, отклоненная оплата)\n\n"
                      "Любой срок действия в будущем, любой CVC и почтовый код.\n\n"
                      "{payment_url}",
    "payment_created": "💳 *Оплата создана* 💳\n\n"
                      "Для завершения покупки {credits} кредитов перейдите по ссылке ниже и выберите способ оплаты криптовалютой.\n\n"
                      "Сумма к оплате: {amount}$\n"
                      "После оплаты нажмите кнопку 'Вернуться в бот'.\n\n"
                      "{payment_url}",
    "payment_success": "✅ *Платеж успешно завершен!* ✅\n\n"
                      "На ваш баланс зачислено {credits} кредитов.\n"
                      "Ваш текущий баланс: {total_credits} кредитов.\n\n"
                      "Спасибо за покупку! Теперь вы можете воспользоваться премиум-функциями бота.",
    "payment_error": "❌ *Ошибка платежа* ❌\n\n"
                    "Произошла ошибка при обработке платежа. Пожалуйста, попробуйте позже или выберите другой способ оплаты.\n\n"
                    "Если проблема повторяется, свяжитесь с поддержкой @FaceFormSupport.",
    "payment_already_processed": "✅ *Платеж уже обработан* ✅\n\n"
                    "Этот платеж уже был обработан ранее.\n"
                    "Ваш баланс: {total_credits} кредитов.\n\n"
                    "Спасибо за покупку! Вы можете воспользоваться премиум-функциями бота."
}

# Face shape criteria - proportions and ratios
FACE_SHAPE_CRITERIA = {
    "OVAL": {
        "description": "Овальное лицо",
        "ratio_width_to_length": (0.65, 0.75),  # Width to length ratio range
        "forehead_to_jawline_ratio": (0.9, 1.1),  # Forehead width to jawline width ratio
        "cheekbone_to_jawline_ratio": (1.1, 1.3),  # Cheekbone width to jawline width ratio
    },
    "ROUND": {
        "description": "Круглое лицо",
        "ratio_width_to_length": (0.8, 1.0),
        "forehead_to_jawline_ratio": (0.9, 1.1),
        "cheekbone_to_jawline_ratio": (1.0, 1.2),
    },
    "SQUARE": {
        "description": "Квадратное лицо",
        "ratio_width_to_length": (0.75, 0.85),
        "forehead_to_jawline_ratio": (0.95, 1.05),
        "cheekbone_to_jawline_ratio": (1.0, 1.1),
    },
    "HEART": {
        "description": "Сердцевидное лицо",
        "ratio_width_to_length": (0.7, 0.8),
        "forehead_to_jawline_ratio": (1.1, 1.5),
        "cheekbone_to_jawline_ratio": (1.05, 1.15),
    },
    "OBLONG": {
        "description": "Продолговатое лицо",
        "ratio_width_to_length": (0.55, 0.65),
        "forehead_to_jawline_ratio": (0.9, 1.1),
        "cheekbone_to_jawline_ratio": (1.0, 1.2),
    },
    "DIAMOND": {
        "description": "Ромбовидное лицо",
        "ratio_width_to_length": (0.7, 0.8),
        "forehead_to_jawline_ratio": (0.85, 0.95),
        "cheekbone_to_jawline_ratio": (1.15, 1.3),
    },
}

# Hairstyle recommendations based on face shape
HAIRSTYLE_RECOMMENDATIONS = {
    "OVAL": [
        "Вам подходит практически любая стрижка! Это идеальная форма лица.",
        "Рекомендации для овального лица:",
        "- Классическое каре любой длины",
        "- Удлиненный боб",
        "- Волны любой длины",
        "- Прямые волосы с челкой или без",
        "- Короткие пикси",
        "- Многослойные стрижки"
    ],
    "ROUND": [
        "Стрижки для круглого лица:",
        "- Асимметричные стрижки для визуального удлинения лица",
        "- Многослойные стрижки средней длины",
        "- Удлиненное каре с пробором посередине",
        "- Пикси с объемом на макушке",
        "- Избегайте коротких стрижек, которые заканчиваются на уровне подбородка",
        "- Длинная косая челка"
    ],
    "SQUARE": [
        "Стрижки для квадратного лица:",
        "- Мягкие волны и локоны для смягчения линий лица",
        "- Многослойные стрижки с объемом у макушки",
        "- Длинная боковая челка",
        "- Стрижки средней длины с рваными концами",
        "- Избегайте прямых волос, подчеркивающих угловатость",
        "- Асимметричный боб"
    ],
    "HEART": [
        "Стрижки для сердцевидного лица:",
        "- Средняя длина с многослойными прядями",
        "- Длинное каре с боковым пробором",
        "- Длинная челка на бок",
        "- Стрижки, добавляющие объем на уровне подбородка",
        "- Волнистые волосы средней длины",
        "- Стрижки, скрывающие широкий лоб"
    ],
    "OBLONG": [
        "Стрижки для продолговатого лица:",
        "- Объемные стрижки по бокам",
        "- Волнистые волосы средней длины",
        "- Челка прямая или рваная",
        "- Избегайте слишком длинных прямых волос",
        "- Многослойные стрижки с объемом у скул",
        "- Боб до плеч или короче"
    ],
    "DIAMOND": [
        "Стрижки для ромбовидного лица:",
        "- Глубокие боковые проборы",
        "- Челка для смягчения лба",
        "- Средняя длина с объемом по бокам",
        "- Многослойные стрижки",
        "- Стрижки, добавляющие объем на уровне подбородка",
        "- Длинные волнистые волосы"
    ],
}

# Определения стилей причесок для LightX API с улучшенными промптами и параметрами настройки
# Каждый стиль теперь содержит базовый стиль и возможные параметры настройки (цвет, длина, текстура)
LIGHTX_HAIRSTYLE_STYLES = {
    "OVAL": [
        {
            "name": "Wolf Cat", 
            "style": "trendy wolf cut with cat-like layering, medium length, textured layers, face-framing, perfect for oval face, shaggy style, natural looking, preserve exact same facial features, keep original face structure, do not change background, maintain original lighting",
            "colors": [
                {"name": "Каштановый", "value": "chestnut brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Пепельный блонд", "value": "ash blonde"},
                {"name": "Рыжий", "value": "ginger red"}
            ],
        },
        {
            "name": "Crew Cut (M)", 
            "style": "men's classic crew cut, short sides, slightly longer top, clean military style, perfect for oval face, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Светлый", "value": "light brown"},
                {"name": "Платиновый", "value": "platinum blonde"}
            ],
            "lengths": [
                {"name": "Короткий", "value": "short crew cut"},
                {"name": "Средний", "value": "medium crew cut"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Классические", "value": "classic"}
            ]
        },
        {
            "name": "Квифф (M)", 
            "style": "men's quiff haircut with styled front, height on top, shorter sides, neat classic style for oval face, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Русый", "value": "medium blonde"},
                {"name": "Пепельный", "value": "ash brown"}
            ],
            "lengths": [
                {"name": "Короткий", "value": "short quiff"},
                {"name": "Средний", "value": "medium quiff"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Объемные", "value": "voluminous"}
            ]
        },
        {
            "name": "Британка (M)", 
            "style": "men's British style haircut, tapered sides, textured crop on top with forward styling, neat look for oval face, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Блонд", "value": "blonde"},
                {"name": "Каштановый", "value": "chestnut"}
            ],
            "lengths": [
                {"name": "Классическая", "value": "classic length"},
                {"name": "Современная", "value": "modern version"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Объемные", "value": "voluminous"}
            ]
        },
        {
            "name": "Wolf Cut (Ж)", 
            "style": "trendy wolf cut hairstyle with shaggy layers, wispy bangs, textured ends, casual messy look, perfect for oval face shape, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Светло-русый", "value": "light blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut brown"}
            ],
            "lengths": [
                {"name": "Средняя длина", "value": "medium length"},
                {"name": "Длинная", "value": "long"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Текстурные", "value": "textured"}
            ]
        },
        {
            "name": "Каре до подбородка (Ж)", 
            "style": "classic chin-length bob haircut, clean lines, emphasizing perfect oval face shape proportions, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Блонд", "value": "blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut brown"}
            ],
            "lengths": [
                {"name": "Классическое", "value": "classic bob length"},
                {"name": "Удлиненное", "value": "long bob"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Слегка волнистые", "value": "slightly wavy"},
                {"name": "Гладкие", "value": "sleek"}
            ]
        },
        {
            "name": "Каскад средней длины (Ж)", 
            "style": "medium length layered cascade haircut, soft textured ends, perfect movement, flattering oval face shape, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Медовый блонд", "value": "honey blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut brown"}
            ],
            "lengths": [
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "Ниже плеч", "value": "below shoulder"}
            ],
            "textures": [
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Легкие кудри", "value": "soft curls"},
                {"name": "Многослойные", "value": "layered"}
            ]
        },
        {
            "name": "Пикси (Ж)", 
            "style": "short pixie haircut, elegant minimal style, emphasizing cheekbones and eyes, perfect for oval face, feminine look, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Платиновый блонд", "value": "platinum blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Пепельный", "value": "ash brown"}
            ],
            "lengths": [
                {"name": "Ультра-короткий", "value": "ultra short pixie"},
                {"name": "Классический", "value": "classic pixie length"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Объемные", "value": "voluminous"}
            ]
        },
        {
            "name": "Прямые длинные волосы (Ж)", 
            "style": "long straight hair with center part, sleek polished finish, showcasing perfect oval face proportions, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Блонд", "value": "blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Рыжий", "value": "auburn"}
            ],
            "lengths": [
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "До лопаток", "value": "mid-back length"},
                {"name": "Очень длинные", "value": "very long"}
            ],
            "textures": [
                {"name": "Идеально прямые", "value": "perfectly straight"},
                {"name": "Гладкие", "value": "sleek and shiny"},
                {"name": "С легким объемом", "value": "with slight volume"}
            ]
        },
        {
            "name": "Классический боб", 
            "style": "sleek classic bob haircut, precise shoulder length cut, straight glossy hair, clean lines, elegant style, perfect for oval face, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Светлый", "value": "blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut brown"}
            ],
            "lengths": [
                {"name": "Короткий боб", "value": "short bob"},
                {"name": "Удлиненный боб", "value": "long bob"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Волнистые", "value": "slightly wavy"},
                {"name": "Гладкие", "value": "sleek"}
            ]
        },
        {
            "name": "Длинные прямые волосы", 
            "style": "long straight hair with face-framing layers, middle part, silky smooth texture, polished look, enhancing oval face shape, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Блонд", "value": "blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Рыжий", "value": "auburn"}
            ],
            "lengths": [
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "До середины спины", "value": "mid-back length"},
                {"name": "Очень длинные", "value": "very long"}
            ],
            "textures": [
                {"name": "Идеально прямые", "value": "perfectly straight"},
                {"name": "Слегка волнистые", "value": "slightly wavy"},
                {"name": "Гладкие", "value": "sleek and shiny"}
            ]
        },
        {
            "name": "Многослойные волны", 
            "style": "medium length wavy hair with soft layers, natural-looking waves, textured finish, bouncy movement, complementing oval faces, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Светло-русый", "value": "light blonde"},
                {"name": "Темный блонд", "value": "dark blonde"},
                {"name": "Омбре", "value": "ombre with dark roots"}
            ],
            "lengths": [
                {"name": "Короткие", "value": "short layered"},
                {"name": "Средние", "value": "medium length"},
                {"name": "Длинные", "value": "long"}
            ],
            "textures": [
                {"name": "Легкие волны", "value": "loose waves"},
                {"name": "Выраженные кудри", "value": "defined curls"},
                {"name": "Пляжные волны", "value": "beach waves"}
            ]
        }
    ],
    "ROUND": [
        {
            "name": "Undercut с объёмом сверху (M)", 
            "style": "men's undercut haircut with voluminous top, high fade sides, vertical volume, elongating round face, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Светлый", "value": "light brown"},
                {"name": "Платиновый", "value": "platinum blonde"}
            ],
            "lengths": [
                {"name": "Короткий", "value": "short crop top"},
                {"name": "Средний", "value": "medium length top"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Взлохмаченные", "value": "messy textured"}
            ]
        },
        {
            "name": "Помпадур (M)", 
            "style": "men's pompadour hairstyle with high volume on top, short sides, slicked back front, vertically elongating round face, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Светлый", "value": "light brown"},
                {"name": "Медный", "value": "copper brown"}
            ],
            "lengths": [
                {"name": "Классический", "value": "classic pompadour"},
                {"name": "Современный", "value": "modern pompadour"}
            ],
            "textures": [
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Текстурные", "value": "textured"},
                {"name": "Матовые", "value": "matte finish"}
            ]
        },
        {
            "name": "Канадка с боковым пробором (M)", 
            "style": "men's Canadian haircut (taper) with side part, longer top, tapered sides, creating vertical lines on round face, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Русый", "value": "medium blonde"},
                {"name": "Каштановый", "value": "chestnut"}
            ],
            "lengths": [
                {"name": "Классическая", "value": "classic length"},
                {"name": "Длиннее сверху", "value": "longer on top"}
            ],
            "textures": [
                {"name": "Гладкие", "value": "sleek combed"},
                {"name": "Текстурные", "value": "textured"},
                {"name": "Небрежные", "value": "slightly messy"}
            ]
        },
        {
            "name": "Квифф (M)", 
            "style": "men's quiff haircut with volume on top, short sides, lifted front section, creating height to elongate round face, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Блонд", "value": "blonde"},
                {"name": "Пепельный", "value": "ash brown"}
            ],
            "lengths": [
                {"name": "Короткий", "value": "short quiff"},
                {"name": "Средний", "value": "medium quiff"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Взлохмаченные", "value": "messy textured"}
            ]
        },
        {
            "name": "Лонг боб с косым пробором (Ж)", 
            "style": "long asymmetric bob with deep side part, straight sleek finish, elongating round face, creating slimming effect, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Пепельный блонд", "value": "ash blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut brown"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Слегка волнистые", "value": "slightly wavy"},
                {"name": "Гладкие", "value": "sleek and polished"}
            ]
        },
        {
            "name": "Пикси с объёмом сверху (Ж)", 
            "style": "pixie cut with volume on top, short sides, vertical height, elongating round face shape, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Платиновый блонд", "value": "platinum blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Рыжий", "value": "ginger red"}
            ],
            "lengths": [
                {"name": "Короткий пикси", "value": "short pixie"},
                {"name": "Удлиненный пикси", "value": "long pixie"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Взъерошенные", "value": "tousled"}
            ]
        },
        {
            "name": "Каскад с удлинёнными прядями (Ж)", 
            "style": "layered cascade haircut with long face-framing strands, vertical lines, making round face appear more oval, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Карамельный", "value": "caramel blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Омбре", "value": "ombre"}
            ],
            "lengths": [
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "До лопаток", "value": "mid-back length"},
                {"name": "Длинные", "value": "long"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Многослойные", "value": "heavily layered"}
            ]
        },
        {
            "name": "Асимметричное каре (Ж)", 
            "style": "asymmetrical bob haircut, one side longer than other, creating diagonal lines that distract from round face shape, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Блонд", "value": "blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Фиолетовый", "value": "purple tint"}
            ],
            "lengths": [
                {"name": "Короткое", "value": "short bob"},
                {"name": "Классическое", "value": "classic bob"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Текстурные", "value": "textured"},
                {"name": "Гладкие", "value": "sleek"}
            ]
        },
        {
            "name": "Удлинённая челка набок (Ж)", 
            "style": "medium length haircut with long side-swept bangs, visually dividing round face, adding angles, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Медовый блонд", "value": "honey blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut brown"}
            ],
            "lengths": [
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "Длинные", "value": "long"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Гладкие", "value": "sleek"}
            ]
        },
        {
            "name": "Удлиненное каре с асимметрией", 
            "style": "long asymmetric bob with dramatic side part, straight sleek finish, elongating round face, creating slimming effect, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Пепельный блонд", "value": "ash blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Балаяж", "value": "balayage highlights"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Слегка волнистые", "value": "slightly wavy"},
                {"name": "Гладкие", "value": "sleek and polished"}
            ]
        },
        {
            "name": "Пикси с длинной челкой", 
            "style": "short pixie cut with long side-swept bangs, textured top, close sides, creating angular structure for round face shape, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Платиновый блонд", "value": "platinum blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Светло-русый", "value": "light brown"}
            ],
            "lengths": [
                {"name": "Ультра-короткий", "value": "ultra short"},
                {"name": "Классический пикси", "value": "classic pixie length"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "highly textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Растрепанные", "value": "tousled"}
            ]
        },
        {
            "name": "Длинные слои с пробором", 
            "style": "long layered hair with deep side part, face-framing layers starting at chin, vertical lines slimming round face, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Русый", "value": "honey blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Рыжий", "value": "auburn"}
            ],
            "lengths": [
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "До середины спины", "value": "mid-back length"},
                {"name": "Очень длинные", "value": "very long"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Крупные волны", "value": "loose waves"},
                {"name": "Легкие кудри", "value": "soft curls"}
            ]
        },
        {
            "name": "Высокий хвост с начесом", 
            "style": "high ponytail with volume at crown, sleek sides, face-framing tendrils, elongating round face shape, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Светлый", "value": "blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut brown"}
            ],
            "lengths": [
                {"name": "Короткий", "value": "short ponytail"},
                {"name": "Средний", "value": "medium length ponytail"},
                {"name": "Длинный", "value": "long ponytail"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Кудрявые", "value": "curly"}
            ]
        }
    ],
    "SQUARE": [
        {
            "name": "Текстурированная стрижка (M)", 
            "style": "men's textured crop haircut, tousled top, soft fringe, softening strong jawline of square face, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Русый", "value": "medium blonde"},
                {"name": "Платиновый", "value": "platinum blonde"}
            ],
            "lengths": [
                {"name": "Короткая", "value": "short textured crop"},
                {"name": "Средняя", "value": "medium textured crop"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "heavily textured"},
                {"name": "Взъерошенные", "value": "messy textured"},
                {"name": "Матовые", "value": "matte finish"}
            ]
        },
        {
            "name": "Цезарь (M)", 
            "style": "men's Caesar cut, short horizontal fringe, textured top, short sides, softening square jawline, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Светло-русый", "value": "light brown"},
                {"name": "Каштановый", "value": "chestnut"}
            ],
            "lengths": [
                {"name": "Классический", "value": "classic Caesar"},
                {"name": "Современный", "value": "modern Caesar"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Взъерошенные", "value": "slightly messy"}
            ]
        },
        {
            "name": "Buzz Cut (M)", 
            "style": "men's buzz cut, very short all around, emphasizing strong jawline and masculine features of square face, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Блонд", "value": "blonde"},
                {"name": "Пепельный", "value": "ash brown"}
            ],
            "lengths": [
                {"name": "Очень короткий", "value": "very short buzz"},
                {"name": "Короткий", "value": "short buzz"}
            ],
            "textures": [
                {"name": "Единая длина", "value": "uniform length"},
                {"name": "С переходом", "value": "with fade"}
            ]
        },
        {
            "name": "Wolf Cut", 
            "style": "modern wolf cut hairstyle with shaggy layers, textured ends, softening jawline, perfect for square face shape, casual messy look, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Светло-русый", "value": "light blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut brown"}
            ],
            "lengths": [
                {"name": "Средняя длина", "value": "medium length"},
                {"name": "Длинная", "value": "long"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Текстурные", "value": "textured"}
            ]
        },
        {
            "name": "Мягкий каскад с волнами (Ж)", 
            "style": "soft layered cascade with gentle waves, face-framing layers, softening strong jawline of square face, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Карамельный", "value": "caramel blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Медный", "value": "copper"}
            ],
            "lengths": [
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "Ниже плеч", "value": "below shoulder"}
            ],
            "textures": [
                {"name": "Мягкие волны", "value": "soft waves"},
                {"name": "Легкие кудри", "value": "loose curls"},
                {"name": "Текстурные", "value": "textured"}
            ]
        },
        {
            "name": "Асимметричное каре (Ж)", 
            "style": "asymmetrical bob haircut, dramatic geometric lines breaking up squareness of face, modern edgy look, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Платиновый блонд", "value": "platinum blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Фиолетовый оттенок", "value": "with purple tint"}
            ],
            "lengths": [
                {"name": "Короткое", "value": "short asymmetrical"},
                {"name": "Удлиненное", "value": "long asymmetrical"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Текстурные", "value": "textured"},
                {"name": "Гладкие", "value": "sleek"}
            ]
        },
        {
            "name": "Лонг боб с волнами (Ж)", 
            "style": "long wavy bob haircut, chin to shoulder length, soft messy waves, softening square jawline, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Пепельный блонд", "value": "ash blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Медовый", "value": "honey blonde"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"}
            ],
            "textures": [
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Пляжные волны", "value": "beach waves"},
                {"name": "Текстурные", "value": "textured"}
            ]
        },
        {
            "name": "Градуированный боб (Ж)", 
            "style": "graduated bob haircut with angled layers, precise geometric cut, softening square face angles, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Платиновый блонд", "value": "platinum blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Карамельный", "value": "caramel blonde"}
            ],
            "lengths": [
                {"name": "Короткий", "value": "short graduated bob"},
                {"name": "Удлиненный", "value": "long graduated bob"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Слегка текстурные", "value": "slightly textured"},
                {"name": "Гладкие", "value": "sleek"}
            ]
        },
        {
            "name": "Мягкие волны с боковым пробором", 
            "style": "soft waves with deep side part, face-framing layers, medium length, softening strong jawline of square face, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Русый", "value": "medium blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Медный", "value": "copper"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "Ниже плеч", "value": "below shoulder"}
            ],
            "textures": [
                {"name": "Мягкие волны", "value": "soft waves"},
                {"name": "Легкие кудри", "value": "loose curls"},
                {"name": "Текстурные волны", "value": "textured waves"}
            ]
        },
        {
            "name": "Длинное каре с градуировкой", 
            "style": "long graduated bob with soft layers around face, side-swept bangs, softening angles of square face shape, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Светло-русый", "value": "light blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Шоколадный", "value": "chocolate brown"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Слегка волнистые", "value": "slightly wavy"},
                {"name": "Структурированные", "value": "textured"}
            ]
        },
        {
            "name": "Длинные волосы с кудрями", 
            "style": "long curly hair with layers starting at cheekbones, volume on sides, balancing square jawline with soft curves, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Темный блонд", "value": "dark blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut brown"}
            ],
            "lengths": [
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "До лопаток", "value": "mid-back length"},
                {"name": "Очень длинные", "value": "very long"}
            ],
            "textures": [
                {"name": "Мягкие кудри", "value": "soft curls"},
                {"name": "Спиральные кудри", "value": "spiral curls"},
                {"name": "Объемные волны", "value": "voluminous waves"}
            ]
        },
        {
            "name": "Растрепанные волны", 
            "style": "tousled beach waves with center part, textured ends, movement throughout, softening square face structure, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Золотистый блонд", "value": "golden blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Балаяж", "value": "balayage highlights"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "Ниже плеч", "value": "below shoulder"}
            ],
            "textures": [
                {"name": "Небрежные волны", "value": "messy waves"},
                {"name": "Пляжные волны", "value": "beach waves"},
                {"name": "Естественная текстура", "value": "natural texture"}
            ]
        }
    ],
    "HEART": [
        {
            "name": "Текстурированный квифф (M)", 
            "style": "men's textured quiff haircut, volume on top, tapered sides, balanced style for heart face shape, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Русый", "value": "medium blonde"},
                {"name": "Пепельный", "value": "ash brown"}
            ],
            "lengths": [
                {"name": "Короткий", "value": "short quiff"},
                {"name": "Средний", "value": "medium quiff"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Взъерошенные", "value": "messy textured"}
            ]
        },
        {
            "name": "Undercut с боковым пробором (M)", 
            "style": "men's undercut with side part, longer top, very short sides, balancing heart-shaped face features, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Светлый", "value": "light brown"},
                {"name": "Платиновый", "value": "platinum blonde"}
            ],
            "lengths": [
                {"name": "Короткий", "value": "short top undercut"},
                {"name": "Средний", "value": "medium top undercut"}
            ],
            "textures": [
                {"name": "Гладкие", "value": "sleek combed"},
                {"name": "Текстурные", "value": "textured"},
                {"name": "Объемные", "value": "voluminous"}
            ]
        },
        {
            "name": "Чёлка набок (M)", 
            "style": "men's haircut with side swept fringe, covering forehead partially, adding balance to heart-shaped face, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Русый", "value": "medium blonde"},
                {"name": "Каштановый", "value": "chestnut"}
            ],
            "lengths": [
                {"name": "Средняя", "value": "medium length"},
                {"name": "Длиннее сверху", "value": "longer on top"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Текстурные", "value": "textured"},
                {"name": "Волнистые", "value": "wavy"}
            ]
        },
        {
            "name": "Wolf Cut",
            "style": "trendy wolf cut hairstyle with layered bangs, shaggy texture, volume at chin level, balancing heart-shaped face proportions, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Светло-русый", "value": "light blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut brown"}
            ],
            "lengths": [
                {"name": "Средняя длина", "value": "medium length"},
                {"name": "Длинная", "value": "long"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Текстурные", "value": "textured"}
            ]
        },
        {
            "name": "Боб с густой челкой (Ж)", 
            "style": "bob haircut with heavy straight-across bangs, chin-length cut, volume at jawline, balancing wide forehead of heart face, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Платиновый блонд", "value": "platinum blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Темно-рыжий", "value": "dark auburn"}
            ],
            "lengths": [
                {"name": "Короткий боб", "value": "short bob"},
                {"name": "Классический боб", "value": "classic bob"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Слегка волнистые", "value": "slightly wavy"},
                {"name": "Гладкие", "value": "sleek"}
            ]
        },
        {
            "name": "Чёлка-шторка (Ж)", 
            "style": "curtain bangs haircut, parted in middle, framing face, softening wide forehead of heart-shaped face, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Медовый блонд", "value": "honey blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Карамельный", "value": "caramel blonde"}
            ],
            "lengths": [
                {"name": "Средняя длина", "value": "medium length"},
                {"name": "Длинная", "value": "long"}
            ],
            "textures": [
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Прямые", "value": "straight"},
                {"name": "Текстурные", "value": "textured"}
            ]
        },
        {
            "name": "Каскад с объемом у подбородка (Ж)", 
            "style": "layered cascade haircut with volume at chin level, balancing narrow jawline of heart face, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Русый", "value": "honey blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Шоколадный", "value": "chocolate brown"}
            ],
            "lengths": [
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "Чуть ниже плеч", "value": "just below shoulders"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Легкие волны", "value": "soft waves"},
                {"name": "Многослойные", "value": "heavily layered"}
            ]
        },
        {
            "name": "Пикси с длинной чёлкой (Ж)", 
            "style": "pixie cut with long side-swept bangs, covering forehead, adding softness to heart-shaped face, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Платиновый блонд", "value": "platinum blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Пепельный", "value": "ash brown"}
            ],
            "lengths": [
                {"name": "Короткий пикси", "value": "short pixie"},
                {"name": "Удлиненный пикси", "value": "long pixie"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Объемные", "value": "voluminous"}
            ]
        },
        {
            "name": "Боб с густой челкой", 
            "style": "bob haircut with heavy straight-across bangs, chin-length cut, volume at jawline, balancing wide forehead of heart face, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Платиновый блонд", "value": "platinum blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Темно-рыжий", "value": "dark auburn"}
            ],
            "lengths": [
                {"name": "Короткий боб", "value": "short bob"},
                {"name": "Классический боб", "value": "classic bob"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Слегка волнистые", "value": "slightly wavy"},
                {"name": "Гладкие", "value": "sleek"}
            ]
        },
        {
            "name": "Средняя длина с многослойными прядями", 
            "style": "medium length hair with graduated layers around face, starting at chin, adding width to narrow jawline, perfect for heart shape, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Русый", "value": "honey blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Шоколадный", "value": "chocolate brown"}
            ],
            "lengths": [
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "Чуть ниже плеч", "value": "just below shoulders"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Легкие волны", "value": "soft waves"},
                {"name": "Структурированные", "value": "textured"}
            ]
        },
        {
            "name": "Длинные волосы с боковым пробором", 
            "style": "long hair with deep side part, face-framing layers, volume at jaw level, balancing heart-shaped face proportions, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Светло-русый", "value": "light blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut brown"}
            ],
            "lengths": [
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "До лопаток", "value": "mid-back length"},
                {"name": "Очень длинные", "value": "very long"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Гладкие", "value": "sleek"}
            ]
        },
        {
            "name": "Текстурный лоб с подкрученными концами", 
            "style": "textured lob (long bob) with flipped ends, side-swept bangs, jawline length, adding width to narrow chin, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Пепельный блонд", "value": "ash blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut brown"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"}
            ],
            "textures": [
                {"name": "Подкрученные кончики", "value": "flipped ends"},
                {"name": "Текстурные", "value": "textured"},
                {"name": "Взъерошенные", "value": "tousled"}
            ]
        }
    ],
    "OBLONG": [
        {
            "name": "Crew Cut с объемом сбоку (M)", 
            "style": "men's crew cut hairstyle with side volume, short top, width emphasis on sides to balance oblong face, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Светлый", "value": "light brown"},
                {"name": "Пепельный", "value": "ash brown"}
            ],
            "lengths": [
                {"name": "Короткий", "value": "short crew cut"},
                {"name": "Классический", "value": "classic crew cut"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Объемные", "value": "voluminous sides"}
            ]
        },
        {
            "name": "French Crop (M)", 
            "style": "men's French crop haircut with horizontal fringe, textured top, short sides, reducing height of oblong face, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Русый", "value": "medium blonde"},
                {"name": "Каштановый", "value": "chestnut"}
            ],
            "lengths": [
                {"name": "Короткий", "value": "short French crop"},
                {"name": "Стандартный", "value": "standard French crop"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Взъерошенные", "value": "messy textured"}
            ]
        },
        {
            "name": "Боб с прямой челкой (Ж)", 
            "style": "bob haircut with full straight-across bangs, chin-length, volume at sides, reducing vertical length of oblong face, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Блонд", "value": "blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut brown"}
            ],
            "lengths": [
                {"name": "Короткий боб", "value": "short bob"},
                {"name": "Классический боб", "value": "classic bob"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Слегка волнистые", "value": "slightly wavy"},
                {"name": "Гладкие", "value": "sleek"}
            ]
        },
        {
            "name": "Боб с объемными волнами (Ж)", 
            "style": "bob haircut with voluminous waves, shoulder-length, horizontal volume, visually shortening oblong face, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Медовый блонд", "value": "honey blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Рыжий", "value": "auburn"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"}
            ],
            "textures": [
                {"name": "Пышные волны", "value": "voluminous waves"},
                {"name": "Объемные кудри", "value": "bouncy curls"},
                {"name": "Текстурные", "value": "textured"}
            ]
        },
        {
            "name": "Пикси с текстурной челкой (Ж)", 
            "style": "pixie cut with textured bangs, short sides, extra volume on sides, shortening oblong face, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Платиновый блонд", "value": "platinum blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Пепельный", "value": "ash brown"}
            ],
            "lengths": [
                {"name": "Ультра-короткий", "value": "ultra short pixie"},
                {"name": "Классический пикси", "value": "classic pixie length"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "highly textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Взъерошенные", "value": "tousled"}
            ]
        },
        {
            "name": "Многослойный боб", 
            "style": "layered bob with full bangs, chin-length cut, volume at sides, reducing vertical length of oblong face, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Блонд", "value": "blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut brown"}
            ],
            "lengths": [
                {"name": "Короткий боб", "value": "short bob"},
                {"name": "Классический боб", "value": "classic bob"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Слегка волнистые", "value": "slightly wavy"},
                {"name": "Текстурные", "value": "textured"}
            ]
        },
        {
            "name": "Короткий слоистый пикси", 
            "style": "short pixie with textured layers on top, full bangs, width at cheekbones, shortening oblong face shape, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Платиновый блонд", "value": "platinum blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Пепельный", "value": "ash brown"}
            ],
            "lengths": [
                {"name": "Ультра-короткий", "value": "ultra short"},
                {"name": "Классический пикси", "value": "classic pixie length"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "highly textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Растрепанные", "value": "tousled"}
            ]
        },
        {
            "name": "Кудрявые волосы средней длины", 
            "style": "shoulder-length curly hair with volume on sides, curtain bangs, adding horizontal width to narrow oblong face, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Медный", "value": "copper"},
                {"name": "Черный", "value": "black"},
                {"name": "Золотистый", "value": "golden brown"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"}
            ],
            "textures": [
                {"name": "Мягкие кудри", "value": "soft curls"},
                {"name": "Упругие кудри", "value": "springy curls"},
                {"name": "Спиральные локоны", "value": "spiral curls"}
            ]
        },
        {
            "name": "Пышная стрижка с горизонтальной челкой", 
            "style": "voluminous haircut with straight-across blunt bangs, side volume, medium length, breaking up length of oblong face, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Блонд", "value": "blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый", "value": "chestnut brown"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Объемные", "value": "voluminous"},
                {"name": "Многослойные", "value": "layered"}
            ]
        }
    ],
    "DIAMOND": [
        {
            "name": "Средняя длина с текстурой (M)", 
            "style": "men's medium length textured hairstyle, volume at temples, fuller sides, balancing diamond face proportions, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Русый", "value": "medium blonde"},
                {"name": "Каштановый", "value": "chestnut"}
            ],
            "lengths": [
                {"name": "Средняя", "value": "medium length"},
                {"name": "Чуть длиннее", "value": "slightly longer"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Объемные", "value": "voluminous"}
            ]
        },
        {
            "name": "Side Part с объемом (M)", 
            "style": "men's side part haircut with volume at temples, medium length on top, short sides, balancing diamond face shape, keep same face, focus on hair only, male haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Черный", "value": "black"},
                {"name": "Светло-русый", "value": "light blonde"},
                {"name": "Рыжеватый", "value": "auburn"}
            ],
            "lengths": [
                {"name": "Классическая", "value": "classic length"},
                {"name": "Современная", "value": "modern version"}
            ],
            "textures": [
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Текстурные", "value": "textured"},
                {"name": "Объемные", "value": "voluminous"}
            ]
        },
        {
            "name": "Градуированный боб с челкой (Ж)", 
            "style": "graduated bob with wispy bangs, chin-length, side volume, softening sharp cheekbones of diamond face shape, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Пепельный блонд", "value": "ash blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Шоколадный", "value": "chocolate brown"}
            ],
            "lengths": [
                {"name": "Короткий боб", "value": "short bob"},
                {"name": "Классический боб", "value": "classic bob"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Рваные кончики", "value": "choppy ends"},
                {"name": "Многослойные", "value": "layered"}
            ]
        },
        {
            "name": "Пикси с объемной макушкой (Ж)", 
            "style": "pixie cut with volume on top, short tapered sides, softening angles of diamond face shape, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Платиновый блонд", "value": "platinum blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Пепельный", "value": "ash brown"}
            ],
            "lengths": [
                {"name": "Короткий пикси", "value": "short pixie"},
                {"name": "Удлиненный пикси", "value": "long pixie"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Гладкие", "value": "sleek"},
                {"name": "Взъерошенные", "value": "tousled"}
            ]
        },
        {
            "name": "Многослойная стрижка (Ж)", 
            "style": "medium length layered haircut with face-framing pieces, softening sharp angles of diamond face, feminine style, keep same face, focus on hair only, female haircut",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Медовый блонд", "value": "honey blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Карамельный", "value": "caramel blonde"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Многослойные", "value": "heavily layered"}
            ]
        },
        {
            "name": "Текстурный боб с челкой", 
            "style": "textured bob with wispy bangs, chin-length, side volume, softening sharp cheekbones of diamond face shape, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Пепельный блонд", "value": "ash blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Шоколадный", "value": "chocolate brown"}
            ],
            "lengths": [
                {"name": "Короткий боб", "value": "short bob"},
                {"name": "Классический боб", "value": "classic bob"}
            ],
            "textures": [
                {"name": "Текстурные", "value": "textured"},
                {"name": "Рваные кончики", "value": "choppy ends"},
                {"name": "Объемные", "value": "voluminous"}
            ]
        },
        {
            "name": "Объемная стрижка средней длины", 
            "style": "medium length cut with volume at jawline and forehead, layers throughout, balancing width at cheekbones, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Русый", "value": "honey blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Каштановый с бликами", "value": "chestnut brown with highlights"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Многослойные", "value": "heavily layered"}
            ]
        },
        {
            "name": "Мягкий лоб с боковым пробором", 
            "style": "soft lob (long bob) with deep side part, volume at chin level, face-framing layers, softening diamond face angles, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Блонд", "value": "blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Медный", "value": "copper"}
            ],
            "lengths": [
                {"name": "До подбородка", "value": "chin length"},
                {"name": "До плеч", "value": "shoulder length"}
            ],
            "textures": [
                {"name": "Мягкие волны", "value": "soft waves"},
                {"name": "Прямые", "value": "straight"},
                {"name": "Легкая текстура", "value": "slight texture"}
            ]
        },
        {
            "name": "Длинные слоистые волосы", 
            "style": "long layered hair with volume at jawline, soft face-framing pieces, creating balance for diamond face proportions, keep same face, focus on hair only",
            "colors": [
                {"name": "Темно-коричневый", "value": "dark brown"},
                {"name": "Светло-русый", "value": "light blonde"},
                {"name": "Черный", "value": "black"},
                {"name": "Омбре", "value": "ombre"}
            ],
            "lengths": [
                {"name": "До плеч", "value": "shoulder length"},
                {"name": "До лопаток", "value": "mid-back length"},
                {"name": "Очень длинные", "value": "very long"}
            ],
            "textures": [
                {"name": "Прямые", "value": "straight"},
                {"name": "Волнистые", "value": "wavy"},
                {"name": "Крупные локоны", "value": "loose curls"}
            ]
        }
    ]
}

# Bot messages
BOT_MESSAGES = {
    "start": "👋 Привет! Я бот, который предлагает расширенные функции с использованием нейросети LightX AI.\n\nВыберите, пожалуйста, одну из доступных функций:\n\n/menu - показать главное меню функций\n/faceshape - определить форму лица и получить рекомендации\n/try - виртуальная примерка причесок\n/symmetry - проверка симметрии лица (как в TikTok)\n/beauty - анализ привлекательности лица (пропорции, симметрия)\n/help - подробная справка по всем функциям\n\n📸 **Как сделать хорошее фото:**\n• Фото в хорошем освещении (желательно дневной свет)\n• Лицо должно быть чётко видно\n• Прямой ракурс, смотрите в камеру\n• Без головных уборов и аксессуаров\n• Волосы не должны закрывать лицо",
    "help": "Мой бот предлагает множество возможностей с использованием технологий LightX AI:\n\n📊 **Основные функции:**\n• Определение формы лица и рекомендации по прическам\n• Виртуальная примерка причесок с настройкой цвета и длины\n• Проверка симметрии лица (как популярный эффект в TikTok)\n• Анализ привлекательности лица по пропорциям и золотому сечению\n\n🎨 **Дополнительные возможности LightX AI:**\n• Изменение фона на фотографиях\n• Удаление объектов с фотографий\n• Генерация изображений по текстовому описанию\n\n📸 **Требования к фото:**\n• Высокое разрешение (минимум 1080p)\n• Хорошее освещение (избегайте теней на лице)\n• Лицо должно быть в фокусе и занимать центральную часть фото\n• Нейтральное выражение лица\n\nКоманды:\n/menu - главное меню функций\n/faceshape - определить форму лица\n/try - примерить прическу на последнее фото\n/symmetry - проверка симметрии лица\n/beauty - анализ привлекательности лица\n/reset - сбросить данные и начать анализ заново",
    "menu": "🤖 **Главное меню функций**\n\nВыберите интересующую вас функцию:\n\n1️⃣ *Форма лица* - анализ и рекомендации по прическам (/faceshape)\n2️⃣ *Примерка причесок* - виртуальная примерка с настройкой (/try)\n3️⃣ *Проверка симметрии* - анализ симметрии лица, как в TikTok (/symmetry)\n4️⃣ *Анализ привлекательности* - оценка по золотому сечению (/beauty)\n\n🎨 **Дополнительные функции LightX AI:**\n5️⃣ *Удаление фона* - замена фона на фотографиях (требуется загрузить фото)\n6️⃣ *Удаление объектов* - удаление нежелательных объектов (требуется загрузить фото)\n7️⃣ *Генерация по тексту* - создание изображений по описанию (фото не требуется)\n\nДля выбора функции введите соответствующую цифру или используйте команду.",
    "no_face": "Я не смог обнаружить лицо на этой фотографии. Пожалуйста, отправь фото, где ясно видно все лицо.",
    "multiple_faces": "Я обнаружил несколько лиц на фотографии. Пожалуйста, отправь фото только с твоим лицом.",
    "error": "Произошла ошибка при обработке запроса. Пожалуйста, попробуй еще раз или отправь другое фото.",
    "processing": "Обрабатываю твое фото... Это займет несколько секунд.",
    "non_photo": "Пожалуйста, отправь фотографию (не файл, стикер или другой тип сообщения).",
    "no_photo_yet": "Пожалуйста, сначала отправьте фотографию вашего лица для анализа.",
    "try_hairstyle": "Выберите тип прически для виртуальной примерки с помощью нейросети LightX AI:\n\n1. 💇‍♂️ Мужские прически\n2. 💇‍♀️ Женские прически",
    "select_male_style": "Выберите мужскую прическу из списка ниже (введите номер):",
    "select_female_style": "Выберите женскую прическу из списка ниже (введите номер):",
    "hairstyle_applied": "Вот как эта прическа будет выглядеть с вашей формой лица! Изображение сгенерировано нейросетью LightX AI.",
    "hairstyle_generating": "🤖 Запускаю нейросеть LightX AI для генерации реалистичной прически... Это может занять до 15 секунд. Пожалуйста, подождите.",
    "no_hairstyles": "К сожалению, пока нет доступных причесок для вашей формы лица. Мы скоро их добавим!",
    "invalid_hairstyle": "Пожалуйста, выберите корректный номер прически.",
    "input_color_length": "Теперь введите желаемый цвет и длину волос в свободной форме (например, \"темно-каштановый, длинные\" или \"русый, короткие\").",
    "color_length_received": "Спасибо! Я использую указанные параметры для генерации прически.",
    "inversion_analysis": "📊 **Результаты анализа инверсии**\n\nИнверсия лица: {inversion_ratio:.2f}\n\n{inversion_result}\n\nИнверсия - это соотношение между верхней и нижней частями лица, которое влияет на то, как вас воспринимают окружающие и какие прически вам больше подходят.",
    "symmetry_analysis": "🔍 **Анализ симметрии лица**\n\nСимметрия: {symmetry_score:.2f}%\n\n{symmetry_result}\n\nМы разделили ваше лицо пополам и показали, как выглядело бы ваше лицо, если бы было полностью симметричным. Этот эффект похож на популярный фильтр из TikTok.",
    "lightx_feature": "🎨 **{feature_name}**\n\nЭта функция доступна на сайте LightX Editor (www.lightxeditor.com).\n\n✅ Для использования загрузите фото и следуйте инструкциям.",
    "select_texture": "💁‍♀️ Выберите текстуру волос (введите номер):\n• 1: Прямые\n• 2: Волнистые\n• 3: Кудрявые\n• 4: Локоны\n• 5: Вьющиеся\n• 6: С уложенной челкой\n• 7: Объемные",
    "invalid_color": "Пожалуйста, выберите корректный номер цвета волос.",
    "invalid_length": "Пожалуйста, выберите корректный номер длины волос.",
    "invalid_texture": "Пожалуйста, выберите корректный номер текстуры волос.",
    "customization_complete": "Все настройки сохранены! Сейчас сгенерирую прическу с вашими параметрами.",
    "beauty_command": "📸 Отправьте мне свою фотографию, и я проанализирую привлекательность вашего лица на основе симметрии и пропорций по золотому сечению.",
    "beauty_analysis": "✨ **Результаты анализа привлекательности**\n\nОценка: {score}/10\n\n{comment}\n\nАнализ основан на:\n• Симметрии лица\n• Пропорциях по золотому сечению\n• Расположении ключевых черт лица\n\nРезультаты носят исключительно информационный характер и отражают математические соотношения, а не реальную красоту, которая всегда субъективна и уникальна."
}
