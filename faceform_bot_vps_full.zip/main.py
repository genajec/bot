from bot import FaceShapeBot
from stripe_payment import app as stripe_app, stripe_payment
from flask import Flask, jsonify, request, Blueprint, url_for, render_template, redirect
import threading
import os
import time
import logging
import atexit
import telebot
import json

# Загрузка переменных окружения из .env файла
from dotenv import load_dotenv
from pathlib import Path

# Загружаем переменные окружения из .env файла
env_path = Path('.') / '.env'
if env_path.exists():
    load_dotenv(dotenv_path=env_path)
    logging.info("Переменные окружения загружены из .env")

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)

# Определяем маршруты для Stripe прямо в основном приложении

@app.route('/stripe/checkout')
def stripe_checkout():
    """Страница для интеграции Stripe Checkout с JavaScript"""
    # Получаем параметры
    session_id = request.args.get('session_id')
    client_secret = request.args.get('client_secret')
    package_id = request.args.get('package_id')
    credits = request.args.get('credits')
    amount = request.args.get('amount')
    # Получаем имя бота из переменных окружения для унификации
    telegram_bot_name = os.environ.get("TELEGRAM_BOT_NAME", "Faceform_bot")
    return_url = request.args.get('return_url', f"https://t.me/{telegram_bot_name}?start=success-{session_id}")
    
    # Получаем публичный ключ Stripe из переменных окружения
    public_key = os.environ.get('STRIPE_PUBLIC_KEY')
    
    # Логируем для отладки
    logger.info(f"Запрос страницы Stripe Checkout: session_id={session_id}, credits={credits}, amount={amount}")
    
    if not client_secret or not session_id:
        logger.error(f"Отсутствуют необходимые параметры для чекаута: session_id={session_id}, client_secret={client_secret}")
        return render_template('error.html', message="Отсутствуют необходимые параметры для оплаты")
    
    return render_template('checkout.html',
                           public_key=public_key,
                           session_id=session_id,
                           client_secret=client_secret,
                           package_id=package_id,
                           credits=credits,
                           amount=amount,
                           return_url=return_url)
@app.route('/stripe/success')
def stripe_success():
    """Обработка успешной оплаты"""
    session_id = request.args.get('session_id')
    if not session_id:
        logger.error("Недействительный ID сессии при попытке обработать успешную оплату")
        return render_template('error.html', message="Недействительный ID сессии")
    
    # Логируем для отладки
    logger.info(f"Получен запрос на обработку успешной оплаты: session_id={session_id}")
    
    # Проверяем статус оплаты через экземпляр Stripe в классе бота
    if face_shape_bot and hasattr(face_shape_bot, 'stripe_payment'):
        payment_data = face_shape_bot.stripe_payment.get_payment_data(session_id)
        if not payment_data:
            logger.error(f"Не удалось получить информацию о платеже для сессии {session_id}")
            return render_template('error.html', message="Не удалось получить информацию о платеже")
        
        # Если оплата успешна, отображаем страницу успеха
        status = payment_data.get('status')
        logger.info(f"Статус платежа для сессии {session_id}: {status}")
        
        if status == 'completed':
            telegram_id = payment_data.get('telegram_id')
            credits = payment_data.get('credits')
            
            # Получаем имя бота из переменных окружения для унификации
            telegram_bot_name = os.environ.get("TELEGRAM_BOT_NAME", "Faceform_bot")
            
            # Отображаем страницу успеха
            return render_template('success.html', 
                                  credits=credits, 
                                  session_id=session_id,
                                  bot_url=f"https://t.me/{telegram_bot_name}?start=success-{session_id}")
        
        # Если статус "pending", показываем страницу с информацией об ожидании
        return render_template('pending.html')
    else:
        return render_template('error.html', message="Ошибка сервера: экземпляр бота не инициализирован")

@app.route('/stripe/cancel')
def stripe_cancel():
    """Обработка отмены оплаты"""
    session_id = request.args.get('session_id')
    if not session_id:
        logger.error("Недействительный ID сессии при попытке обработать отмену оплаты")
        return render_template('error.html', message="Недействительный ID сессии")
    
    # Логируем для отладки
    logger.info(f"Получен запрос на обработку отмены оплаты: session_id={session_id}")
    
    # Получаем имя бота из переменных окружения для унификации
    telegram_bot_name = os.environ.get("TELEGRAM_BOT_NAME", "Faceform_bot")
    
    # Отображаем страницу с информацией об отмене
    return render_template('error.html', 
                          message="Вы отменили платеж. Вы можете вернуться в бот, чтобы попробовать снова или выбрать другой способ оплаты.",
                          bot_url=f"https://t.me/{telegram_bot_name}")
                          
app.template_folder = 'templates'

# Глобальные переменные для отслеживания состояния бота
bot_thread = None
face_shape_bot = None
is_bot_running = False

def start_bot():
    """Initialize bot and start polling"""
    global face_shape_bot, bot_thread, is_bot_running
    
    # Проверяем, есть ли другие экземпляры бота, запущенные в системе
    # Если есть - не запускаем свой экземпляр
    try:
        import psutil
        current_pid = os.getpid()
        process_count = 0
        
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                # Проверяем, является ли процесс Python и содержит ли командная строка 'main.py'
                if proc.info['name'] == 'python' and proc.info['pid'] != current_pid:
                    cmdline = ' '.join(proc.info['cmdline'])
                    if 'main.py' in cmdline:
                        process_count += 1
                        logger.info(f"Найден другой экземпляр бота (PID: {proc.info['pid']})")
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass
                
        if process_count > 0:
            logger.warning(f"Обнаружено {process_count} работающих экземпляров бота. Не запускаем новый экземпляр")
            # Создаем экземпляр бота без запуска опроса
            if face_shape_bot is None:
                face_shape_bot = FaceShapeBot(use_webhook=False)
            return True
    except Exception as e:
        logger.error(f"Ошибка при проверке других экземпляров бота: {e}")
    
    # Make sure we only create one instance
    if face_shape_bot is None:
        logger.info("Creating new bot instance")
        
        # Создаем экземпляр бота в режиме polling (не webhook) для тестирования
        face_shape_bot = FaceShapeBot(use_webhook=False)
        
        # Проверяем, запущен ли уже поток с ботом
        if bot_thread is None or not bot_thread.is_alive():
            logger.info("Starting bot in polling mode...")
            is_bot_running = True
            
            # Проверяем, не запущен ли уже опрос бота в Telegram API
            try:
                # Пробуем получить последние обновления
                updates = face_shape_bot.bot.get_updates(offset=-1, limit=1, timeout=1)
                if updates:
                    logger.info("Успешно получены обновления от Telegram API")
                
                # Запускаем поллинг бота в отдельном потоке
                def run_bot():
                    try:
                        # Удаляем webhook, чтобы бот работал в режиме polling
                        logger.info("Удаляем webhook для предотвращения конфликтов...")
                        result = face_shape_bot.bot.remove_webhook()
                        logger.info(f"Ответ API: {result}")
                        
                        # Запускаем бота в режиме polling
                        face_shape_bot.bot.polling(none_stop=True, interval=1)
                    except Exception as e:
                        logger.error(f"Error in bot polling: {e}")
                        is_bot_running = False
                
                bot_thread = threading.Thread(target=run_bot)
                bot_thread.daemon = True  # Поток будет завершен при выходе из основной программы
                bot_thread.start()
                
                return True
                
            except Exception as e:
                logger.error(f"Не удалось запустить бота: {e}")
                is_bot_running = False
                return False
    else:
        logger.info("Bot instance already exists")
        # Не пытаемся перезапустить поток, если уже существует экземпляр бота
        return True

# Функция для очистки ресурсов при выходе
def cleanup_resources():
    global is_bot_running
    logger.info("Shutting down, cleaning up resources...")
    is_bot_running = False

# Регистрация функции очистки ресурсов
atexit.register(cleanup_resources)

@app.route("/")
def index():
    return jsonify({
        "status": "running", 
        "message": "Telegram bot is active. Find it at t.me/Faceform_bot"
    })
    
@app.route("/stripe_test")
def stripe_test():
    """Test page for Stripe integration"""
    # Get the Stripe public key from environment
    public_key = os.environ.get('STRIPE_PUBLIC_KEY')
    
    # Get credit packages from the stripe_payment class
    packages = []
    if face_shape_bot and hasattr(face_shape_bot, 'stripe_payment'):
        packages = face_shape_bot.stripe_payment.get_credit_packages()
    
    # Render the test page
    return render_template('stripe_test.html', public_key=public_key, packages=packages)
    
@app.route("/stripe_webhook_guide")
def stripe_webhook_guide():
    """Guide for setting up Stripe webhooks"""
    return render_template('stripe_webhook_guide.html')
    
@app.route("/stripe_test_payment")
def stripe_test_payment():
    """Create a test payment session"""
    # Get package ID from request
    package_id = request.args.get('package_id')
    if not package_id:
        return jsonify({"error": "Missing package_id parameter"}), 400
    
    # Check if bot instance exists
    if not face_shape_bot or not hasattr(face_shape_bot, 'stripe_payment'):
        return jsonify({"error": "Stripe payment module not initialized"}), 500
    
    # Get the package details
    packages = face_shape_bot.stripe_payment.get_credit_packages()
    package = next((p for p in packages if p["id"] == package_id), None)
    if not package:
        return jsonify({"error": f"Package with ID {package_id} not found"}), 404
    
    # Use a test Telegram ID for demonstration
    test_telegram_id = 12345
    
    # Create payment session
    payment_info = face_shape_bot.stripe_payment.create_payment(
        amount=package["price"],
        package_id=package_id,
        telegram_id=test_telegram_id,
        title=f"Test Payment - {package['description']}",
        description=f"Test payment for {package['credits']} credits"
    )
    
    if not payment_info:
        return jsonify({"error": "Failed to create payment session"}), 500
    
    # Redirect to payment URL
    return redirect(payment_info["payment_url"])

@app.route("/health")
def health():
    global bot_thread
    
    if bot_thread is None or not bot_thread.is_alive():
        # Restart the bot if it's not running
        try:
            start_bot()
            status = "restarted"
        except Exception as e:
            logger.error(f"Failed to restart bot: {e}")
            status = "restart_failed"
    else:
        status = "ok"
        
    return jsonify({"status": status})

@app.route("/debug")
def debug():
    """Show system information for debugging"""
    import psutil
    
    # Проверяем, запрашивается ли конкретная переменная окружения
    env_var = request.args.get('env')
    if env_var:
        # Для безопасности: не показываем реальные значения секретов, только их наличие
        value = "Set" if os.environ.get(env_var) else "Not set"
        return jsonify({
            "env_variable": env_var,
            "is_set": value
        })
    
    memory = psutil.virtual_memory()
    return jsonify({
        "memory_used_percent": memory.percent,
        "memory_available": memory.available,
        "cpu_usage": psutil.cpu_percent(interval=1),
        "bot_instance_exists": face_shape_bot is not None,
        "webhook_mode": face_shape_bot.use_webhook if face_shape_bot else False
    })

@app.route("/webhook", methods=["POST"])
def webhook():
    """Webhook endpoint for Telegram bot updates"""
    if request.headers.get("content-type") == "application/json":
        json_string = request.get_data().decode("utf-8")
        update = telebot.types.Update.de_json(json_string)
        
        if face_shape_bot:
            face_shape_bot.bot.process_new_updates([update])
            return "", 200
        else:
            logger.error("Webhook received, but bot instance does not exist")
            return "", 500
    else:
        return "", 403

@app.route("/stripe-webhook", methods=["POST"])
def stripe_webhook():
    """
    Обработчик вебхуков от Stripe
    Stripe будет отправлять уведомления на этот эндпоинт при изменении статуса платежа
    """
    try:
        # Проверяем, что экземпляр бота создан
        if not face_shape_bot:
            logger.error("Экземпляр бота не существует")
            return jsonify({"status": "error", "message": "Bot instance not available"}), 500
            
        # Получаем сырые данные запроса
        payload = request.get_data()
        sig_header = request.headers.get('Stripe-Signature')
        
        if not sig_header:
            logger.warning("Заголовок Stripe-Signature отсутствует, возможно тестовый вызов")
        
        # Логируем заголовки и тело запроса для отладки
        logger.info(f"Получен Stripe webhook. Заголовки: {dict(request.headers)}")
        logger.info(f"Тело запроса (первые 200 символов): {str(payload)[:200]}...")
        
        # Обрабатываем вебхук с использованием метода stripe_payment
        event_data = face_shape_bot.stripe_payment.handle_webhook(payload, sig_header)
        
        if not event_data:
            logger.error("Не удалось обработать вебхук Stripe")
            return jsonify({"status": "error", "message": "Failed to process webhook"}), 400
        
        # Логируем полученные данные
        logger.info(f"Обработанные данные Stripe webhook: {event_data}")
            
        # Если это событие о завершенном платеже
        if event_data.get("status") == "completed":
            # Получаем данные платежа
            session_id = event_data.get("session_id")
            telegram_id = event_data.get("telegram_id")
            
            if not session_id:
                logger.error(f"Не удалось получить ID сессии из данных: {event_data}")
                return jsonify({"status": "error", "message": "Missing session_id"}), 400
                
            if not telegram_id:
                logger.error(f"Не удалось получить telegram_id из данных: {event_data}")
                # Если нет telegram_id в метаданных, попробуем получить его из базы данных по session_id
                from database import Session, Transaction
                db_session = Session()
                try:
                    # Ищем транзакцию с этим session_id
                    transaction = db_session.query(Transaction).filter_by(payment_id=session_id).first()
                    if transaction:
                        telegram_id = transaction.telegram_id
                        logger.info(f"Найден telegram_id в базе данных: {telegram_id}")
                    else:
                        logger.error(f"Транзакция с payment_id={session_id} не найдена в базе данных")
                        return jsonify({"status": "error", "message": "Transaction not found"}), 400
                finally:
                    db_session.close()
            
            # Обрабатываем успешный платеж
            logger.info(f"Обрабатываем успешный платеж: telegram_id={telegram_id}, session_id={session_id}")
            result = face_shape_bot.handle_successful_payment(telegram_id, session_id)
            
            if result:
                logger.info(f"Платеж успешно обработан: telegram_id={telegram_id}, session_id={session_id}")
                return jsonify({"status": "success", "message": "Payment processed successfully"}), 200
            else:
                logger.error(f"Не удалось обработать платеж: telegram_id={telegram_id}, session_id={session_id}")
                return jsonify({"status": "error", "message": "Failed to process payment"}), 500
        
        # Обрабатываем другие статусы (pending, expired, failed)
        elif event_data.get("status") in ["pending", "expired", "failed"]:
            session_id = event_data.get("session_id")
            status = event_data.get("status")
            
            logger.info(f"Получено уведомление о платеже со статусом {status}: session_id={session_id}")
            
            # Здесь можно реализовать обработку других статусов платежа
            # Например, обновить статус в базе данных
            
            return jsonify({"status": "success", "message": f"Payment status '{status}' recorded"}), 200
        
        # Подтверждаем получение любых других типов событий
        return jsonify({"status": "success", "message": "Webhook received, event type: " + event_data.get("event_type", "unknown")}), 200
        
    except Exception as e:
        import traceback
        logger.error(f"Ошибка при обработке Stripe webhook: {e}")
        logger.error(traceback.format_exc())
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/crypto-bot-webhook", methods=["POST"])
def crypto_bot_webhook():
    """
    Обработчик вебхука для Crypto Bot API
    API 1.0 будет отправлять уведомления на этот эндпоинт при изменении статуса платежа
    
    Формат webhook-данных:
    {
        "update_type": "invoice_paid",
        "invoice": {
            "invoice_id": "12345",
            "status": "paid",
            "hash": "hash_value",
            "amount": "10.0",
            "asset": "TON",
            "payload": "package_id:basic_crypto,user_id:123456789"
        }
    }
    """
    try:
        # Проверяем, что экземпляр бота создан
        if not face_shape_bot:
            logger.error("Экземпляр бота не существует")
            return jsonify({"status": "error", "message": "Bot instance not available"}), 500
            
        # Получаем сырые данные запроса для проверки подписи
        request_data = request.get_data()
        
        # Логируем данные для отладки
        logger.info(f"Получены данные вебхука: {request_data}")
        
        # Получаем заголовки с подписью
        signature = request.headers.get('X-Crypto-Bot-Signature')
        init_vector = request.headers.get('X-Crypto-Bot-Signature-IV')
        
        # Проверка подписи, если она передана в заголовках
        if signature:
            # Проверяем подпись запроса
            signature_valid = face_shape_bot.payment_module.verify_webhook_signature(
                request_data, 
                signature,
                init_vector
            )
            
            if not signature_valid:
                logger.error("Недействительная подпись webhook")
                return jsonify({"status": "error", "message": "Invalid signature"}), 403
        else:
            logger.warning("Заголовок X-Crypto-Bot-Signature отсутствует, пропускаем проверку подписи")
            
            # Проверяем наличие тестового режима
            test_mode = os.environ.get("TEST_CRYPTO_BOT", "").lower() == "true"
            if not test_mode:
                logger.warning("Пропуск проверки подписи разрешен только в тестовом режиме")
                # Не возвращаем ошибку для тестовых вызовов
        
        # Пытаемся разобрать JSON-данные
        try:
            data = request.json
            logger.info(f"Получен webhook от Crypto Bot: {data}")
        except Exception as json_error:
            logger.error(f"Не удалось разобрать JSON: {json_error}")
            
            # Проверяем, возможно, это тестовый вызов с простыми данными
            if request.form:
                # Получаем данные формы
                form_data = dict(request.form)
                logger.info(f"Получены данные формы: {form_data}")
                
                # Создаем структуру данных для тестового вебхука
                data = {
                    "update_type": "invoice_paid",
                    "status": form_data.get("status", "paid"),
                    "invoice_id": form_data.get("invoice_id"),
                    "payload": form_data.get("payload", "")
                }
            else:
                return jsonify({"status": "error", "message": "Invalid JSON data"}), 400
        
        # Проверяем наличие обязательных полей
        if not data:
            logger.error("Некорректные данные в webhook")
            return jsonify({"status": "error", "message": "Invalid data"}), 400
        
        # Проверяем тип обновления
        update_type = data.get('update_type')
        
        # Если тип обновления не указан, пробуем использовать статус
        if not update_type and 'status' in data:
            # Тестовый режим с упрощенной структурой
            if data['status'] == 'paid':
                update_type = 'invoice_paid'
            elif data['status'] == 'expired':
                update_type = 'invoice_expired'
        
        if not update_type:
            logger.error("Тип обновления не указан в данных")
            return jsonify({"status": "error", "message": "Update type not specified"}), 400
        
        # Обрабатываем разные типы обновлений
        if update_type == 'invoice_paid':
            # Счет был оплачен
            # Получаем ID инвойса
            invoice_id = None
            
            # Проверяем разные форматы данных
            if 'invoice' in data and isinstance(data['invoice'], dict):
                # Стандартный формат API 1.0
                invoice_id = data['invoice'].get('invoice_id')
            elif 'invoice_id' in data:
                # Упрощенный формат для тестирования
                invoice_id = data['invoice_id']
            
            if not invoice_id:
                logger.error("ID инвойса не найден в данных")
                return jsonify({"status": "error", "message": "Invoice ID not found"}), 400
                
            # Получаем payload с данными заказа
            payload = None
            if 'invoice' in data and isinstance(data['invoice'], dict):
                payload = data['invoice'].get('payload', '')
            elif 'payload' in data:
                payload = data['payload']
                
            # Логируем payload для отладки
            logger.info(f"Payload платежа: {payload}")
            
            # Обрабатываем payload
            package_id = None
            telegram_id = None
            
            if payload:
                # Парсим payload формата "key1:value1,key2:value2"
                pairs = payload.split(',')
                for pair in pairs:
                    if ':' in pair:
                        key, value = pair.split(':', 1)
                        if key == 'package_id':
                            package_id = value
                        elif key == 'user_id':
                            try:
                                telegram_id = int(value)
                            except (ValueError, TypeError):
                                logger.error(f"Некорректный telegram_id в payload: {value}")
            
            # Если в payload не было данных, получаем информацию через API
            if not telegram_id or not package_id:
                # Получаем данные платежа через API
                payment_data = face_shape_bot.payment_module.get_payment_data(invoice_id)
                
                if not payment_data:
                    logger.error(f"Не удалось получить данные платежа для инвойса {invoice_id}")
                    return jsonify({"status": "error", "message": "Payment data not found"}), 400
                    
                # Получаем telegram_id и package_id из данных платежа
                telegram_id = payment_data.get('telegram_id') or telegram_id
                package_id = payment_data.get('package_id') or package_id
            
            # Проверяем наличие необходимых данных
            if not telegram_id:
                logger.error(f"ID пользователя не найден в данных платежа для инвойса {invoice_id}")
                return jsonify({"status": "error", "message": "User ID not found"}), 400
                
            # Убедимся, что telegram_id - это число
            if not isinstance(telegram_id, int):
                try:
                    telegram_id = int(telegram_id)
                except (ValueError, TypeError):
                    logger.error(f"Некорректный telegram_id: {telegram_id}")
                    return jsonify({"status": "error", "message": "Invalid user ID"}), 400
            
            # Обрабатываем платеж
            logger.info(f"Обрабатываем успешный платеж: ID пользователя = {telegram_id}, ID инвойса = {invoice_id}")
            result = face_shape_bot.handle_successful_payment(telegram_id, invoice_id)
            
            if result:
                return jsonify({"status": "success", "message": "Payment processed successfully"}), 200
            else:
                return jsonify({"status": "error", "message": "Failed to process payment"}), 500
                
        elif update_type == 'invoice_expired':
            # Счет истек - можно добавить дополнительную логику при необходимости
            invoice_id = None
            if 'invoice' in data and isinstance(data['invoice'], dict):
                invoice_id = data['invoice'].get('invoice_id')
            elif 'invoice_id' in data:
                invoice_id = data['invoice_id']
                
            logger.info(f"Счет истек: {invoice_id}")
            return jsonify({"status": "success", "message": "Invoice expired notification received"}), 200
            
        else:
            # Другие типы обновлений
            logger.info(f"Получен необрабатываемый тип обновления: {update_type}")
            return jsonify({"status": "success", "message": "Update received"}), 200
            
    except Exception as e:
        import traceback
        logger.error(f"Ошибка при обработке webhook: {e}")
        logger.error(traceback.format_exc())
        return jsonify({"status": "error", "message": str(e)}), 500

# Функция проверки незавершенных платежей
def check_pending_payments():
    """Периодическая проверка незавершенных платежей"""
    global payment_check_timer_started
    
    try:
        logger.info("Начинаем периодическую проверку незавершенных платежей...")
        
        # Проверяем, что экземпляр бота создан
        if not face_shape_bot or not hasattr(face_shape_bot, 'stripe_payment'):
            logger.error("Не удалось проверить незавершенные платежи: экземпляр бота не инициализирован")
            return
            
        # Вызываем метод проверки незавершенных платежей
        processed_count = face_shape_bot.stripe_payment.check_pending_payments()
        logger.info(f"Периодическая проверка незавершенных платежей завершена. Обработано: {processed_count}")
        
        # Планируем следующую проверку через 30 минут
        threading.Timer(1800, check_pending_payments).start()
    except Exception as e:
        logger.error(f"Ошибка при периодической проверке незавершенных платежей: {e}")
        # Даже в случае ошибки планируем следующую проверку
        threading.Timer(1800, check_pending_payments).start()

# Глобальные переменные
payment_check_timer_started = False

# Initialize the bot when app starts
with app.app_context():
    start_bot()
    
    # Запускаем первую проверку незавершенных платежей через 5 минут после запуска
    # Только если таймер не был запущен ранее
    if not payment_check_timer_started:
        threading.Timer(300, check_pending_payments).start()
        payment_check_timer_started = True
        logger.info("Запланирована периодическая проверка незавершенных платежей (первый запуск через 5 минут)")

# For running directly with Python (without Gunicorn)
if __name__ == "__main__":
    # Start bot
    start_bot()
    
    # Запускаем первую проверку незавершенных платежей только в случае,
    # если таймер не был запущен ранее (избегаем множественных таймеров)
    if not payment_check_timer_started:
        threading.Timer(300, check_pending_payments).start()
        payment_check_timer_started = True
        logger.info("Запланирована периодическая проверка незавершенных платежей (первый запуск через 5 минут)")
    
    # Run the Flask app
    try:
        app.run(host="0.0.0.0", port=5000)
    except OSError as e:
        if "Address already in use" in str(e):
            logger.warning("Порт 5000 уже используется, Flask приложение не запущено")
            # Просто продолжаем работу без запуска Flask, так как вероятно
            # приложение уже запущено через Gunicorn
            import time
            while True:
                time.sleep(60)  # Просто поддерживаем процесс живым
        else:
            raise
