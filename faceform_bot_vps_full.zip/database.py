import os
import logging
import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from models import Base, User, Transaction, CreditUsage

# Настраиваем логирование
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Получаем URL базы данных из переменной окружения или используем SQLite по умолчанию
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///faceform_bot.db")

# Создаем движок SQLAlchemy
engine = create_engine(DATABASE_URL)

# Создаем фабрику сессий
session_factory = sessionmaker(bind=engine)
Session = scoped_session(session_factory)

def init_db():
    """Инициализировать базу данных (создать таблицы)"""
    try:
        # Создаем все таблицы, которые определены в models.py
        Base.metadata.create_all(engine)
        logger.info("База данных успешно инициализирована")
    except Exception as e:
        logger.error(f"Ошибка при инициализации базы данных: {e}")
        raise

def get_or_create_user(telegram_id, username=None, first_name=None, last_name=None):
    """
    Получить существующего пользователя или создать нового
    
    Args:
        telegram_id (int): ID пользователя в Telegram
        username (str, optional): Имя пользователя в Telegram
        first_name (str, optional): Имя пользователя
        last_name (str, optional): Фамилия пользователя
        
    Returns:
        User: Объект пользователя
    """
    session = Session()
    try:
        # Ищем пользователя по ID в Telegram
        user = session.query(User).filter_by(telegram_id=telegram_id).first()
        
        if user is None:
            # Если пользователь не найден, создаем нового
            user = User(
                telegram_id=telegram_id,
                username=username,
                first_name=first_name,
                last_name=last_name,
                credits=0  # Новый пользователь получает 0 кредитов
            )
            session.add(user)
            session.commit()
            logger.info(f"Создан новый пользователь с ID {telegram_id}")
        
        return user
    except Exception as e:
        session.rollback()
        logger.error(f"Ошибка при работе с пользователем {telegram_id}: {e}")
        raise
    finally:
        session.close()

def get_user_credits(telegram_id):
    """
    Получить количество кредитов у пользователя
    
    Args:
        telegram_id (int): ID пользователя в Telegram
        
    Returns:
        int: Количество кредитов у пользователя
    """
    session = Session()
    try:
        user = session.query(User).filter_by(telegram_id=telegram_id).first()
        if user:
            return user.credits
        return 0
    except Exception as e:
        logger.error(f"Ошибка при получении кредитов пользователя {telegram_id}: {e}")
        return 0
    finally:
        session.close()

def update_user_credits(telegram_id, credits_change):
    """
    Изменить количество кредитов у пользователя
    
    Args:
        telegram_id (int): ID пользователя в Telegram
        credits_change (int): Изменение количества кредитов (положительное - добавление, отрицательное - списание)
        
    Returns:
        int: Новое количество кредитов у пользователя
    """
    session = Session()
    try:
        user = session.query(User).filter_by(telegram_id=telegram_id).first()
        if user:
            # Обновляем количество кредитов
            user.credits += credits_change
            # Проверяем, что количество кредитов не стало отрицательным
            if user.credits < 0:
                user.credits = 0
            session.commit()
            return user.credits
        return 0
    except Exception as e:
        session.rollback()
        logger.error(f"Ошибка при обновлении кредитов пользователя {telegram_id}: {e}")
        return 0
    finally:
        session.close()

def use_credit(telegram_id, feature):
    """
    Использовать 1 кредит для определенной функции
    
    Args:
        telegram_id (int): ID пользователя в Telegram
        feature (str): Название функции, для которой используется кредит
        
    Returns:
        bool: True, если кредит успешно использован, False в противном случае
    """
    session = Session()
    try:
        user = session.query(User).filter_by(telegram_id=telegram_id).first()
        if not user:
            logger.error(f"Пользователь {telegram_id} не найден")
            return False
            
        # Проверяем, есть ли у пользователя кредиты
        if user.credits <= 0:
            logger.warning(f"У пользователя {telegram_id} недостаточно кредитов")
            return False
            
        # Списываем кредит
        user.credits -= 1
        
        # Записываем использование кредита
        credit_usage = CreditUsage(
            user_id=user.id,
            feature=feature,
            credits_used=1
        )
        session.add(credit_usage)
        session.commit()
        
        logger.info(f"Пользователь {telegram_id} использовал 1 кредит для функции {feature}. Осталось: {user.credits}")
        return True
    except Exception as e:
        session.rollback()
        logger.error(f"Ошибка при использовании кредита пользователем {telegram_id}: {e}")
        return False
    finally:
        session.close()

def create_transaction(telegram_id, amount, credits, payment_id=None):
    """
    Создать новую транзакцию покупки кредитов
    
    Args:
        telegram_id (int): ID пользователя в Telegram
        amount (float): Сумма в долларах
        credits (int): Количество приобретаемых кредитов
        payment_id (str, optional): ID платежа в платежной системе
        
    Returns:
        Transaction: Объект транзакции
    """
    session = Session()
    try:
        user = session.query(User).filter_by(telegram_id=telegram_id).first()
        if not user:
            logger.error(f"Пользователь {telegram_id} не найден")
            return None
            
        # Создаем транзакцию
        transaction = Transaction(
            user_id=user.id,
            amount=amount,
            credits=credits,
            status='pending',
            payment_id=payment_id
        )
        session.add(transaction)
        session.commit()
        
        logger.info(f"Создана новая транзакция для пользователя {telegram_id}: {amount}$ за {credits} кредитов")
        return transaction
    except Exception as e:
        session.rollback()
        logger.error(f"Ошибка при создании транзакции для пользователя {telegram_id}: {e}")
        return None
    finally:
        session.close()

def complete_transaction(transaction_id, status='completed'):
    """
    Завершить транзакцию и начислить кредиты пользователю
    
    Args:
        transaction_id (str): ID транзакции (например, session_id из Stripe)
        status (str): Статус транзакции ('completed', 'canceled', 'failed')
        
    Returns:
        bool: True, если транзакция успешно завершена, False в противном случае
    """
    session = Session()
    try:
        # Ищем по payment_id, а не по id
        transaction = session.query(Transaction).filter_by(payment_id=transaction_id).first()
        if not transaction:
            logger.error(f"Транзакция с payment_id={transaction_id} не найдена")
            return False
            
        # Проверяем, что транзакция еще не завершена
        if transaction.status == status and status == 'completed':
            logger.warning(f"Транзакция {transaction_id} уже имеет статус {status}")
            return True
            
        # Получаем пользователя
        user = session.query(User).filter_by(id=transaction.user_id).first()
        if not user:
            logger.error(f"Пользователь для транзакции {transaction_id} не найден")
            return False
            
        # Обновляем статус транзакции
        transaction.status = status
        transaction.completed_at = datetime.datetime.utcnow()
        transaction.updated_at = datetime.datetime.utcnow()
        
        # Начисляем кредиты пользователю только если статус completed
        if status == 'completed':
            user.credits += transaction.credits
            logger.info(f"Транзакция {transaction_id} успешно завершена. Пользователь {user.telegram_id} получил {transaction.credits} кредитов")
        else:
            logger.info(f"Транзакция {transaction_id} отмечена как {status}. Пользователь {user.telegram_id} не получил кредитов.")
        
        session.commit()
        return True
    except Exception as e:
        session.rollback()
        logger.error(f"Ошибка при завершении транзакции {transaction_id}: {e}")
        return False
    finally:
        session.close()

# Инициализируем базу данных при импорте модуля
init_db()