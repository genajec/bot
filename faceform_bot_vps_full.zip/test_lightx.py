import os
import sys
import logging
import cv2
import numpy as np
from lightx_client import LightXClient
from face_analyzer import FaceAnalyzer

# Настройка логирования
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_lightx_api():
    """
    Тестирование интеграции с LightX API для генерации причесок
    """
    # Загружаем тестовое изображение
    test_image_path = "demo_base_face.jpg"
    if not os.path.exists(test_image_path):
        logger.error(f"Тестовое изображение не найдено: {test_image_path}")
        return False
    
    # Читаем тестовое изображение
    with open(test_image_path, "rb") as f:
        image_data = f.read()
    
    # Инициализируем face_analyzer
    face_analyzer = FaceAnalyzer()
    
    # Анализируем форму лица
    face_shape, _, _ = face_analyzer.analyze_face_shape(image_data)
    if not face_shape:
        logger.error("Не удалось определить форму лица")
        return False
    
    logger.info(f"Определена форма лица: {face_shape}")
    
    # Получаем доступные стили причесок для формы лица
    hairstyles = face_analyzer.get_available_hairstyles(face_shape)
    logger.info(f"Доступно {len(hairstyles)} причесок для формы лица {face_shape}")
    
    # Выбираем первую прическу для тестирования
    hairstyle_index = 0
    
    # Применяем прическу к изображению
    result_image_bytes = face_analyzer.apply_hairstyle(image_data, None, face_shape, hairstyle_index)
    
    if not result_image_bytes:
        logger.error("Не удалось применить прическу")
        return False
    
    # Сохраняем результат
    result_path = "test_hairstyle_result.jpg"
    with open(result_path, "wb") as f:
        f.write(result_image_bytes)
    
    logger.info(f"Результат сохранен в {result_path}")
    return True

if __name__ == "__main__":
    logger.info("Тестирование LightX API...")
    result = test_lightx_api()
    
    if result:
        logger.info("Тест успешно завершен! ✅")
        sys.exit(0)
    else:
        logger.error("Тест завершился с ошибкой ❌")
        sys.exit(1)