# FaceForm Telegram Бот

## Описание
FaceForm - это продвинутый Telegram бот для анализа формы лица, предоставления рекомендаций по прическам и других функций на основе компьютерного зрения и AI.

## Функциональность
- 🧠 Анализ формы лица (овальное, круглое, квадратное, сердцевидное, продолговатое, ромбовидное)
- 💇 Подбор прически под форму лица
- 🪞 Виртуальная примерка причесок
- 🎥 Обработка видео для визуализации параметров лица
- 🌟 Анализ привлекательности лица
- 🖼️ Смена фона на фотографиях
- 🔄 Замена элементов на фотографиях с помощью AI
- 💰 Система кредитов и платежей (Stripe и Crypto Bot)

## Установка на VPS

### Требования к серверу
- Ubuntu 20.04 или выше
- Python 3.8 или выше
- Доступ по SSH с правами sudo

### Шаги установки

1. **Подготовка сервера**:
   ```bash
   sudo apt update && sudo apt upgrade -y
   sudo apt install -y python3-pip python3-venv supervisor zip unzip git
   sudo apt install -y libgl1-mesa-glx libsm6 libxext6 libxrender-dev libglib2.0-0
   ```

2. **Создание директории и распаковка архива**:
   ```bash
   mkdir -p ~/faceform_bot
   cd ~/faceform_bot
   # Загрузите faceform_bot_vps.zip на сервер
   unzip faceform_bot_vps.zip
   ```

3. **Настройка API ключей**:
   ```bash
   cp .env.example .env
   nano .env
   ```
   
   Заполните в файле .env следующие ключи:
   - TELEGRAM_API_TOKEN - получите у @BotFather
   - DEEPL_API_KEY - API ключ для перевода
   - STRIPE_SECRET_KEY, STRIPE_PUBLIC_KEY, STRIPE_WEBHOOK_SECRET - для платежей через Stripe
   - LIGHTX_API_KEY - для работы с LightX API (замена фона, обработка изображений)
   - CRYPTO_BOT_API_KEY - для платежей через CryptoBot

4. **Запуск скрипта установки**:
   ```bash
   chmod +x setup.sh
   ./setup.sh
   ```

5. **Проверка статуса**:
   ```bash
   sudo supervisorctl status faceform_bot_polling
   ```

## Управление ботом

### Мониторинг логов
```bash
sudo tail -f /var/log/faceform_bot/stderr.log
sudo tail -f /var/log/faceform_bot/stdout.log
```

### Перезапуск бота
```bash
sudo supervisorctl restart faceform_bot_polling
```

### Остановка бота
```bash
sudo supervisorctl stop faceform_bot_polling
```

## Структура проекта
- `bot.py` - основной файл бота
- `run_vps.py` - скрипт запуска в режиме polling для VPS
- `face_analyzer.py` - модуль анализа лица
- `database.py` - работа с базой данных
- `config.py` - конфигурация бота
- `models.py` - модели данных
- `lightx_client.py` - интеграция с LightX API
- `process_video_with_grid.py` - обработка видео
- `stripe_payment.py` - интеграция с платежами Stripe
- `crypto_bot_payment.py` - интеграция с CryptoBot

## Бэкап и восстановление

### Создание резервной копии базы данных
```bash
cd ~/faceform_bot
cp faceform_bot.db faceform_bot_backup_$(date +%Y%m%d).db
```

### Создание полного бэкапа бота
```bash
cd ~
zip -r faceform_bot_backup_$(date +%Y%m%d).zip faceform_bot
```

## Поддержка и обновления
Для обновления бота:
1. Загрузите новую версию на VPS
2. Распакуйте файлы в директорию бота
3. Перезапустите бота через supervisor

## Примечания
- Бот работает в режиме polling на VPS, что обеспечивает стабильную работу без необходимости настройки SSL и обратного прокси.
- База данных SQLite используется по умолчанию (`faceform_bot.db`).
- Логи хранятся в директории `/var/log/faceform_bot/`.

---
© 2025 FaceForm Bot