#!/usr/bin/env python
"""
Тест для проверки взаимодействия DeepL и LightX API
"""

import logging
import requests
import sys
from lightx_client import LightXClient
from config import LIGHTX_API_KEY

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def translate_with_deepl(text, source_lang="RU", target_lang="EN"):
    """
    Переводит текст с помощью DeepL API
    
    Args:
        text (str): Исходный текст для перевода
        source_lang (str): Язык исходного текста (по умолчанию "RU" - русский)
        target_lang (str): Язык, на который нужно перевести (по умолчанию "EN" - английский)
        
    Returns:
        str: Переведенный текст или None при ошибке
    """
    try:
        # Ключ API DeepL
        api_key = "7fe9dd7a-990a-4bf1-86af-a216b1b993a1:fx"
        
        # URL DeepL API
        url = "https://api-free.deepl.com/v2/translate"
        
        # Данные для запроса
        data = {
            "text": [text],
            "source_lang": source_lang,
            "target_lang": target_lang
        }
        
        # Заголовки с ключом API
        headers = {
            "Authorization": f"DeepL-Auth-Key {api_key}",
            "Content-Type": "application/json"
        }
        
        logger.info(f"Отправляем запрос перевода в DeepL API для текста: '{text}'")
        
        # Отправляем запрос
        response = requests.post(url, json=data, headers=headers)
        
        # Проверяем успешность запроса
        if response.status_code == 200:
            result = response.json()
            
            if "translations" in result and len(result["translations"]) > 0:
                translated_text = result["translations"][0]["text"]
                logger.info(f"Перевод через DeepL успешен: '{text}' -> '{translated_text}'")
                return translated_text
            else:
                logger.warning(f"DeepL API вернул 200, но переводов не найдено в ответе: {result}")
        
        # Если запрос неуспешен или ответ не содержит перевода,
        # логируем ошибку и возвращаем None
        logger.warning(f"Ошибка DeepL API: {response.status_code} - {response.text}")
        return None
    except Exception as e:
        logger.error(f"Ошибка при использовании DeepL API: {e}")
        return None

def test_translation_to_lightx():
    """
    Тестирует передачу перевода в LightX API
    """
    try:
        # Инициализируем клиент LightX API
        logger.info("Инициализация LightX клиента...")
        lightx_client = LightXClient()
        logger.info(f"LightX API ключ: {LIGHTX_API_KEY[:10]}...")
        
        # Тестовые фразы на русском
        test_phrases = [
            "Создай деловой портрет в офисе",
            "Сделай фотографию с синим фоном"
        ]
        
        for phrase in test_phrases:
            logger.info(f"\nИсходная фраза: '{phrase}'")
            
            # Переводим фразу
            translated = translate_with_deepl(phrase)
            if not translated:
                logger.error("Не удалось перевести фразу")
                continue
                
            logger.info(f"Перевод: '{translated}'")
            
            # Улучшаем запрос для LightX (добавляем качество и детали)
            improved_prompt = f"{translated}, photorealistic, high-resolution, professional"
            logger.info(f"Улучшенный запрос для LightX: '{improved_prompt}'")
            
            # Здесь должен быть вызов LightX API с улучшенным запросом
            # В этом тесте мы только проверяем формирование запроса
            logger.info("API запрос к LightX будет выполнен с переведенным запросом")
            
    except Exception as e:
        logger.error(f"Ошибка при тестировании интеграции DeepL и LightX: {e}")
        import traceback
        logger.error(traceback.format_exc())

def main():
    """Основная функция"""
    print("Тест интеграции DeepL и LightX API\n")
    
    test_translation_to_lightx()

if __name__ == "__main__":
    main()