#!/usr/bin/env python
"""
Скрипт для запуска бота в режиме polling
"""

import logging
import sys
import telebot
from bot import FaceShapeBot
from config import TELEGRAM_API_TOKEN

# Настраиваем логирование
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def main():
    """
    Запуск бота в режиме polling
    """
    logger.info("Запуск бота FaceShapeBot в режиме polling")
    
    try:
        # Удаляем старый webhook перед запуском polling
        try:
            bot = telebot.TeleBot(TELEGRAM_API_TOKEN)
            bot.delete_webhook()
            logger.info("Webhook успешно удален")
        except Exception as e:
            logger.error(f"Ошибка при удалении webhook: {e}")
        
        # Создаем экземпляр бота
        face_shape_bot = FaceShapeBot(use_webhook=False)
        
        # Выводим информацию о доступных командах
        logger.info("""
        Бот запущен. Доступны следующие команды:
        /start - Начать работу с ботом
        /help - Получить справку
        /try - Примерить прическу (после анализа фото)
        /hairstyles - Список причесок
        /reset - Сбросить данные
        """)
        
        # Запускаем бота в режиме polling
        face_shape_bot.run()
        
    except Exception as e:
        logger.error(f"Ошибка при запуске бота: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()