# Быстрый запуск FaceForm бота на VPS

## Подготовка сервера
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y python3-pip python3-venv supervisor zip unzip git
sudo apt install -y libgl1-mesa-glx libsm6 libxext6 libxrender-dev libglib2.0-0
```

## Установка бота
```bash
# 1. Создайте директорию
mkdir -p ~/faceform_bot
cd ~/faceform_bot

# 2. Загрузите архив и распакуйте его
# Скопируйте файл faceform_bot_vps_full.zip на сервер 
unzip faceform_bot_vps_full.zip

# 3. Запустите скрипт установки
chmod +x setup.sh
./setup.sh
```

## Проверка работы бота
```bash
# Проверьте статус запущенного бота
sudo supervisorctl status faceform_bot_polling

# Проверьте логи
sudo tail -f /var/log/faceform_bot/stderr.log
sudo tail -f /var/log/faceform_bot/stdout.log
```

## Использование
Бот запущен в режиме polling, работает стабильно без настройки SSL или обратного прокси.
Найдите бота в Telegram: @Faceform_bot

## Важные файлы:
- .env - файл с API ключами (уже настроен, не меняйте)
- faceform_bot.db - база данных SQLite (уже создана и заполнена)
- run_vps.py - основной скрипт запуска бота на VPS

## Перезапуск бота
```bash
sudo supervisorctl restart faceform_bot_polling
```

---
© 2025 FaceForm Bot