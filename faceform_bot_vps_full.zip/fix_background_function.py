#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging
import requests
import os
import re
import traceback

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def fix_background_change_function():
    """
    Возвращает исправленную версию функции change_background для LightX API
    """
    code = """
    def change_background(self, image_data, background_prompt, style_image_data=None):
        \"\"\"
        Меняет фон на фотографии используя API удаления фона с последующей установкой нового фона
        
        Args:
            image_data (bytes): Исходная фотография
            background_prompt (str): Текстовое описание или цвет нового фона (например, "#FFFFFF" для белого)
            style_image_data (bytes, optional): Изображение стиля для применения к фону
            
        Returns:
            bytes: Фотография с новым фоном или None, если ошибка
        \"\"\"
        # Проверка наличия API ключа LightX перед отправкой запроса
        if not self.api_key:
            logger.error("CRITICAL ERROR: LIGHTX_API_KEY не найден в переменных окружения!")
            logger.error("Убедитесь, что API ключ LightX добавлен в переменные окружения под именем LIGHTX_API_KEY")
            return None
            
        try:
            # Подготовка цвета фона или URL изображения фона
            bg_value = background_prompt
            
            # Проверяем, является ли фон цветом в формате HEX
            import re
            is_hex_color = re.match(r'^#(?:[0-9a-fA-F]{3}){1,2}$', str(bg_value)) is not None
            
            # Если это не HEX-цвет и не URL изображения, используем белый цвет по умолчанию
            if not is_hex_color and not (isinstance(bg_value, str) and bg_value.startswith('http')):
                logger.info(f"Промпт '{bg_value}' не является цветом HEX или URL изображения, используем белый цвет #FFFFFF")
                bg_value = "#FFFFFF"
                
            # Шаг 1: Загружаем основное изображение
            logger.info(f"Шаг 1: Загрузка оригинального изображения на сервер LightX")
            image_url = self.upload_image(image_data)
            if not image_url:
                logger.error("Failed to upload image for background change")
                return None
                
            logger.info(f"Успешно загружено основное изображение, получен URL: {image_url}")
            
            # Шаг 2: Отправляем запрос на удаление фона с заменой на новый
            logger.info(f"Шаг 2: Отправка запроса на удаление фона с заменой на: '{bg_value}'")
            
            # URL для API удаления фона
            remove_bg_url = "https://api.lightxeditor.com/external/api/v1/remove-background"
            
            # Данные для запроса согласно документации API
            data = {
                "imageUrl": image_url,
                "background": bg_value  # Цвет фона или URL изображения фона
            }
            
            # Заголовки для аутентификации
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key
            }
            
            logger.info(f"URL запроса: {remove_bg_url}")
            logger.info(f"Заголовки запроса: {headers}")
            logger.info(f"Тело запроса: {data}")
            
            # Отправляем запрос
            response = requests.post(remove_bg_url, headers=headers, json=data)
            logger.info(f"Получен ответ API со статусом: {response.status_code}")
            logger.info(f"Текст ответа: {response.text[:200]}...")  # Логируем только начало текста ответа
            
            # Проверяем ответ
            if response.status_code != 200:
                logger.error(f"Failed to request background removal: {response.status_code} - {response.text}")
                return None
                
            logger.info(f"Запрос успешно отправлен, получен ответ статус {response.status_code}")
            
            # Анализируем ответ
            result = response.json()
            
            if result.get("statusCode") != 2000 or "body" not in result:
                logger.error(f"Invalid response from remove-background API: {result}")
                return None
                
            # Получаем ID заказа
            order_id = result["body"].get("orderId")
            if not order_id:
                logger.error("Missing order ID in response")
                return None
                
            logger.info(f"Получен ID заказа: {order_id}")
            
            # Шаг 3: Ожидаем результат
            logger.info(f"Шаг 3: Ожидание обработки изображения...")
            
            # Увеличиваем количество попыток и интервал ожидания
            output_url = self.wait_for_result(order_id, max_retries=20, retry_interval=3)
            if not output_url:
                logger.error("Failed to get output URL after waiting")
                return None
                
            logger.info(f"Обработка завершена, получен URL результата: {output_url}")
            
            # Шаг 4: Загружаем результат
            logger.info(f"Шаг 4: Загрузка обработанного изображения")
            response = requests.get(output_url)
            if response.status_code != 200:
                logger.error(f"Failed to download image with new background: {response.status_code}")
                return None
                
            logger.info(f"Успешно загружено обработанное изображение, размер: {len(response.content)} байт")
            return response.content
            
        except Exception as e:
            logger.error(f"Error changing background: {e}")
            # Более подробное логирование ошибки
            import traceback
            logger.error(f"Stack trace: {traceback.format_exc()}")
            return None
    """
    return code

def main():
    """
    Основная функция для тестирования и интеграции
    """
    # Вывод функции для копирования
    print(fix_background_change_function())

if __name__ == "__main__":
    main()