import os
import requests
import json
from dotenv import load_dotenv

# Загружаем переменные из .env файла
load_dotenv()

# Загружаем API ключ из переменной окружения
api_key = os.environ.get("LIGHTX_API_KEY")
print(f"API Key: {api_key}")

# Тестируем запрос на получение URL для загрузки изображения
def test_upload_url():
    url = 'https://api.lightxeditor.com/external/api/v2/uploadImageUrl'
    headers = {
        'Content-Type': 'application/json',
        'x-api-key': api_key
    }
    data = {
        "uploadType": "imageUrl",
        "size": 100000,
        "contentType": "image/jpeg"
    }
    
    print("Отправляем запрос на получение URL для загрузки...")
    response = requests.post(url, headers=headers, json=data)
    
    print(f"Статус ответа: {response.status_code}")
    print(f"Тело ответа: {response.text}")
    
    if response.status_code == 200:
        print("Запрос успешно выполнен! ✅")
        return True
    else:
        print("Ошибка в запросе! ❌")
        return False

# Тестируем запрос на генерацию изображения по тексту
def test_text_to_image():
    url = 'https://api.lightxeditor.com/external/api/v1/text2image'
    headers = {
        'Content-Type': 'application/json',
        'x-api-key': api_key
    }
    data = {
        "textPrompt": "портрет девушки с красивой прической, реалистичный стиль",
        "negativePrompt": "low quality, blurry"
    }
    
    print("Отправляем запрос на генерацию изображения...")
    response = requests.post(url, headers=headers, json=data)
    
    print(f"Статус ответа: {response.status_code}")
    print(f"Тело ответа: {response.text}")
    
    if response.status_code == 200:
        print("Запрос успешно отправлен! ✅")
        
        # Получаем orderId для проверки результата
        result = response.json()
        if "body" in result and "orderId" in result["body"]:
            order_id = result["body"]["orderId"]
            print(f"Order ID: {order_id}")
            
            # Ждем 5 секунд перед проверкой результата
            import time
            print("Ожидаем обработку изображения...")
            time.sleep(5)
            
            # Проверяем статус заказа
            check_order_status(order_id)
        
        return True
    else:
        print("Ошибка в запросе! ❌")
        return False

# Проверка статуса заказа
def check_order_status(order_id):
    url = 'https://api.lightxeditor.com/external/api/v1/order-status'
    headers = {
        'Content-Type': 'application/json',
        'x-api-key': api_key
    }
    data = {
        "orderId": order_id
    }
    
    print(f"Проверяем статус заказа {order_id}...")
    response = requests.post(url, headers=headers, json=data)
    
    print(f"Статус ответа: {response.status_code}")
    print(f"Тело ответа: {response.text}")
    
    if response.status_code == 200:
        result = response.json()
        if "body" in result and "status" in result["body"]:
            status = result["body"]["status"]
            print(f"Статус заказа: {status}")
            
            if status == "active" and "output" in result["body"]:
                output_url = result["body"]["output"]
                print(f"URL результата: {output_url}")
                return True
            elif status == "init":
                print("Заказ все еще обрабатывается, требуется больше времени")
            else:
                print(f"Неизвестный статус: {status}")
        else:
            print("Неверный формат ответа")
    else:
        print("Ошибка при проверке статуса заказа")
    
    return False

# Тестируем функцию ретуши фото
def test_beautify():
    # Сначала нужно получить URL для загрузки изображения
    url = 'https://api.lightxeditor.com/external/api/v2/uploadImageUrl'
    headers = {
        'Content-Type': 'application/json',
        'x-api-key': api_key
    }
    
    # Получаем URL для загрузки
    upload_data = {
        "uploadType": "imageUrl",
        "size": 100000,
        "contentType": "image/jpeg"
    }
    
    print("Получаем URL для загрузки изображения...")
    upload_response = requests.post(url, headers=headers, json=upload_data)
    
    if upload_response.status_code != 200:
        print("Ошибка при получении URL для загрузки! ❌")
        return False
    
    upload_result = upload_response.json()
    
    if "body" not in upload_result or "imageUrl" not in upload_result["body"]:
        print("Неверный формат ответа при получении URL! ❌")
        return False
    
    # В реальном сценарии здесь мы бы загрузили изображение по URL,
    # но для теста просто используем полученный URL
    image_url = upload_result["body"]["imageUrl"]
    print(f"URL изображения: {image_url}")
    
    # Теперь отправляем запрос на ретушь
    beautify_url = 'https://api.lightxeditor.com/external/api/v1/beautify'
    
    beautify_data = {
        "imageUrl": image_url,
        "options": {
            "skinSmoothing": True,
            "enhanceFeatures": True,
            "removeImperfections": True,
            "improveContrast": True,
            "level": 0.75
        }
    }
    
    print("\nОтправляем запрос на ретушь фото...")
    beautify_response = requests.post(beautify_url, headers=headers, json=beautify_data)
    
    print(f"Статус ответа: {beautify_response.status_code}")
    print(f"Тело ответа: {beautify_response.text}")
    
    if beautify_response.status_code == 200:
        print("Запрос на ретушь успешно отправлен! ✅")
        
        # Получаем orderId для проверки результата
        result = beautify_response.json()
        if "body" in result and "orderId" in result["body"]:
            order_id = result["body"]["orderId"]
            print(f"Order ID: {order_id}")
            
            # Ждем 5 секунд перед проверкой результата
            import time
            print("Ожидаем обработку изображения...")
            time.sleep(5)
            
            # Проверяем статус заказа
            check_order_status(order_id)
        
        return True
    else:
        print("Ошибка в запросе на ретушь! ❌")
        return False

if __name__ == "__main__":
    print("Тестирование подключения к LightX API...")
    print("\n1. Тест получения URL загрузки")
    test_upload_url()
    
    print("\n2. Тест генерации изображения по тексту")
    test_text_to_image()
    
    print("\n3. Тест функции ретуши фото")
    test_beautify()