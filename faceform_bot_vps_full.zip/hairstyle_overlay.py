import cv2
import numpy as np
import os
import logging
from PIL import Image
from io import BytesIO

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class HairstyleOverlay:
    """Class to handle virtual hairstyle try-on functionality"""
    
    def __init__(self):
        """Initialize the hairstyle overlay manager"""
        self.hairstyles = self._load_hairstyles()
        
    def _load_hairstyles(self):
        """
        Load hairstyle overlay images from the hairstyles directory.
        
        Returns:
            dict: Dictionary mapping face shapes to lists of hairstyle images
        """
        hairstyles = {
            "OVAL": [],
            "ROUND": [],
            "SQUARE": [],
            "HEART": [],
            "OBLONG": [],
            "DIAMOND": []
        }
        
        # Check if hairstyles directory exists, create if not
        if not os.path.exists("hairstyles"):
            os.makedirs("hairstyles")
            logger.warning("Hairstyles directory not found, created empty directory")
            return hairstyles
            
        # Load hairstyles for each face shape
        for face_shape in hairstyles.keys():
            shape_dir = os.path.join("hairstyles", face_shape.lower())
            if not os.path.exists(shape_dir):
                logger.warning(f"Directory for {face_shape} hairstyles not found")
                continue
                
            for file_name in os.listdir(shape_dir):
                if file_name.lower().endswith(('.png', '.jpg', '.jpeg')):
                    try:
                        # PNG format is preferred for transparency
                        image_path = os.path.join(shape_dir, file_name)
                        image = cv2.imread(image_path, cv2.IMREAD_UNCHANGED)
                        
                        # If image has no alpha channel, skip it
                        if image.shape[2] < 4:
                            logger.warning(f"Skipping {file_name}: no alpha channel")
                            continue
                            
                        hairstyles[face_shape].append({
                            'image': image,
                            'name': os.path.splitext(file_name)[0]
                        })
                        logger.info(f"Loaded hairstyle: {file_name} for {face_shape}")
                    except Exception as e:
                        logger.error(f"Error loading hairstyle {file_name}: {e}")
        
        return hairstyles
    
    def get_available_hairstyles(self, face_shape):
        """
        Get list of available hairstyle names for a face shape
        
        Args:
            face_shape (str): The determined face shape
            
        Returns:
            list: List of hairstyle names
        """
        if face_shape not in self.hairstyles:
            logger.warning(f"No hairstyles found for {face_shape}, using OVAL")
            face_shape = "OVAL"
            
        return [h['name'] for h in self.hairstyles[face_shape]]
    
    def apply_hairstyle(self, image_data, landmarks, face_shape, hairstyle_index=0):
        """
        Apply a hairstyle overlay to the face image
        
        Args:
            image_data (bytes): Original image data
            landmarks (list): Facial landmarks from MediaPipe
            face_shape (str): The determined face shape
            hairstyle_index (int): Index of the hairstyle to apply (default: 0)
            
        Returns:
            bytes: Image with hairstyle overlay applied
        """
        try:
            # Convert image bytes to numpy array
            nparr = np.frombuffer(image_data, np.uint8)
            image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            # Check if we have hairstyles for this face shape
            if face_shape not in self.hairstyles or not self.hairstyles[face_shape]:
                logger.warning(f"No hairstyles found for {face_shape}, using OVAL")
                face_shape = "OVAL"
                
            # If still no hairstyles available, return the original image
            if not self.hairstyles[face_shape]:
                logger.warning(f"No hairstyles available for {face_shape}")
                _, buffer = cv2.imencode('.jpg', image)
                return buffer.tobytes()
                
            # Get the hairstyle to apply (handle index out of range)
            hairstyles_list = self.hairstyles[face_shape]
            if hairstyle_index >= len(hairstyles_list):
                hairstyle_index = 0
                
            hairstyle = hairstyles_list[hairstyle_index]['image']
            
            # Calculate head measurements based on landmarks
            head_width, head_height, head_center, head_top = self._calculate_head_measurements(landmarks)
            
            # Resize and position the hairstyle
            result_image = self._position_hairstyle(image.copy(), hairstyle, landmarks, 
                                                   head_width, head_height, head_center, head_top)
            
            # Encode the result image
            _, buffer = cv2.imencode('.jpg', result_image)
            return buffer.tobytes()
            
        except Exception as e:
            logger.error(f"Error applying hairstyle: {e}")
            # Return original image if there's an error
            _, buffer = cv2.imencode('.jpg', image)
            return buffer.tobytes()
    
    def _calculate_head_measurements(self, landmarks):
        """
        Calculate head measurements from facial landmarks
        
        Args:
            landmarks (list): Facial landmarks
            
        Returns:
            tuple: head_width, head_height, head_center, head_top
        """
        # Find forehead - landmark 10 from MediaPipe
        forehead = landmarks[10]
        
        # Find chin - landmark 152 from MediaPipe
        chin = landmarks[152]
        
        # Find temples (sides of forehead) - landmarks 67 and 296
        left_temple = landmarks[67]
        right_temple = landmarks[296]
        
        # Calculate head width (distance between temples) and add margin
        head_width = self._calculate_distance(left_temple, right_temple) * 1.5
        
        # Calculate head height (forehead to chin) and add margin for hair above forehead
        head_height = self._calculate_distance(forehead, chin) * 2.2
        
        # Calculate head center point (midpoint between temples)
        head_center = ((left_temple[0] + right_temple[0]) // 2, 
                       (left_temple[1] + right_temple[1]) // 2)
        
        # Calculate a point on top of the head (above forehead)
        head_top = (forehead[0], forehead[1] - int(head_height * 0.35))
        
        return head_width, head_height, head_center, head_top
    
    def _position_hairstyle(self, image, hairstyle, landmarks, head_width, head_height, head_center, head_top):
        """
        Resize and position hairstyle on the face
        
        Args:
            image (ndarray): Original image
            hairstyle (ndarray): Hairstyle image with alpha channel
            landmarks (list): Facial landmarks
            head_width (float): Width of the head
            head_height (float): Height of the head
            head_center (tuple): Center point of the head
            head_top (tuple): Top point of the head
            
        Returns:
            ndarray: Image with hairstyle applied
        """
        # Get image dimensions
        img_h, img_w = image.shape[:2]
        h_h, h_w = hairstyle.shape[:2]
        
        # Calculate scale factor to fit hairstyle to head width
        scale_factor = head_width / h_w
        
        # Resize hairstyle to match head width
        new_width = int(h_w * scale_factor)
        new_height = int(h_h * scale_factor)
        resized_hairstyle = cv2.resize(hairstyle, (new_width, new_height), 
                                     interpolation=cv2.INTER_AREA)
        
        # Calculate position to place hairstyle
        # Center of the hairstyle should align with head center
        x_offset = max(0, head_center[0] - resized_hairstyle.shape[1] // 2)
        y_offset = max(0, head_top[1] - resized_hairstyle.shape[0] // 2)
        
        # Ensure that hairstyle doesn't go outside the image boundaries
        x_end = min(img_w, x_offset + resized_hairstyle.shape[1])
        y_end = min(img_h, y_offset + resized_hairstyle.shape[0])
        
        # Adjust offsets if the hairstyle exceeds image boundaries
        x_offset = min(x_offset, img_w)
        y_offset = min(y_offset, img_h)
        
        # Calculate the visible portion of the hairstyle
        h_visible_width = x_end - x_offset
        h_visible_height = y_end - y_offset
        
        if h_visible_width <= 0 or h_visible_height <= 0:
            return image
        
        # Extract the visible part of the hairstyle
        hairstyle_visible = resized_hairstyle[:h_visible_height, :h_visible_width]
        
        # Create a region of interest (ROI) in the image
        roi = image[y_offset:y_end, x_offset:x_end]
        
        # Apply alpha blending
        # Extract alpha channel from hairstyle
        alpha = hairstyle_visible[:, :, 3] / 255.0
        
        # Extract BGR channels
        hairstyle_rgb = hairstyle_visible[:, :, :3]
        
        # Blend the hairstyle with the original image based on alpha values
        for c in range(3):  # RGB channels
            roi[:, :, c] = (1 - alpha) * roi[:, :, c] + alpha * hairstyle_rgb[:, :, c]
        
        # Put the ROI back in the original image
        image[y_offset:y_end, x_offset:x_end] = roi
        
        return image
    
    def _calculate_distance(self, point1, point2):
        """Calculate Euclidean distance between two points"""
        return np.sqrt((point1[0] - point2[0])**2 + (point1[1] - point2[1])**2)
        
    def create_sample_hairstyles(self):
        """
        Create sample hairstyle directories and placeholder images for testing
        This is only for development and should be replaced with real hairstyle images
        """
        for face_shape in ["oval", "round", "square", "heart", "oblong", "diamond"]:
            shape_dir = os.path.join("hairstyles", face_shape)
            if not os.path.exists(shape_dir):
                os.makedirs(shape_dir)
                
            # Create 3 placeholder hairstyles per face shape
            for i in range(1, 4):
                self._create_placeholder_hairstyle(shape_dir, f"style_{i}", (800, 800))
                
        logger.info("Created sample hairstyle placeholders")
    
    def _create_placeholder_hairstyle(self, directory, name, size):
        """
        Create a placeholder hairstyle image with transparency for testing
        
        Args:
            directory (str): Directory to save the image
            name (str): Name of the hairstyle
            size (tuple): Size of the image (width, height)
        """
        try:
            # Create a transparent image
            img = np.zeros((size[1], size[0], 4), dtype=np.uint8)
            
            # Draw a simple hairstyle shape
            cv2.rectangle(img, (200, 100), (600, 400), (0, 0, 0, 200), -1)
            cv2.rectangle(img, (250, 50), (550, 300), (0, 0, 0, 200), -1)
            
            # Save the image
            cv2.imwrite(os.path.join(directory, f"{name}.png"), img)
        except Exception as e:
            logger.error(f"Error creating placeholder: {e}")