#!/usr/bin/env python3
import re
import os
import sys

print("Начинаю исправление визуализации и улучшение дизайна...")

# Путь к файлу face_analyzer.py
file_path = 'face_analyzer.py'

# 1. Делаем бэкап файла
backup_path = file_path + '.backup'
os.system(f'cp {file_path} {backup_path}')
print(f"Создан бэкап: {backup_path}")

# 2. Читаем содержимое файла
with open(file_path, 'r') as f:
    content = f.read()

# 3. Находим и заменяем метод _create_custom_visualization
visualization_pattern = r'def _create_custom_visualization\(self, image, landmarks, face_shape\):.*?return visualization_image'
visualization_match = re.search(visualization_pattern, content, re.DOTALL)

if visualization_match:
    old_method = visualization_match.group(0)
    
    # Новая реализация метода без вопросительных знаков
    new_method = '''def _create_custom_visualization(self, image, landmarks, face_shape):
        """
        Create a custom visualization for the specific face shape
        
        Args:
            image: Original image
            landmarks: Face landmarks
            face_shape: Determined face shape
            
        Returns:
            Image with custom visualization
        """
        # Создаем копию изображения для визуализации
        visualization_image = image.copy()
        
        # Преобразуем цветовую схему
        visualization_image = cv2.cvtColor(visualization_image, cv2.COLOR_BGR2RGB)
        
        # Рисуем лицевые ориентиры
        for idx, (x, y) in enumerate(landmarks):
            x, y = int(x), int(y)
            # Рисуем точки только для основных ориентиров
            if idx in [0, 8, 16, 27, 30, 33, 36, 39, 42, 45, 48, 51, 54, 57]:
                cv2.circle(visualization_image, (x, y), 2, (0, 255, 0), -1)
        
        # Рисуем соединения между точками для создания сетки
        # Контур лица
        jaw_points = landmarks[0:17]
        for i in range(len(jaw_points) - 1):
            pt1 = (int(jaw_points[i][0]), int(jaw_points[i][1]))
            pt2 = (int(jaw_points[i + 1][0]), int(jaw_points[i + 1][1]))
            cv2.line(visualization_image, pt1, pt2, (0, 255, 0), 1)
        
        # Левая бровь
        left_brow = landmarks[17:22]
        for i in range(len(left_brow) - 1):
            pt1 = (int(left_brow[i][0]), int(left_brow[i][1]))
            pt2 = (int(left_brow[i + 1][0]), int(left_brow[i + 1][1]))
            cv2.line(visualization_image, pt1, pt2, (0, 255, 0), 1)
        
        # Правая бровь
        right_brow = landmarks[22:27]
        for i in range(len(right_brow) - 1):
            pt1 = (int(right_brow[i][0]), int(right_brow[i][1]))
            pt2 = (int(right_brow[i + 1][0]), int(right_brow[i + 1][1]))
            cv2.line(visualization_image, pt1, pt2, (0, 255, 0), 1)
        
        # Нос
        nose_bridge = landmarks[27:31]
        for i in range(len(nose_bridge) - 1):
            pt1 = (int(nose_bridge[i][0]), int(nose_bridge[i][1]))
            pt2 = (int(nose_bridge[i + 1][0]), int(nose_bridge[i + 1][1]))
            cv2.line(visualization_image, pt1, pt2, (0, 255, 0), 1)
        
        nose_tip = landmarks[31:36]
        for i in range(len(nose_tip) - 1):
            pt1 = (int(nose_tip[i][0]), int(nose_tip[i][1]))
            pt2 = (int(nose_tip[i + 1][0]), int(nose_tip[i + 1][1]))
            cv2.line(visualization_image, pt1, pt2, (0, 255, 0), 1)
        
        # Глаза
        left_eye = landmarks[36:42]
        for i in range(len(left_eye)):
            pt1 = (int(left_eye[i][0]), int(left_eye[i][1]))
            pt2 = (int(left_eye[(i + 1) % len(left_eye)][0]), int(left_eye[(i + 1) % len(left_eye)][1]))
            cv2.line(visualization_image, pt1, pt2, (0, 255, 0), 1)
        
        right_eye = landmarks[42:48]
        for i in range(len(right_eye)):
            pt1 = (int(right_eye[i][0]), int(right_eye[i][1]))
            pt2 = (int(right_eye[(i + 1) % len(right_eye)][0]), int(right_eye[(i + 1) % len(right_eye)][1]))
            cv2.line(visualization_image, pt1, pt2, (0, 255, 0), 1)
        
        # Губы
        outer_lips = landmarks[48:60]
        for i in range(len(outer_lips)):
            pt1 = (int(outer_lips[i][0]), int(outer_lips[i][1]))
            pt2 = (int(outer_lips[(i + 1) % len(outer_lips)][0]), int(outer_lips[(i + 1) % len(outer_lips)][1]))
            cv2.line(visualization_image, pt1, pt2, (0, 255, 0), 1)
        
        inner_lips = landmarks[60:68]
        for i in range(len(inner_lips)):
            pt1 = (int(inner_lips[i][0]), int(inner_lips[i][1]))
            pt2 = (int(inner_lips[(i + 1) % len(inner_lips)][0]), int(inner_lips[(i + 1) % len(inner_lips)][1]))
            cv2.line(visualization_image, pt1, pt2, (0, 255, 0), 1)
        
        # Добавляем линии для измерения пропорций
        # Измерение ширины и высоты лица
        # Ширина лица (расстояние между скулами)
        cheekbone_left = landmarks[0]
        cheekbone_right = landmarks[16]
        cv2.line(visualization_image, 
                 (int(cheekbone_left[0]), int(cheekbone_left[1])), 
                 (int(cheekbone_right[0]), int(cheekbone_right[1])), 
                 (255, 0, 0), 1)
        
        # Высота лица (от подбородка до линии роста волос)
        chin = landmarks[8]
        forehead = landmarks[27]
        cv2.line(visualization_image, 
                 (int(chin[0]), int(chin[1])), 
                 (int(forehead[0]), int(forehead[1])), 
                 (255, 0, 0), 1)
        
        # Добавляем надпись с формой лица
        face_shape_name = {
            "OVAL": "Овальное",
            "ROUND": "Круглое",
            "SQUARE": "Квадратное",
            "HEART": "Сердцевидное",
            "OBLONG": "Продолговатое",
            "DIAMOND": "Ромбовидное"
        }.get(face_shape, face_shape)
        
        font = cv2.FONT_HERSHEY_SIMPLEX
        text = f"Форма лица: {face_shape_name}"
        text_size = cv2.getTextSize(text, font, 0.7, 2)[0]
        
        # Позиция текста внизу изображения
        height, width = visualization_image.shape[:2]
        text_x = int((width - text_size[0]) / 2)
        text_y = height - 20
        
        # Добавляем полупрозрачный фон для текста
        overlay = visualization_image.copy()
        cv2.rectangle(overlay, 
                     (text_x - 10, text_y - text_size[1] - 10), 
                     (text_x + text_size[0] + 10, text_y + 10), 
                     (0, 0, 0), 
                     -1)
        
        # Накладываем с прозрачностью
        alpha = 0.6
        cv2.addWeighted(overlay, alpha, visualization_image, 1 - alpha, 0, visualization_image)
        
        # Рисуем текст белым цветом
        cv2.putText(visualization_image, text, (text_x, text_y), font, 0.7, (255, 255, 255), 2)
        
        return visualization_image'''
    
    # Заменяем старый метод на новый
    content = content.replace(old_method, new_method)
    print("Метод _create_custom_visualization обновлен")
else:
    print("Не удалось найти метод _create_custom_visualization")

# 4. Ищем и исправляем любые строки с вопросительными знаками
question_marks_pattern = r'"(\?+)"'
content = re.sub(question_marks_pattern, '"Анализ лица"', content)

# 5. Сохраняем измененный файл
with open(file_path, 'w') as f:
    f.write(content)

print("Файл face_analyzer.py обновлен")

# 6. Теперь улучшим сообщения в bot.py
bot_file_path = 'bot.py'
os.system(f'cp {bot_file_path} {bot_file_path}.backup')
print(f"Создан бэкап: {bot_file_path}.backup")

# Читаем содержимое bot.py
with open(bot_file_path, 'r') as f:
    bot_content = f.read()

# 7. Улучшаем сообщение анализа
try:
    # Ищем шаблон сообщения анализа
    analysis_patterns = [
        r'caption = \(\s+f"[^"]*"\s+f"[^"]*"\s+f"[^"]*"\s+\)',
        r'caption = f"[^"]*"',
        r'caption = \(\s+.*?\s+\)'
    ]
    
    for pattern in analysis_patterns:
        analysis_match = re.search(pattern, bot_content, re.DOTALL)
        if analysis_match:
            old_caption = analysis_match.group(0)
            new_caption = '''caption = (
            f"✅ *Анализ завершен!*\\n\\n"
            f"📊 *Форма твоего лица: {face_shape}*\\n\\n"
            f"{face_shape_description}\\n\\n"
            f"💇‍♀️ *Рекомендуемые прически:*\\n{recommendations}\\n\\n"
            f"• Для виртуальной примерки прически, используй /try\\n"
            f"• Для просмотра всех доступных причесок, используй /hairstyles"
        )'''
            
            bot_content = bot_content.replace(old_caption, new_caption)
            print("Улучшено сообщение анализа")
            break
    else:
        print("Не удалось найти шаблон сообщения анализа, попробуем другой подход...")
        
        # Альтернативный подход: ищем метод process_photo
        process_photo_pattern = r'def process_photo\(self, message\):.*?except Exception as e:'
        process_photo_match = re.search(process_photo_pattern, bot_content, re.DOTALL)
        
        if process_photo_match:
            process_photo_code = process_photo_match.group(0)
            
            # Ищем строки с caption внутри метода
            caption_lines = re.findall(r'caption = .*', process_photo_code)
            if caption_lines:
                old_caption_line = caption_lines[0]
                new_caption_line = '''caption = (
            f"✅ *Анализ завершен!*\\n\\n"
            f"📊 *Форма твоего лица: {face_shape}*\\n\\n"
            f"{face_shape_description}\\n\\n"
            f"💇‍♀️ *Рекомендуемые прически:*\\n{recommendations}\\n\\n"
            f"• Для виртуальной примерки прически, используй /try\\n"
            f"• Для просмотра всех доступных причесок, используй /hairstyles"
        )'''
                
                updated_process_photo = process_photo_code.replace(old_caption_line, new_caption_line)
                bot_content = bot_content.replace(process_photo_code, updated_process_photo)
                print("Улучшено сообщение анализа (альтернативный метод)")
            else:
                print("Не удалось найти строки с caption в методе process_photo")
        else:
            print("Не удалось найти метод process_photo")
except Exception as e:
    print(f"Ошибка при улучшении сообщения анализа: {e}")

# 8. Сохраняем изменения в bot.py
with open(bot_file_path, 'w') as f:
    f.write(bot_content)

print("Файл bot.py обновлен")

# 9. Создаем скрипт для перезапуска бота
restart_script = '''#!/bin/bash
# Удаляем webhook
python3 -c "import telebot; import os; from config import BOT_TOKEN; bot = telebot.TeleBot(BOT_TOKEN); print(f'Webhook removed: {bot.remove_webhook()}')"

# Перезапускаем бота
sudo supervisorctl restart faceform_bot_polling

# Проверяем статус
sudo supervisorctl status faceform_bot_polling

# Выводим последние логи
sudo tail -n 20 /var/log/faceform_bot/stderr_polling.log
'''

restart_path = 'restart_bot.sh'
with open(restart_path, 'w') as f:
    f.write(restart_script)

os.system(f'chmod +x {restart_path}')
print(f"Создан скрипт для перезапуска бота: {restart_path}")

print("\nГотово! Теперь выполните: ./restart_bot.sh")

# Если передан аргумент --run, автоматически запускаем скрипт перезапуска
if len(sys.argv) > 1 and sys.argv[1] == '--run':
    print("\nАвтоматически запускаем скрипт перезапуска...")
    os.system('./restart_bot.sh')