#!/usr/bin/env python3
import logging
import sys
import time
import psutil
import os
from bot import FaceShapeBot

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

def check_process_memory():
    """Проверка использования памяти процессом"""
    process = psutil.Process(os.getpid())
    memory_info = process.memory_info()
    memory_mb = memory_info.rss / 1024 / 1024
    logger.info(f"Memory usage: {memory_mb:.2f} MB")
    return memory_mb

def main():
    """Запуск бота в режиме polling"""
    logger.info("Starting FaceShape Bot in polling mode")
    
    max_memory_mb = 1500  # Максимальное использование памяти в MB
    max_uptime_hours = 12  # Максимальное время работы в часах
    
    bot = FaceShapeBot(use_webhook=False)
    
    # Запускаем бота
    start_time = time.time()
    bot.run()
    
    # Цикл перезапуска при достижении лимитов (никогда не выполнится из-за бесконечного цикла в run())
    while True:
        # Проверка времени работы
        uptime_hours = (time.time() - start_time) / 3600
        if uptime_hours >= max_uptime_hours:
            logger.info(f"Max uptime of {max_uptime_hours} hours reached, restarting")
            break
        
        # Проверка использования памяти
        memory_mb = check_process_memory()
        if memory_mb >= max_memory_mb:
            logger.info(f"Memory usage of {memory_mb:.2f} MB exceeds limit of {max_memory_mb} MB, restarting")
            break
        
        time.sleep(300)  # Проверка каждые 5 минут

if __name__ == "__main__":
    main()