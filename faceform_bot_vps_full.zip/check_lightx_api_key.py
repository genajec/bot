import requests
import logging
import sys

# Настраиваем логирование
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def check_api_key(api_key):
    """
    Проверяет работоспособность API ключа LightX
    
    Args:
        api_key (str): API ключ для проверки
        
    Returns:
        bool: True если ключ работает, False если нет
    """
    logger.info(f"Проверка API ключа LightX: {api_key}")
    
    # Самый простой запрос - получение URL для загрузки изображения
    try:
        # API endpoint
        url = "https://api.lightxeditor.com/external/api/v2/uploadImageUrl"
        
        # Заголовки
        headers = {
            "Content-Type": "application/json",
            "x-api-key": api_key
        }
        
        # Тестовые данные
        data = {
            "uploadType": "imageUrl",
            "size": 1024,
            "contentType": "image/jpeg"
        }
        
        # Отправка запроса
        logger.info("Отправка тестового запроса к LightX API...")
        response = requests.post(url, headers=headers, json=data)
        
        # Проверка ответа
        logger.info(f"Код ответа: {response.status_code}")
        logger.info(f"Ответ: {response.text}")
        
        # Анализ ответа
        if response.status_code == 200:
            result = response.json()
            if result.get("statusCode") == 2000:
                logger.info("✅ API ключ работает корректно!")
                return True
            else:
                logger.error(f"❌ API вернул ошибку: {result.get('message', 'Неизвестная ошибка')}")
                logger.error(f"Статус код API: {result.get('statusCode')}")
                return False
        else:
            logger.error(f"❌ Ошибка HTTP: {response.status_code}")
            return False
            
    except Exception as e:
        logger.error(f"❌ Ошибка при проверке API ключа: {e}")
        return False

if __name__ == "__main__":
    # Проверяем ключ, указанный в аргументах, или используем тестовый
    api_key = sys.argv[1] if len(sys.argv) > 1 else "5bf93ecbebf740c592ed2ad0d0c992f3_ca6160cc72394be7b9ebc13f66a53925_andoraitools"
    
    # Проверяем ключ
    if check_api_key(api_key):
        print("✅ API ключ работает корректно!")
        sys.exit(0)
    else:
        print("❌ API ключ не работает или исчерпаны кредиты!")
        sys.exit(1)