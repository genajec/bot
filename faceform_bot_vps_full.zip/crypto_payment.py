import os
import logging
import requests
import json
import uuid
from datetime import datetime
import hmac
import hashlib

# Настраиваем логирование
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class CryptoPayment:
    """Класс для работы с криптоплатежами через CryptoCloud API"""
    
    def __init__(self):
        """Инициализация объекта для работы с криптоплатежами"""
        self.api_key = os.environ.get("CRYPTOCOUD_API_KEY")
        self.api_secret = os.environ.get("CRYPTOCOUD_API_SECRET")
        self.shop_id = os.environ.get("CRYPTOCOUD_SHOP_ID")
        
        if not self.api_key or not self.api_secret or not self.shop_id:
            logger.warning("Отсутствуют ключи CryptoCloud API. Платежи будут работать в тестовом режиме.")
            # В тестовом режиме используем фиктивные ключи
            self.api_key = "test_key"
            self.api_secret = "test_secret"
            self.shop_id = "test_shop"
            
        # API endpoint
        self.api_url = "https://api.cryptocloud.plus/v1"
        
        # Тарифные планы
        self.credit_packages = [
            {"id": "basic", "credits": 5, "price": 0.40, "description": "Базовый пакет: 5 кредитов"},
            {"id": "standard", "credits": 10, "price": 0.9, "description": "Стандартный пакет: 10 кредитов"},
            {"id": "premium", "credits": 20, "price": 1.7, "description": "Премиум пакет: 20 кредитов"}
        ]
        
    def get_credit_packages(self):
        """Получить доступные пакеты кредитов"""
        return self.credit_packages
    
    def generate_signature(self, data):
        """
        Генерация подписи для API запроса
        
        Args:
            data (dict): Данные для подписи
            
        Returns:
            str: Подпись запроса
        """
        if self.api_secret == "test_secret":
            # В тестовом режиме просто возвращаем тестовую подпись
            return "test_signature"
            
        # Сортируем ключи в алфавитном порядке
        sorted_data = dict(sorted(data.items()))
        
        # Сериализуем данные в строку
        data_string = json.dumps(sorted_data, separators=(',', ':'))
        
        # Создаем HMAC подпись с использованием SHA256
        signature = hmac.new(
            self.api_secret.encode('utf-8'),
            data_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        
        return signature
    
    def create_payment(self, amount, package_id, telegram_id):
        """
        Создание платежа в CryptoCloud
        
        Args:
            amount (float): Сумма платежа в долларах
            package_id (str): ID пакета кредитов
            telegram_id (int): Telegram ID пользователя
            
        Returns:
            dict: Информация о созданном платеже или None в случае ошибки
        """
        try:
            # Формируем уникальный ID заказа
            order_id = f"FaceForm_{telegram_id}_{uuid.uuid4().hex[:8]}_{int(datetime.now().timestamp())}"
            
            # Формируем данные для запроса
            payment_data = {
                "shop_id": self.shop_id,
                "amount": amount,
                "currency": "USD",
                "order_id": order_id,
                "email": f"{telegram_id}@telegram.user",  # Используем ID как email
                "description": f"Покупка пакета кредитов {package_id} для FaceForm бота",
                "success_url": f"https://t.me/Faceform_bot?start=success_{order_id}",
                "fail_url": f"https://t.me/Faceform_bot?start=fail_{order_id}",
                "metadata": {
                    "telegram_id": telegram_id,
                    "package_id": package_id
                }
            }
            
            # В тестовом режиме просто возвращаем тестовые данные
            if self.api_key == "test_key":
                logger.info(f"Тестовый режим: создан платеж для пользователя {telegram_id} на сумму {amount}$")
                return {
                    "payment_id": f"test_payment_{order_id}",
                    "payment_url": f"https://example.com/pay/test_{order_id}",
                    "amount": amount,
                    "currency": "USD",
                    "status": "pending",
                    "test_mode": True
                }
            
            # Генерируем подпись
            signature = self.generate_signature(payment_data)
            
            # Формируем заголовки
            headers = {
                "Content-Type": "application/json",
                "X-API-KEY": self.api_key,
                "X-API-SIGNATURE": signature
            }
            
            # Отправляем запрос на создание платежа
            response = requests.post(
                f"{self.api_url}/invoice/create",
                headers=headers,
                json=payment_data
            )
            
            # Проверяем ответ
            if response.status_code != 200:
                logger.error(f"Ошибка при создании платежа: {response.status_code} - {response.text}")
                return None
                
            # Парсим ответ
            result = response.json()
            
            if result.get("status") != "success":
                logger.error(f"Ошибка при создании платежа: {result}")
                return None
                
            payment_info = result.get("data", {})
            logger.info(f"Создан платеж для пользователя {telegram_id} на сумму {amount}$: {payment_info}")
            
            return payment_info
            
        except Exception as e:
            logger.error(f"Ошибка при создании платежа: {e}")
            return None
            
    def check_payment_status(self, payment_id):
        """
        Проверка статуса платежа
        
        Args:
            payment_id (str): ID платежа
            
        Returns:
            str: Статус платежа ('pending', 'completed', 'failed') или None в случае ошибки
        """
        try:
            # В тестовом режиме просто возвращаем статус 'completed'
            if self.api_key == "test_key" or payment_id.startswith("test_payment_"):
                logger.info(f"Тестовый режим: платеж {payment_id} имеет статус 'completed'")
                return "completed"
                
            # Формируем данные для запроса
            data = {
                "shop_id": self.shop_id,
                "payment_id": payment_id
            }
            
            # Генерируем подпись
            signature = self.generate_signature(data)
            
            # Формируем заголовки
            headers = {
                "Content-Type": "application/json",
                "X-API-KEY": self.api_key,
                "X-API-SIGNATURE": signature
            }
            
            # Отправляем запрос на проверку статуса платежа
            response = requests.post(
                f"{self.api_url}/invoice/status",
                headers=headers,
                json=data
            )
            
            # Проверяем ответ
            if response.status_code != 200:
                logger.error(f"Ошибка при проверке статуса платежа: {response.status_code} - {response.text}")
                return None
                
            # Парсим ответ
            result = response.json()
            
            if result.get("status") != "success":
                logger.error(f"Ошибка при проверке статуса платежа: {result}")
                return None
                
            payment_status = result.get("data", {}).get("status")
            logger.info(f"Статус платежа {payment_id}: {payment_status}")
            
            # Преобразуем статус платежа в наш формат
            if payment_status == "paid":
                return "completed"
            elif payment_status == "cancelled" or payment_status == "expired":
                return "failed"
            else:
                return "pending"
                
        except Exception as e:
            logger.error(f"Ошибка при проверке статуса платежа: {e}")
            return None