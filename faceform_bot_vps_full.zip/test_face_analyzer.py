import cv2
import os
from face_analyzer import FaceAnalyzer
from hairstyle_recommender import HairstyleRecommender
import sys

# Установите модуль конфигурации для тестирования
sys.modules['config'] = __import__('config_test')
from config_test import FACE_SHAPE_CRITERIA

def main():
    """
    Скрипт для тестирования анализа лица без Telegram бота
    """
    print("Запуск тестирования анализатора формы лица...")
    
    # Инициализация анализатора и рекомендателя
    analyzer = FaceAnalyzer()
    recommender = HairstyleRecommender()
    
    # Проверка наличия изображений
    assets_dir = "attached_assets"
    if not os.path.exists(assets_dir):
        print(f"Ошибка: Папка {assets_dir} не найдена")
        return
    
    # Перебор всех изображений в папке assets
    image_files = [f for f in os.listdir(assets_dir) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
    
    if not image_files:
        print(f"Ошибка: Изображения не найдены в папке {assets_dir}")
        return
    
    for image_file in image_files:
        image_path = os.path.join(assets_dir, image_file)
        print(f"\nАнализ изображения: {image_file}")
        
        # Загрузка изображения
        try:
            with open(image_path, 'rb') as file:
                image_data = file.read()
            
            # Анализ формы лица
            face_shape, vis_image, measurements = analyzer.analyze_face_shape(image_data)
            
            if face_shape:
                print(f"Определена форма лица: {face_shape}")
                if measurements:
                    print("Измерения:")
                    for key, value in measurements.items():
                        print(f"  - {key}: {value:.2f}")
                
                # Получение рекомендаций
                face_shape_desc, recommendations = recommender.get_recommendations(face_shape)
                print(f"\nОписание: {face_shape_desc}")
                print("Рекомендации:")
                for rec in recommendations:
                    print(f"  {rec}")
                
                # Сохранение визуализации
                if vis_image:
                    vis_image_path = f"vis_{image_file}"
                    with open(vis_image_path, 'wb') as f:
                        f.write(vis_image)
                    print(f"Визуализация сохранена в файл: {vis_image_path}")
            else:
                print("Не удалось определить форму лица на изображении.")
                
        except Exception as e:
            print(f"Ошибка при обработке изображения {image_file}: {e}")
    
    print("\nТестирование завершено.")

if __name__ == "__main__":
    main()