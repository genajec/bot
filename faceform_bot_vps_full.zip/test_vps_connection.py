#!/usr/bin/env python
"""
Скрипт для проверки подключения к Telegram API и тестирования бота на VPS
"""

import os
import sys
import logging
import telebot
from dotenv import load_dotenv

# Загружаем переменные окружения из .env файла
load_dotenv()

# Настраиваем логирование
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def test_telegram_connection():
    """
    Проверка подключения к Telegram API
    """
    # Получаем токен из переменных окружения
    token = os.environ.get("TELEGRAM_API_TOKEN")
    if not token:
        logger.error("TELEGRAM_API_TOKEN не найден в переменных окружения!")
        return False
    
    logger.info("Проверка подключения к Telegram API...")
    
    try:
        # Создаем экземпляр бота
        bot = telebot.TeleBot(token)
        
        # Получаем информацию о боте
        bot_info = bot.get_me()
        
        logger.info(f"Подключение успешно! Информация о боте:")
        logger.info(f"ID: {bot_info.id}")
        logger.info(f"Имя: {bot_info.first_name}")
        logger.info(f"Имя пользователя: @{bot_info.username}")
        
        return True
    except Exception as e:
        logger.error(f"Ошибка при подключении к Telegram API: {e}")
        return False

def test_webhook_status():
    """
    Проверка статуса webhook
    """
    # Получаем токен из переменных окружения
    token = os.environ.get("TELEGRAM_API_TOKEN")
    if not token:
        logger.error("TELEGRAM_API_TOKEN не найден в переменных окружения!")
        return False
    
    logger.info("Проверка статуса webhook...")
    
    try:
        # Создаем экземпляр бота
        bot = telebot.TeleBot(token)
        
        # Получаем информацию о webhook
        webhook_info = bot.get_webhook_info()
        
        if webhook_info.url:
            logger.warning(f"Обнаружен активный webhook URL: {webhook_info.url}")
            logger.warning("Для работы в режиме polling необходимо удалить webhook!")
            
            # Спрашиваем пользователя, хочет ли он удалить webhook
            response = input("Хотите удалить webhook? (y/n): ")
            if response.lower() == 'y':
                bot.delete_webhook()
                logger.info("Webhook успешно удален")
                return True
            else:
                logger.info("Webhook не был удален")
                return False
        else:
            logger.info("Webhook не установлен. Готово для режима polling.")
            return True
    except Exception as e:
        logger.error(f"Ошибка при проверке статуса webhook: {e}")
        return False

def test_api_keys():
    """
    Проверка наличия всех необходимых API ключей
    """
    required_keys = [
        "TELEGRAM_API_TOKEN",
        "LIGHTX_API_KEY"
    ]
    
    optional_keys = [
        "CRYPTO_BOT_TOKEN",
        "STRIPE_SECRET_KEY",
        "STRIPE_PUBLIC_KEY",
        "DEEPL_API_KEY"
    ]
    
    logger.info("Проверка API ключей...")
    
    # Проверяем обязательные ключи
    missing_required = []
    for key in required_keys:
        if not os.environ.get(key):
            missing_required.append(key)
    
    # Проверяем опциональные ключи
    missing_optional = []
    for key in optional_keys:
        if not os.environ.get(key):
            missing_optional.append(key)
    
    # Выводим результаты
    if missing_required:
        logger.error(f"Отсутствуют обязательные API ключи: {', '.join(missing_required)}")
        logger.error("Бот не сможет корректно работать без этих ключей!")
        return False
    else:
        logger.info("Все обязательные API ключи найдены")
    
    if missing_optional:
        logger.warning(f"Отсутствуют опциональные API ключи: {', '.join(missing_optional)}")
        logger.warning("Некоторые функции бота могут быть недоступны")
    else:
        logger.info("Все опциональные API ключи найдены")
    
    return len(missing_required) == 0

def main():
    """
    Основная функция для запуска тестов
    """
    logger.info("Запуск тестов подключения для FaceForm бота на VPS")
    
    # Проверка API ключей
    keys_result = test_api_keys()
    
    # Проверка подключения к Telegram API
    connection_result = test_telegram_connection()
    
    # Проверка статуса webhook
    webhook_result = test_webhook_status()
    
    # Выводим итоговый результат
    if keys_result and connection_result and webhook_result:
        logger.info("Все тесты пройдены успешно! Бот готов к запуску в режиме polling.")
        return 0
    else:
        logger.error("Некоторые тесты не пройдены. Исправьте ошибки перед запуском бота.")
        return 1

if __name__ == "__main__":
    sys.exit(main())