"""
Скрипт для тестирования функции проверки незавершенных платежей 
"""
import logging
import os
import sys
import time
from pathlib import Path

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('logs/payment_check.log')
    ]
)

logger = logging.getLogger(__name__)

# Подключаем необходимые модули
from stripe_payment import StripePayment
from database import Session, Transaction, User

def test_pending_payments():
    """
    Тестирует функцию проверки незавершенных платежей
    """
    logger.info("Тестируем проверку незавершенных платежей...")
    
    # Создаем экземпляр StripePayment
    stripe_payment = StripePayment()
    
    # Проверяем незавершенные платежи
    processed_count = stripe_payment.check_pending_payments()
    
    logger.info(f"Обработано платежей: {processed_count}")
    
    # Выводим текущие незавершенные транзакции
    db_session = Session()
    try:
        pending_transactions = db_session.query(Transaction).filter(
            Transaction.status.in_(['pending', 'pending_webhook'])
        ).all()
        
        logger.info(f"Найдено {len(pending_transactions)} незавершенных транзакций в базе данных")
        
        # Выводим информацию о первых 5 транзакциях
        for i, tx in enumerate(pending_transactions[:5]):
            logger.info(f"Транзакция {i+1}: ID={tx.id}, payment_id={tx.payment_id}, telegram_id={tx.telegram_id}, " 
                        f"status={tx.status}, created_at={tx.created_at}, " 
                        f"updated_at={tx.updated_at}, amount={tx.amount}, credits={tx.credits}")
            
            # Пробуем проверить статус через Stripe API
            logger.info(f"Проверяем статус платежа {tx.payment_id} через API...")
            payment_data = stripe_payment.get_payment_data(tx.payment_id)
            
            if payment_data:
                logger.info(f"Получены данные платежа: {payment_data}")
            else:
                logger.warning(f"Не удалось получить данные платежа {tx.payment_id}")
                
    finally:
        db_session.close()

if __name__ == "__main__":
    logger.info("Запуск скрипта для проверки незавершенных платежей...")
    test_pending_payments()
    logger.info("Скрипт завершил работу")