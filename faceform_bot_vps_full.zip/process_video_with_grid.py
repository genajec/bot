import cv2
import logging
import tempfile
import os
import numpy as np
import mediapipe as mp

# Настройка логирования
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def calculate_distance(point1, point2):
    """Calculate Euclidean distance between two points"""
    return np.sqrt((point1[0] - point2[0]) ** 2 + (point1[1] - point2[1]) ** 2)

def determine_face_shape(width_to_length_ratio, forehead_to_jawline_ratio, cheekbone_to_jawline_ratio):
    """
    Determine face shape based on facial measurements and ratios using a scoring system
    """
    # Scores for each face shape based on different ratios
    scores = {
        "OVAL": 0,
        "ROUND": 0,
        "SQUARE": 0,
        "HEART": 0,
        "OBLONG": 0,
        "DIAMOND": 0
    }
    
    # Width to length ratio scoring
    if 0.7 <= width_to_length_ratio <= 0.75:
        scores["OVAL"] += 2
        scores["OBLONG"] += 1
    elif width_to_length_ratio < 0.7:
        scores["OBLONG"] += 3
    elif 0.75 < width_to_length_ratio <= 0.8:
        scores["OVAL"] += 2
        scores["SQUARE"] += 1
        scores["DIAMOND"] += 1
    elif 0.8 < width_to_length_ratio <= 0.85:
        scores["ROUND"] += 2
        scores["SQUARE"] += 2
    elif width_to_length_ratio > 0.85:
        scores["ROUND"] += 3
    
    # Forehead to jawline ratio scoring
    if 0.9 <= forehead_to_jawline_ratio <= 1.1:
        scores["OVAL"] += 2
        scores["SQUARE"] += 2
    elif forehead_to_jawline_ratio < 0.9:
        scores["HEART"] += 3
        scores["DIAMOND"] += 1
    elif forehead_to_jawline_ratio > 1.1:
        scores["DIAMOND"] += 2
        scores["OBLONG"] += 1
    
    # Cheekbone to jawline ratio scoring
    if 1.0 <= cheekbone_to_jawline_ratio <= 1.1:
        scores["SQUARE"] += 2
    elif cheekbone_to_jawline_ratio < 1.0:
        scores["ROUND"] += 1
    elif 1.1 < cheekbone_to_jawline_ratio <= 1.2:
        scores["OVAL"] += 1
        scores["DIAMOND"] += 1
    elif 1.2 < cheekbone_to_jawline_ratio <= 1.3:
        scores["HEART"] += 2
        scores["DIAMOND"] += 2
    elif cheekbone_to_jawline_ratio > 1.3:
        scores["HEART"] += 3
        scores["DIAMOND"] += 1
    
    # Determine the face shape with the highest score
    max_score = 0
    face_shape = "OVAL"  # Default
    
    for shape, score in scores.items():
        if score > max_score:
            max_score = score
            face_shape = shape
    
    logger.info(f"FACE SHAPE SCORES: {scores}")
    return face_shape, scores

def process_video_with_grid(video_data):
    """
    Process video frame by frame, add facial landmarks grid, and return processed video
    
    Args:
        video_data: Video file bytes
        
    Returns:
        bytes: Processed video with facial landmarks visualization
    """
    # Создаем временные файлы для входного и выходного видео
    with tempfile.NamedTemporaryFile(suffix='.mp4', delete=False) as input_video_file:
        input_video_path = input_video_file.name
        input_video_file.write(video_data)
    
    output_video_path = input_video_path + "_output.mp4"
    
    # Откроем видео с помощью OpenCV
    cap = cv2.VideoCapture(input_video_path)
    if not cap.isOpened():
        return None
    
    # Получаем параметры видео
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    # Инициализируем медиапайп
    mp_face_mesh = mp.solutions.face_mesh
    face_mesh = mp_face_mesh.FaceMesh(
        static_image_mode=False,
        max_num_faces=1,
        min_detection_confidence=0.5
    )
    
    # Создаем VideoWriter для записи выходного видео
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_video_path, fourcc, fps, (width, height))
    
    # Обрабатываем каждый кадр видео
    frame_count = 0
    face_shape_counts = {"OVAL": 0, "ROUND": 0, "SQUARE": 0, "HEART": 0, "OBLONG": 0, "DIAMOND": 0}
    total_scores = {"OVAL": 0, "ROUND": 0, "SQUARE": 0, "HEART": 0, "OBLONG": 0, "DIAMOND": 0}
    frames_with_face = 0
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        # Конвертируем BGR в RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # Обнаруживаем лицевые ориентиры
        results = face_mesh.process(rgb_frame)
        
        # Определяем форму лица для текущего кадра
        current_face_shape = None
        
        if results.multi_face_landmarks:
            frames_with_face += 1
            landmarks = results.multi_face_landmarks[0]
            
            # Визуализируем сетку лицевых ориентиров
            for landmark in landmarks.landmark:
                x = int(landmark.x * width)
                y = int(landmark.y * height)
                cv2.circle(frame, (x, y), 1, (0, 255, 0), -1)
            
            # Соединяем точки, чтобы создать сетку
            connections = mp_face_mesh.FACEMESH_TESSELATION
            for connection in connections:
                start_idx = connection[0]
                end_idx = connection[1]
                
                start_point = landmarks.landmark[start_idx]
                end_point = landmarks.landmark[end_idx]
                
                start_x = int(start_point.x * width)
                start_y = int(start_point.y * height)
                
                end_x = int(end_point.x * width)
                end_y = int(end_point.y * height)
                
                cv2.line(frame, (start_x, start_y), (end_x, end_y), (0, 255, 0), 1)
                
            # Вычисляем пропорции лица
            landmarks_list = [[landmark.x * width, landmark.y * height] for landmark in landmarks.landmark]
            
            # Измерение ширины и высоты лица
            face_width = calculate_distance(landmarks_list[234], landmarks_list[454])  # Расстояние между скулами
            face_length = calculate_distance(landmarks_list[10], landmarks_list[152])  # Расстояние от подбородка до лба
            
            # Измерение ширины лба и челюсти
            forehead_width = calculate_distance(landmarks_list[346], landmarks_list[67])  # Ширина лба
            jawline_width = calculate_distance(landmarks_list[172], landmarks_list[397])  # Ширина челюсти
            
            # Измерение ширины скул и челюсти
            cheekbone_width = face_width  # Уже рассчитали выше
            
            # Рассчитываем соотношения
            width_to_length_ratio = face_width / face_length if face_length > 0 else 0
            forehead_to_jawline_ratio = forehead_width / jawline_width if jawline_width > 0 else 0
            cheekbone_to_jawline_ratio = cheekbone_width / jawline_width if jawline_width > 0 else 0
            
            # Определяем форму лица
            current_face_shape, shape_scores = determine_face_shape(
                width_to_length_ratio, 
                forehead_to_jawline_ratio, 
                cheekbone_to_jawline_ratio
            )
            
            # Накапливаем счетчики и баллы
            if current_face_shape:
                face_shape_counts[current_face_shape] += 1
                
                # Добавляем баллы в общую сумму
                for shape, score in shape_scores.items():
                    total_scores[shape] += score
                
                # Добавляем текст с информацией о форме лица
                cv2.putText(
                    frame, 
                    f"Face Shape: {current_face_shape}", 
                    (10, 30), 
                    cv2.FONT_HERSHEY_SIMPLEX, 
                    1, 
                    (0, 0, 255), 
                    2
                )
                
                # Добавляем пропорции
                cv2.putText(
                    frame, 
                    f"W/L: {width_to_length_ratio:.2f}, F/J: {forehead_to_jawline_ratio:.2f}, C/J: {cheekbone_to_jawline_ratio:.2f}", 
                    (10, 70), 
                    cv2.FONT_HERSHEY_SIMPLEX, 
                    0.7, 
                    (0, 0, 255), 
                    2
                )
        
        # Запишем обработанный кадр в выходное видео
        out.write(frame)
        
        # Выводим прогресс
        frame_count += 1
        if frame_count % 10 == 0:
            logger.info(f"Processed {frame_count}/{total_frames} frames ({frame_count*100/total_frames:.1f}%)")
    
    # Освобождаем ресурсы
    cap.release()
    out.release()
    face_mesh.close()
    
    # Нормализуем суммарные баллы по всем кадрам
    normalized_scores = {}
    total_score_sum = sum(total_scores.values())
    if total_score_sum > 0:
        for shape, score in total_scores.items():
            normalized_scores[shape] = (score / total_score_sum) * 100
    
    # Определяем наиболее частую форму лица в видео
    most_common_shape = max(face_shape_counts.items(), key=lambda x: x[1])[0] if any(face_shape_counts.values()) else "Unknown"
    
    # Добавляем статистику в конце видео
    cap = cv2.VideoCapture(output_video_path)
    final_video_path = input_video_path + "_final.mp4"
    final_out = cv2.VideoWriter(final_video_path, fourcc, fps, (width, height))
    
    # Копируем все кадры из промежуточного видео
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        final_out.write(frame)
    
    # Создаем финальный кадр с результатами
    result_frame = np.zeros((height, width, 3), dtype=np.uint8)
    
    # Добавляем заголовок с результатом
    cv2.putText(
        result_frame, 
        f"Итоговый анализ формы лица: {most_common_shape}", 
        (width//2 - 250, 50), 
        cv2.FONT_HERSHEY_SIMPLEX, 
        1, 
        (255, 255, 255), 
        2
    )
    
    # Добавляем статистику по детекции лица в кадрах
    cv2.putText(
        result_frame, 
        f"Лицо обнаружено в {frames_with_face} из {frame_count} кадров ({frames_with_face*100/frame_count:.1f}%)", 
        (width//2 - 300, 100), 
        cv2.FONT_HERSHEY_SIMPLEX, 
        0.8, 
        (255, 255, 255), 
        1
    )
    
    # Добавляем статистику по распределению форм лица
    y_pos = 150
    cv2.putText(
        result_frame, 
        "Распределение форм лица по кадрам:", 
        (width//2 - 200, y_pos), 
        cv2.FONT_HERSHEY_SIMPLEX, 
        0.8, 
        (255, 255, 255), 
        1
    )
    y_pos += 40
    
    for shape, count in face_shape_counts.items():
        percentage = count * 100 / frames_with_face if frames_with_face > 0 else 0
        if percentage > 0:
            cv2.putText(
                result_frame, 
                f"{shape}: {percentage:.1f}%", 
                (width//2 - 150, y_pos), 
                cv2.FONT_HERSHEY_SIMPLEX, 
                0.8, 
                (255, 255, 255), 
                1
            )
            y_pos += 30
    
    # Добавляем статистику по общим баллам
    y_pos += 20
    cv2.putText(
        result_frame, 
        "Распределение баллов по формам лица:", 
        (width//2 - 200, y_pos), 
        cv2.FONT_HERSHEY_SIMPLEX, 
        0.8, 
        (255, 255, 255), 
        1
    )
    y_pos += 40
    
    for shape, percentage in normalized_scores.items():
        if percentage > 0:
            cv2.putText(
                result_frame, 
                f"{shape}: {percentage:.1f}%", 
                (width//2 - 150, y_pos), 
                cv2.FONT_HERSHEY_SIMPLEX, 
                0.8, 
                (255, 255, 255), 
                1
            )
            y_pos += 30
    
    # Добавляем финальный кадр в течение 5 секунд (fps * 5 кадров)
    for _ in range(int(fps * 5)):
        final_out.write(result_frame)
    
    # Освобождаем ресурсы
    cap.release()
    final_out.release()
    
    # Читаем готовое видео в байты
    with open(final_video_path, 'rb') as f:
        processed_video_bytes = f.read()
    
    # Удаляем временные файлы
    try:
        os.remove(input_video_path)
        os.remove(output_video_path)
        os.remove(final_video_path)
    except:
        pass
    
    return processed_video_bytes

if __name__ == "__main__":
    # Этот блок позволяет тестировать функцию отдельно
    print("Модуль обработки видео с сеткой лицевых ориентиров")
    print("Используйте функцию process_video_with_grid() для обработки видео")