#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging
import requests
import io
import sys
import os
from lightx_client import LightXClient
from PIL import Image

# Enable logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

def translate_with_deepl(text, source_lang="RU", target_lang="EN"):
    """
    Переводит текст с помощью DeepL API
    
    Args:
        text (str): Исходный текст для перевода
        source_lang (str): Язык исходного текста (по умолчанию "RU" - русский)
        target_lang (str): Язык, на который нужно перевести (по умолчанию "EN" - английский)
        
    Returns:
        str: Переведенный текст или None при ошибке
    """
    try:
        # Ключ API DeepL
        api_key = "7fe9dd7a-990a-4bf1-86af-a216b1b993a1:fx"
        
        # URL DeepL API
        url = "https://api-free.deepl.com/v2/translate"
        
        # Данные для запроса
        data = {
            "text": [text],
            "source_lang": source_lang,
            "target_lang": target_lang
        }
        
        # Заголовки с ключом API
        headers = {
            "Authorization": f"DeepL-Auth-Key {api_key}",
            "Content-Type": "application/json"
        }
        
        logger.info(f"Sending translation request to DeepL API for text: '{text}'")
        
        # Отправляем запрос
        response = requests.post(url, json=data, headers=headers)
        
        # Подробное логирование ответа для отладки
        logger.info(f"DeepL API response status: {response.status_code}")
        
        # Проверяем успешность запроса
        if response.status_code == 200:
            result = response.json()
            logger.info(f"DeepL API response: {result}")
            
            if "translations" in result and len(result["translations"]) > 0:
                translated_text = result["translations"][0]["text"]
                logger.info(f"DeepL translation successful: '{text}' -> '{translated_text}'")
                return translated_text
            else:
                logger.warning(f"DeepL API returned 200 but no translations found in response: {result}")
        
        # Если запрос неуспешен или ответ не содержит перевода,
        # логируем ошибку и возвращаем None
        logger.warning(f"DeepL API error: {response.status_code} - {response.text}")
        return None
    except Exception as e:
        logger.error(f"Error in DeepL API: {e}")
        return None

def main():
    # Получаем путь к изображению и описание фона
    if len(sys.argv) < 2:
        print("Использование: python test_background_change.py <путь_к_изображению> [описание_фона]")
        print("Пример: python test_background_change.py demo_base_face.jpg 'Пляж на закате'")
        return
    
    image_path = sys.argv[1]
    
    # Описание фона по умолчанию, если не указано
    background_prompt = "Пляж на закате с пальмами"
    
    # Если пользователь указал своё описание фона
    if len(sys.argv) > 2:
        background_prompt = sys.argv[2]
    
    print(f"\n=== Тестирование функции смены фона ===")
    print(f"Исходное изображение: {image_path}")
    print(f"Запрос для фона (русский): '{background_prompt}'")
    
    # Переводим русское описание на английский
    english_prompt = translate_with_deepl(background_prompt)
    
    if english_prompt:
        print(f"✓ Запрос переведен на английский: '{english_prompt}'")
        
        try:
            # Загружаем изображение
            if not os.path.exists(image_path):
                print(f"✖ Ошибка: Файл {image_path} не найден")
                return
                
            with open(image_path, "rb") as f:
                image_data = f.read()
                
            print(f"✓ Изображение успешно загружено, размер: {len(image_data)} байт")
            
            # Инициализируем LightX API клиент
            print("\nИнициализация LightX API клиента...")
            lightx_client = LightXClient()
            print("✓ LightX API клиент успешно инициализирован")
            
            # Применяем смену фона
            print(f"\nОтправка запроса на смену фона с промптом: '{english_prompt}'...")
            result_image = lightx_client.change_background(image_data, english_prompt)
            
            if result_image:
                print("✓ Фон успешно изменен!")
                
                # Сохраняем изображение в файл
                output_path = "background_changed_image.jpg"
                with open(output_path, "wb") as f:
                    f.write(result_image)
                print(f"Изображение с новым фоном сохранено в файл: {output_path}")
                
                # Показываем информацию о размере сгенерированного изображения
                img = Image.open(io.BytesIO(result_image))
                print(f"Размер изображения: {img.width}x{img.height}")
            else:
                print("✖ Ошибка при смене фона через LightX API")
        
        except Exception as e:
            print(f"✖ Ошибка при работе с LightX API: {e}")
    else:
        print("✖ Ошибка перевода через DeepL API")

if __name__ == "__main__":
    main()