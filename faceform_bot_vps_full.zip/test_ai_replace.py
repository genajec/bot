import os
import logging
import requests
from lightx_client import LightXClient

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_ai_replace():
    """Тестирование функции замены элементов с помощью LightX API Replace"""
    logger.info("=== Тестирование функции AI Replace ===")
    
    # Инициализация клиента LightX
    lightx_client = LightXClient()
    
    # Проверка наличия API ключа
    if not lightx_client.api_key:
        logger.error("API ключ LightX не найден. Убедитесь, что переменная окружения LIGHTX_API_KEY установлена.")
        return False
        
    # Проверяем несколько изображений для теста
    test_images = [
        os.path.join(".", "demo_base_face.jpg"),
        os.path.join(".", "test_hairstyle_result.jpg"),
        os.path.join(".", "vis_IMG_6834.png")
    ]
    
    # Находим первое доступное изображение
    image_data = None
    for test_path in test_images:
        if os.path.exists(test_path):
            logger.info(f"Используем тестовое изображение: {test_path}")
            with open(test_path, "rb") as f:
                image_data = f.read()
            break
    
    if not image_data:
        logger.error("Не найдено ни одно тестовое изображение")
        return False
        
    # Текстовый запрос для замены элементов - используем простой и конкретный формат
    text_prompt = "replace background with blue color"
    
    # Загружаем маску для изображения
    mask_paths = [
        os.path.join(".", "test_mask_center.jpg"),
        os.path.join(".", "test_mask_background.jpg"),
        os.path.join(".", "test_mask_all.jpg")
    ]
    
    # Находим первую доступную маску
    mask_data = None
    mask_path = None
    for m_path in mask_paths:
        if os.path.exists(m_path):
            logger.info(f"Используем маску: {m_path}")
            with open(m_path, "rb") as f:
                mask_data = f.read()
            mask_path = m_path
            break
    
    if not mask_data:
        logger.warning("Не найдена маска, пробуем без неё")
        
    # Вызов функции AI Replace
    logger.info(f"Отправка запроса в LightX API Replace с запросом: {text_prompt} и маской: {mask_path}")
    result_image = lightx_client.ai_replace(image_data, text_prompt=text_prompt, mask_data=mask_data)
    
    if result_image:
        logger.info(f"Получено обработанное изображение размером {len(result_image)} байт")
        
        # Сохранение результата
        output_path = os.path.join(".", "test_ai_replace_result.jpg")
        with open(output_path, "wb") as f:
            f.write(result_image)
        
        logger.info(f"Результат сохранен в файл: {output_path}")
        return True
    else:
        logger.error("Не удалось получить результат от LightX API Replace")
        return False

if __name__ == "__main__":
    success = test_ai_replace()
    if success:
        logger.info("✅ Тест пройден успешно!")
    else:
        logger.error("❌ Тест не пройден!")