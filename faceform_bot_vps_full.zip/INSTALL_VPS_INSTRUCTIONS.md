# Инструкция по установке FaceForm бота на VPS

Данная инструкция поможет вам установить и запустить FaceForm бота на VPS сервере.

## Шаг 1: Подготовка сервера

1. Загрузите архив `faceform_bot_vps.zip` на ваш VPS сервер и распакуйте его:

```bash
# Создайте директорию для бота (если она еще не создана)
mkdir -p ~/faceform_bot

# Перейдите в эту директорию
cd ~/faceform_bot

# Загрузите архив на сервер (используйте scp или другой метод)
# Пример: scp faceform_bot_vps.zip username@your_server_ip:~/faceform_bot/

# Распакуйте архив
unzip faceform_bot_vps.zip
```

2. Убедитесь, что файл `.env` находится в этой директории и содержит все необходимые ключи API.

## Шаг 2: Создание виртуального окружения и установка зависимостей

```bash
# Создаем виртуальное окружение
python3 -m venv venv

# Активируем виртуальное окружение
source venv/bin/activate

# Устанавливаем зависимости
pip install -r vps_requirements.txt
```

## Шаг 3: Настройка Supervisor для автозапуска бота

1. Создайте директорию для логов:

```bash
sudo mkdir -p /var/log/faceform_bot
sudo chown -R $(whoami):$(whoami) /var/log/faceform_bot
```

2. Отредактируйте конфигурационный файл `faceform_bot_supervisor.conf`, заменив пути на актуальные:

```bash
# Откройте файл конфигурации
nano faceform_bot_supervisor.conf

# Замените пути и имя пользователя на актуальные
# Например:
# command=/home/username/faceform_bot/venv/bin/python /home/username/faceform_bot/run_vps.py
# directory=/home/username/faceform_bot
# user=username
```

3. Установите конфигурацию Supervisor:

```bash
sudo cp faceform_bot_supervisor.conf /etc/supervisor/conf.d/faceform_bot_polling.conf
sudo supervisorctl reread
sudo supervisorctl update
```

## Шаг 4: Запуск бота

```bash
sudo supervisorctl start faceform_bot_polling
```

## Проверка статуса и логов

```bash
# Проверка статуса
sudo supervisorctl status faceform_bot_polling

# Просмотр логов
sudo tail -f /var/log/faceform_bot/stderr.log
```

## Остановка и перезапуск бота

```bash
# Остановка бота
sudo supervisorctl stop faceform_bot_polling

# Перезапуск бота
sudo supervisorctl restart faceform_bot_polling
```

## Удаление веб-сайта с сервера (если он был установлен)

Если вы ранее установили веб-сайт и хотите его удалить, выполните следующие команды:

```bash
sudo supervisorctl stop faceform_website
sudo rm /etc/supervisor/conf.d/faceform_website.conf
sudo supervisorctl reread
sudo supervisorctl update
cd ~ && rm -rf faceform_website
sudo rm -rf /var/log/faceform_website
sudo rm -f /etc/nginx/sites-enabled/faceform_website
sudo rm -f /etc/nginx/sites-available/faceform_website
sudo systemctl reload nginx
```

## Диагностика и устранение проблем

Если бот не запускается или работает некорректно, проверьте логи:

```bash
sudo tail -f /var/log/faceform_bot/stderr.log
```

Убедитесь, что:
1. Все зависимости установлены корректно
2. Файл `.env` содержит правильные API ключи
3. Права доступа к файлам и директориям настроены правильно