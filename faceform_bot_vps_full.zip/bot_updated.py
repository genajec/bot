import os
import io
import logging
import tempfile
import telebot
from telebot import types
import cv2
import numpy as np
import mediapipe as mp
import time
import base64
from config import TOKEN, ADMINS
from face_analyzer import FaceAnalyzer
from hairstyle_recommender import HairstyleRecommender
from process_video_with_grid import process_video_with_grid

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class FaceShapeBot:
    def __init__(self, use_webhook=False):
        """Инициализация бота."""
        self.bot = telebot.TeleBot(TOKEN)
        self.face_analyzer = FaceAnalyzer()
        self.hairstyle_recommender = HairstyleRecommender()
        
        # Состояние пользователей (фото и определенная форма лица)
        self.user_photos = {}  # chat_id -> photo bytes
        self.user_face_shapes = {}  # chat_id -> face shape
        self.user_landmarks = {}  # chat_id -> landmarks
        self.user_selecting_hairstyle = {}  # chat_id -> bool
        
        # Регистрация обработчиков
        @self.bot.message_handler(commands=['start'])
        def handle_start(message):
            self.start(message)
        
        @self.bot.message_handler(commands=['help'])
        def handle_help(message):
            self.help_command(message)
        
        @self.bot.message_handler(commands=['try'])
        def handle_try(message):
            self.try_hairstyle_command(message)
        
        @self.bot.message_handler(commands=['hairstyles'])
        def handle_hairstyles(message):
            self.list_hairstyles_command(message)
        
        @self.bot.message_handler(commands=['reset'])
        def handle_reset(message):
            self.reset_command(message)
        
        @self.bot.message_handler(content_types=['photo'])
        def handle_photo(message):
            self.process_photo(message)
        
        @self.bot.message_handler(content_types=['video'])
        def handle_video(message):
            self.process_video(message)
        
        @self.bot.message_handler(content_types=['text'])
        def handle_text(message):
            self.handle_message(message)
        
        logger.info("Бот успешно инициализирован")
        self.use_webhook = use_webhook
    
    def start(self, message):
        """Send a message when the command /start is issued."""
        user_first_name = message.from_user.first_name
        welcome_text = (
            f"Привет, {user_first_name}! 👋\n\n"
            "Я FaceForm Бот, который поможет определить форму вашего лица и подобрать подходящую прическу.\n\n"
            "🤔 *Как это работает*:\n"
            "1. Отправьте мне селфи фото или короткое видео с вашим лицом\n"
            "2. Я проанализирую вашу форму лица\n"
            "3. Получите рекомендации по прическам\n"
            "4. Используйте /try чтобы виртуально примерить прически\n\n"
            "📸 *Для лучшего результата*:\n"
            "- Фото/видео должно быть с хорошим освещением\n"
            "- Смотрите прямо в камеру\n"
            "- Уберите волосы с линии лица\n"
            "- Сохраняйте нейтральное выражение\n\n"
            "Для получения справки введите /help"
        )
        
        self.bot.send_message(message.chat.id, welcome_text, parse_mode="Markdown")
    
    def help_command(self, message):
        """Send a message when the command /help is issued."""
        help_text = (
            "Я бот для анализа формы лица. Отправьте мне фото или видео с вашим лицом, и я определю вашу форму лица.\n\n"
            "📸 *Фото или видео должно соответствовать критериям*:\n"
            "- Хорошее освещение\n"
            "- Лицо анфас (смотреть прямо в камеру)\n"
            "- Убрать волосы с линии лица\n"
            "- Нейтральное выражение лица\n\n"
            "👈 *Доступные команды*:\n"
            "/start - Начать работу с ботом\n"
            "/help - Показать это сообщение\n"
            "/try - Примерить виртуальную прическу на фото\n"
            "/hairstyles - Показать доступные прически\n"
            "/reset - Сбросить данные и начать заново\n\n"
            "🎬 *Для обработки видео*:\n"
            "Просто отправьте короткое видео (5-10 секунд) с вашим лицом, и бот проанализирует форму лица в каждом кадре видео."
        )
        
        self.bot.send_message(message.chat.id, help_text, parse_mode="Markdown")
    
    def process_photo(self, message):
        """Process the user photo and send face shape analysis with recommendations."""
        try:
            chat_id = message.chat.id
            
            # Получение фото в высоком разрешении
            file_info = self.bot.get_file(message.photo[-1].file_id)
            downloaded_file = self.bot.download_file(file_info.file_path)
            
            # Отправляем сообщение о начале обработки
            processing_msg = self.bot.send_message(chat_id, "Обрабатываю ваше фото... 🔍")
            
            # Анализ формы лица
            face_shape, visualization_image, landmarks = self.face_analyzer.analyze_face_shape(downloaded_file)
            
            if face_shape is None:
                self.bot.send_message(chat_id, 
                    "Не удалось распознать лицо на фото. Пожалуйста, убедитесь, что на фото четко видно ваше лицо, "
                    "и отправьте снова. Если проблема повторяется, попробуйте фото с лучшим освещением.")
                self.bot.delete_message(chat_id, processing_msg.message_id)
                return
            
            # Сохраняем данные пользователя для дальнейшей обработки
            self.user_photos[chat_id] = downloaded_file
            self.user_face_shapes[chat_id] = face_shape
            self.user_landmarks[chat_id] = landmarks
            
            # Получаем рекомендации по прическам
            face_shape_description, recommendations = self.hairstyle_recommender.get_recommendations(face_shape)
            
            # Отправляем результаты анализа
            caption = (
                f"*Форма вашего лица: {face_shape}*\n\n"
                f"{face_shape_description}\n\n"
                f"*Рекомендуемые прически:*\n{recommendations}\n\n"
                f"Чтобы виртуально примерить прическу, отправьте команду /try\n"
                f"Чтобы посмотреть доступные прически, отправьте команду /hairstyles"
            )
            
            # Конвертируем визуализацию в JPEG и отправляем
            is_success, img_buffer = cv2.imencode('.jpg', visualization_image)
            if not is_success:
                raise Exception("Failed to encode image")
            
            photo_bytes = io.BytesIO(img_buffer.tobytes())
            photo_bytes.seek(0)
            
            # Удаляем сообщение о процессе обработки
            self.bot.delete_message(chat_id, processing_msg.message_id)
            
            # Отправляем фото с результатами
            self.bot.send_photo(chat_id, photo_bytes, caption=caption, parse_mode="Markdown")
            
            # Отправка сообщения для предложения примерить прическу
            markup = types.InlineKeyboardMarkup()
            try_hairstyle_button = types.InlineKeyboardButton("Примерить прическу", callback_data="try_hairstyle")
            show_hairstyles_button = types.InlineKeyboardButton("Показать прически", callback_data="show_hairstyles")
            markup.add(try_hairstyle_button, show_hairstyles_button)
            
            self.bot.send_message(chat_id, 
                "Хотите примерить виртуальную прическу или просмотреть доступные варианты?", 
                reply_markup=markup)
            
        except Exception as e:
            logger.error(f"Error processing photo: {str(e)}")
            try:
                self.bot.send_message(message.chat.id, 
                    "Произошла ошибка при обработке фото. Пожалуйста, попробуйте еще раз.")
            except:
                pass
    
    def process_video(self, message):
        """Process the user video, add facial grid, and return processed video."""
        try:
            chat_id = message.chat.id
            # Отправляем сообщение, что начался процесс обработки
            processing_msg = self.bot.send_message(chat_id, "Получил ваше видео! Обрабатываю и добавляю сетку на лицо... Это может занять некоторое время.")
            
            # Получаем информацию о видео файле
            file_info = self.bot.get_file(message.video.file_id)
            file_content = self.bot.download_file(file_info.file_path)
            
            # Обработка видео с нанесением сетки
            processed_video = process_video_with_grid(file_content)
            
            if processed_video is None:
                self.bot.send_message(chat_id, "Не удалось обработать видео. Пожалуйста, убедитесь, что ваше лицо хорошо видно, и попробуйте еще раз.")
                return
            
            # Отправляем обработанное видео
            self.bot.send_video(
                chat_id, 
                processed_video,
                caption="Вот ваше обработанное видео с сеткой лицевых ориентиров и определенной формой лица."
            )
            
            # Удаляем сообщение о процессе обработки
            self.bot.delete_message(chat_id, processing_msg.message_id)
            
            logging.info(f"Processed video for chat_id {chat_id}")
            
        except Exception as e:
            logging.error(f"Error processing video: {str(e)}")
            chat_id = message.chat.id
            self.bot.send_message(chat_id, f"Произошла ошибка при обработке видео: {str(e)}. Пожалуйста, попробуйте еще раз или отправьте видео меньшего размера.")
    
    def handle_message(self, message):
        """Handle non-photo messages."""
        chat_id = message.chat.id
        text = message.text.strip()
        
        # Проверка, находится ли пользователь в режиме выбора прически
        if chat_id in self.user_selecting_hairstyle and self.user_selecting_hairstyle[chat_id]:
            try:
                # Попытка преобразовать текст в номер прически
                hairstyle_index = int(text) - 1
                self.apply_selected_hairstyle(message, hairstyle_index)
            except ValueError:
                self.bot.send_message(chat_id, "Пожалуйста, отправьте номер прически (число).")
        else:
            # Общие ответы на текстовые сообщения
            if text.lower() in ["привет", "здравствуйте", "hi", "hello"]:
                self.start(message)
            elif "прическ" in text.lower() or "волос" in text.lower() or "стиль" in text.lower():
                self.bot.send_message(chat_id, 
                    "Чтобы получить рекомендации по прическам, отправьте мне свое фото. "
                    "Затем я определю форму вашего лица и предложу подходящие варианты.")
            else:
                self.bot.send_message(chat_id, 
                    "Отправьте мне свое фото или видео, и я определю форму вашего лица и предложу подходящие прически.")
    
    def try_hairstyle_command(self, message):
        """Handle the /try command to try on hairstyles"""
        chat_id = message.chat.id
        
        if chat_id not in self.user_photos or chat_id not in self.user_face_shapes:
            self.bot.send_message(chat_id, 
                "Сначала отправьте мне свое фото для анализа формы лица.")
            return
        
        face_shape = self.user_face_shapes[chat_id]
        hairstyle_names = self.face_analyzer.get_hairstyle_names(face_shape)
        
        if not hairstyle_names:
            self.bot.send_message(chat_id, 
                "К сожалению, для вашей формы лица пока нет доступных вариантов причесок. "
                "Мы работаем над расширением базы.")
            return
        
        # Формируем сообщение со списком доступных причесок
        hairstyles_message = "Доступные прически для вашей формы лица:\n\n"
        for i, name in enumerate(hairstyle_names, 1):
            hairstyles_message += f"{i}. {name}\n"
        
        hairstyles_message += "\nОтправьте номер прически, которую хотите примерить, или /reset чтобы начать заново."
        
        # Включаем режим выбора прически
        self.user_selecting_hairstyle[chat_id] = True
        
        self.bot.send_message(chat_id, hairstyles_message)
    
    def list_hairstyles_command(self, message):
        """Handle the /hairstyles command to list available hairstyles"""
        chat_id = message.chat.id
        
        if chat_id not in self.user_face_shapes:
            self.bot.send_message(chat_id, 
                "Сначала отправьте мне свое фото для анализа формы лица.")
            return
        
        face_shape = self.user_face_shapes[chat_id]
        hairstyle_names = self.face_analyzer.get_hairstyle_names(face_shape)
        
        if not hairstyle_names:
            self.bot.send_message(chat_id, 
                "К сожалению, для вашей формы лица пока нет доступных вариантов причесок. "
                "Мы работаем над расширением базы.")
            return
        
        # Формируем сообщение со списком доступных причесок
        hairstyles_message = f"Доступные прически для формы лица {face_shape}:\n\n"
        for i, name in enumerate(hairstyle_names, 1):
            hairstyles_message += f"{i}. {name}\n"
        
        hairstyles_message += "\nОтправьте команду /try, чтобы примерить одну из них."
        
        self.bot.send_message(chat_id, hairstyles_message)
    
    def apply_selected_hairstyle(self, message, hairstyle_index):
        """Apply the selected hairstyle to the user's photo"""
        chat_id = message.chat.id
        
        if chat_id not in self.user_photos or chat_id not in self.user_face_shapes:
            self.bot.send_message(chat_id, 
                "Сначала отправьте мне свое фото для анализа формы лица.")
            return
        
        # Выключаем режим выбора прически
        self.user_selecting_hairstyle[chat_id] = False
        
        face_shape = self.user_face_shapes[chat_id]
        hairstyle_names = self.face_analyzer.get_hairstyle_names(face_shape)
        
        if not hairstyle_names or hairstyle_index < 0 or hairstyle_index >= len(hairstyle_names):
            self.bot.send_message(chat_id, 
                "Некорректный номер прически. Пожалуйста, выберите из предложенного списка.")
            return
        
        # Отправляем сообщение о начале обработки
        processing_msg = self.bot.send_message(chat_id, f"Применяю прическу '{hairstyle_names[hairstyle_index]}'... 🔄")
        
        try:
            # Получаем данные
            photo_data = self.user_photos[chat_id]
            landmarks = self.user_landmarks.get(chat_id)
            
            # Применяем виртуальную примерку прически
            hairstyle_image = self.face_analyzer.apply_hairstyle(
                photo_data, 
                landmarks=landmarks,
                face_shape=face_shape,
                hairstyle_index=hairstyle_index
            )
            
            if hairstyle_image is None:
                self.bot.send_message(chat_id, 
                    "Не удалось применить прическу. Пожалуйста, попробуйте другую или отправьте новое фото.")
                self.bot.delete_message(chat_id, processing_msg.message_id)
                return
            
            # Отправляем фото с примененной прической
            caption = f"Вот как будет выглядеть прическа '{hairstyle_names[hairstyle_index]}' с вашей формой лица {face_shape}!"
            
            self.bot.send_photo(chat_id, hairstyle_image, caption=caption)
            
            # Удаляем сообщение о процессе обработки
            self.bot.delete_message(chat_id, processing_msg.message_id)
            
            # Предлагаем примерить другие прически
            markup = types.InlineKeyboardMarkup()
            try_another_button = types.InlineKeyboardButton("Примерить другую прическу", callback_data="try_hairstyle")
            markup.add(try_another_button)
            
            self.bot.send_message(chat_id, "Хотите примерить другую прическу?", reply_markup=markup)
            
        except Exception as e:
            logger.error(f"Error applying hairstyle: {str(e)}")
            self.bot.send_message(chat_id, 
                "Произошла ошибка при применении прически. Пожалуйста, попробуйте еще раз или выберите другую прическу.")
            self.bot.delete_message(chat_id, processing_msg.message_id)
    
    def reset_command(self, message):
        """Reset user data and start fresh"""
        chat_id = message.chat.id
        
        # Очищаем все данные пользователя
        if chat_id in self.user_photos:
            del self.user_photos[chat_id]
        if chat_id in self.user_face_shapes:
            del self.user_face_shapes[chat_id]
        if chat_id in self.user_landmarks:
            del self.user_landmarks[chat_id]
        if chat_id in self.user_selecting_hairstyle:
            del self.user_selecting_hairstyle[chat_id]
        
        self.bot.send_message(chat_id, 
            "Все данные сброшены. Отправьте новое фото для анализа формы лица.")
    
    def run(self):
        """Run the bot."""
        if self.use_webhook:
            logger.info("Bot running in webhook mode")
            return
        
        logger.info("Bot started in polling mode")
        while True:
            try:
                self.bot.polling(none_stop=True, interval=1)
            except Exception as e:
                logger.error(f"Bot polling error: {str(e)}")
                time.sleep(5)
                continue
            break