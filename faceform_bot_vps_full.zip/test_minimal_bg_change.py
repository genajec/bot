#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import logging
import requests
import sys
from PIL import Image
import io

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def upload_image(api_key, image_path):
    """
    Загружает изображение на сервер LightX API
    
    Args:
        api_key (str): API ключ LightX
        image_path (str): Путь к изображению для загрузки
        
    Returns:
        str: URL загруженного изображения или None в случае ошибки
    """
    try:
        # Получение API ключа из переменных окружения, если он не предоставлен
        if not api_key:
            api_key = os.environ.get("LIGHTX_API_KEY")
            if not api_key:
                logger.error("LIGHTX_API_KEY не найден в переменных окружения!")
                return None
                
        # URL API для загрузки изображения
        upload_url = "https://api.lightxeditor.com/api/v1/upload-image-file"
        
        # Заголовки с ключом API
        headers = {
            "x-api-key": api_key
        }
        
        # Загрузка файла
        with open(image_path, 'rb') as f:
            image_data = f.read()
            
        # Данные для запроса
        files = {
            'image': (os.path.basename(image_path), image_data)
        }
        
        # Отправка запроса
        logger.info(f"Отправка запроса на загрузку изображения: {image_path}")
        response = requests.post(upload_url, headers=headers, files=files)
        
        # Проверка ответа
        if response.status_code != 200:
            logger.error(f"Ошибка загрузки изображения: {response.status_code} - {response.text}")
            return None
            
        # Парсинг ответа
        result = response.json()
        if result.get("statusCode") != 2000 or "body" not in result:
            logger.error(f"Некорректный ответ от API загрузки: {result}")
            return None
            
        # Получение URL изображения
        image_url = result["body"].get("imageUrl")
        if not image_url:
            logger.error("URL изображения отсутствует в ответе")
            return None
            
        logger.info(f"Изображение успешно загружено, URL: {image_url}")
        return image_url
        
    except Exception as e:
        logger.error(f"Ошибка при загрузке изображения: {e}")
        return None

def remove_background(api_key, image_url, bg_color="#FFFFFF"):
    """
    Удаляет фон изображения и заменяет его на указанный цвет или изображение
    
    Args:
        api_key (str): API ключ LightX
        image_url (str): URL изображения
        bg_color (str): Цвет фона в HEX формате или URL фонового изображения
        
    Returns:
        str: ID заказа на обработку или None в случае ошибки
    """
    try:
        # Получение API ключа из переменных окружения, если он не предоставлен
        if not api_key:
            api_key = os.environ.get("LIGHTX_API_KEY")
            if not api_key:
                logger.error("LIGHTX_API_KEY не найден в переменных окружения!")
                return None
                
        # URL API для удаления фона
        remove_bg_url = "https://api.lightxeditor.com/api/v1/remove-background"
        
        # Заголовки с ключом API
        headers = {
            "Content-Type": "application/json",
            "x-api-key": api_key
        }
        
        # Данные для запроса
        data = {
            "imageUrl": image_url,
            "background": bg_color
        }
        
        # Отправка запроса
        logger.info(f"Отправка запроса на удаление фона. URL изображения: {image_url}, Фон: {bg_color}")
        response = requests.post(remove_bg_url, headers=headers, json=data)
        
        # Проверка ответа
        if response.status_code != 200:
            logger.error(f"Ошибка удаления фона: {response.status_code} - {response.text}")
            return None
            
        # Парсинг ответа
        result = response.json()
        if result.get("statusCode") != 2000 or "body" not in result:
            logger.error(f"Некорректный ответ от API удаления фона: {result}")
            return None
            
        # Получение ID заказа
        order_id = result["body"].get("orderId")
        if not order_id:
            logger.error("ID заказа отсутствует в ответе")
            return None
            
        logger.info(f"Запрос на удаление фона успешно отправлен, ID заказа: {order_id}")
        return order_id
        
    except Exception as e:
        logger.error(f"Ошибка при запросе на удаление фона: {e}")
        return None

def wait_for_result(api_key, order_id, max_retries=20, retry_interval=2):
    """
    Ожидает завершения обработки заказа
    
    Args:
        api_key (str): API ключ LightX
        order_id (str): ID заказа
        max_retries (int): Максимальное количество попыток проверки
        retry_interval (int): Интервал между попытками в секундах
        
    Returns:
        str: URL результата или None в случае ошибки или тайм-аута
    """
    try:
        # Получение API ключа из переменных окружения, если он не предоставлен
        if not api_key:
            api_key = os.environ.get("LIGHTX_API_KEY")
            if not api_key:
                logger.error("LIGHTX_API_KEY не найден в переменных окружения!")
                return None
                
        # URL API для проверки статуса заказа
        status_url = f"https://api.lightxeditor.com/api/v1/query?orderId={order_id}"
        
        # Заголовки с ключом API
        headers = {
            "x-api-key": api_key
        }
        
        import time
        
        # Ожидание результата
        for i in range(max_retries):
            logger.info(f"Проверка статуса заказа {order_id}, попытка {i+1}/{max_retries}")
            
            # Отправка запроса на проверку статуса
            response = requests.get(status_url, headers=headers)
            
            # Проверка ответа
            if response.status_code != 200:
                logger.error(f"Ошибка проверки статуса: {response.status_code} - {response.text}")
                time.sleep(retry_interval)
                continue
                
            # Парсинг ответа
            result = response.json()
            if result.get("statusCode") != 2000 or "body" not in result:
                logger.error(f"Некорректный ответ от API проверки статуса: {result}")
                time.sleep(retry_interval)
                continue
                
            # Проверка статуса заказа
            status = result["body"].get("status")
            
            # Если обработка завершена успешно
            if status == 2200:
                # Получение URL результата
                output_url = result["body"].get("outputUrl")
                if not output_url:
                    logger.error("URL результата отсутствует в ответе")
                    return None
                    
                logger.info(f"Обработка завершена, URL результата: {output_url}")
                return output_url
                
            # Если обработка завершена с ошибкой
            elif status == 2500:
                logger.error(f"Ошибка обработки заказа: {result}")
                return None
                
            # Если обработка всё ещё выполняется
            else:
                logger.info(f"Заказ всё ещё обрабатывается, статус: {status}")
                time.sleep(retry_interval)
                
        # Если превышено максимальное количество попыток
        logger.error(f"Превышено максимальное количество попыток ({max_retries})")
        return None
        
    except Exception as e:
        logger.error(f"Ошибка при ожидании результата: {e}")
        return None

def download_result(output_url):
    """
    Загружает результат по указанному URL
    
    Args:
        output_url (str): URL с результатом
    
    Returns:
        bytes: Данные изображения или None в случае ошибки
    """
    try:
        # Загрузка результата
        logger.info(f"Загрузка результата по URL: {output_url}")
        response = requests.get(output_url)
        
        # Проверка ответа
        if response.status_code != 200:
            logger.error(f"Ошибка загрузки результата: {response.status_code}")
            return None
            
        logger.info(f"Результат успешно загружен, размер: {len(response.content)} байт")
        return response.content
        
    except Exception as e:
        logger.error(f"Ошибка при загрузке результата: {e}")
        return None

def main():
    """
    Основная функция для тестирования удаления фона
    """
    # Проверка аргументов командной строки
    if len(sys.argv) < 2:
        logger.error("Укажите путь к изображению в качестве аргумента")
        print("Использование: python test_minimal_bg_change.py <путь_к_изображению> [цвет_фона]")
        return
        
    # Получение пути к изображению
    image_path = sys.argv[1]
    
    # Получение цвета фона (если указан)
    bg_color = sys.argv[2] if len(sys.argv) > 2 else "#FFFFFF"
    
    # Получение API ключа из переменных окружения
    api_key = os.environ.get("LIGHTX_API_KEY")
    if not api_key:
        logger.error("LIGHTX_API_KEY не найден в переменных окружения!")
        return
        
    # Загрузка изображения
    logger.info("Шаг 1: Загрузка изображения")
    image_url = upload_image(api_key, image_path)
    if not image_url:
        logger.error("Не удалось загрузить изображение")
        return
        
    # Удаление фона
    logger.info("Шаг 2: Удаление фона")
    order_id = remove_background(api_key, image_url, bg_color)
    if not order_id:
        logger.error("Не удалось отправить запрос на удаление фона")
        return
        
    # Ожидание результата
    logger.info("Шаг 3: Ожидание результата")
    output_url = wait_for_result(api_key, order_id)
    if not output_url:
        logger.error("Не удалось получить результат")
        return
        
    # Загрузка результата
    logger.info("Шаг 4: Загрузка результата")
    result_data = download_result(output_url)
    if not result_data:
        logger.error("Не удалось загрузить результат")
        return
        
    # Сохранение результата
    output_path = "background_removed_image.jpg"
    with open(output_path, "wb") as f:
        f.write(result_data)
        
    logger.info(f"Результат сохранен в файл: {output_path}")
    
    # Отображение результата
    try:
        from PIL import Image
        import io
        
        # Загрузка результата в PIL
        result_image = Image.open(io.BytesIO(result_data))
        
        # Вывод информации об изображении
        logger.info(f"Размер изображения: {result_image.size}")
        logger.info(f"Формат изображения: {result_image.format}")
        logger.info(f"Режим изображения: {result_image.mode}")
        
        # Отображение изображения
        # result_image.show()
        
    except Exception as e:
        logger.error(f"Ошибка при отображении результата: {e}")

if __name__ == "__main__":
    main()