#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import os
import shutil
import logging
from fix_background_function import fix_background_change_function

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def fix_lightx_client():
    """
    Заменяет функцию change_background в файле lightx_client.py
    """
    file_path = 'lightx_client.py'
    backup_path = 'lightx_client.py.bak'
    
    # Создаем резервную копию файла
    shutil.copy2(file_path, backup_path)
    logger.info(f"Создана резервная копия файла: {backup_path}")
    
    # Чтение файла
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Регулярное выражение для поиска функции change_background
    pattern = r'def change_background\(self, image_data, background_prompt, style_image_data=None\):(.*?)def'
    
    # Замена функции
    new_function = fix_background_change_function()
    replacement = new_function + "\n\n    def"
    
    # Ищем функцию в файле
    matches = re.search(pattern, content, re.DOTALL)
    if not matches:
        logger.error("Функция change_background не найдена в файле")
        return False
    
    # Заменяем функцию
    new_content = re.sub(pattern, replacement, content, flags=re.DOTALL)
    
    # Запись обновленного содержимого
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(new_content)
    
    logger.info("Функция change_background успешно заменена")
    return True

def main():
    """
    Основная функция
    """
    result = fix_lightx_client()
    if result:
        logger.info("Успешно выполнено исправление функции смены фона")
    else:
        logger.error("Не удалось выполнить исправление функции смены фона")

if __name__ == "__main__":
    main()