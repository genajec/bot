from flask import Flask, session
from datetime import timedelta


def setup_session(app):
    """
    Настраивает сессии Flask для приложения.
    
    Args:
        app (Flask): Экземпляр приложения Flask
    """
    # Настройка сессий
    app.config['SESSION_TYPE'] = 'filesystem'
    app.config['SESSION_FILE_DIR'] = 'flask_session'
    app.config['SESSION_PERMANENT'] = True
    app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=30)
    
    # Установка secure cookies в продакшене
    app.config['SESSION_COOKIE_SECURE'] = True
    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    
    # Создаем директорию для сессий если не существует
    import os
    os.makedirs(app.config['SESSION_FILE_DIR'], exist_ok=True)
    
    # Инициализация расширения Flask-Session
    from flask_session import Session
    Session(app)
    
    return app