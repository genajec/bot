# FaceForm Telegram Bot Polling Mode Setup

This guide explains how to configure the FaceForm Telegram bot in polling mode on your VPS. Use this method if you don't have a domain name with SSL certificate, or if you prefer not to use webhooks.

## What is Polling Mode?

Polling mode means the bot actively checks for new messages periodically, rather than receiving them via webhooks. This is simpler to set up but slightly less efficient than webhook mode.

## Prerequisites

- FaceForm already installed on your VPS using the `setup_faceform_vps.sh` script
- A Telegram bot token (obtained from [@BotFather](https://t.me/BotFather))

## Step 1: Create a Bot Runner Script

Create a polling-specific script to run the bot:

```bash
sudo nano /opt/faceform/run_bot_polling.py
```

Add the following content:

```python
import os
import sys
import logging
from dotenv import load_dotenv
from bot import FaceShapeBot

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('/opt/faceform/bot_polling.log')
    ]
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Check for Telegram Bot Token
token = os.environ.get('TELEGRAM_BOT_TOKEN')
if not token:
    logger.error("TELEGRAM_BOT_TOKEN not found in environment variables")
    sys.exit(1)

if __name__ == "__main__":
    try:
        logger.info("Starting FaceForm bot in polling mode...")
        # Create bot instance with webhook mode disabled (use_webhook=False)
        bot = FaceShapeBot(use_webhook=False)
        # Run the bot
        bot.run()
    except Exception as e:
        logger.error(f"Error running bot: {e}")
        sys.exit(1)
```

Save the file by pressing Ctrl+O, Enter, then Ctrl+X.

## Step 2: Create a Systemd Service for Polling Mode

Create a service file specifically for polling mode:

```bash
sudo nano /etc/systemd/system/faceform-bot-polling.service
```

Add the following content:

```ini
[Unit]
Description=FaceForm Telegram Bot Service (Polling Mode)
After=network.target postgresql.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=/opt/faceform
Environment="PATH=/opt/faceform/venv/bin"
ExecStart=/opt/faceform/venv/bin/python3 run_bot_polling.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Save the file by pressing Ctrl+O, Enter, then Ctrl+X.

## Step 3: Update Environment Variables

Ensure your .env file doesn't have webhook-specific settings that might interfere:

```bash
sudo nano /opt/faceform/.env
```

Make sure the following line is commented out or removed:

```
# TELEGRAM_WEBHOOK_URL=https://your-domain.com/webhook
```

Add or update your bot token:

```
TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here
```

Save the file by pressing Ctrl+O, Enter, then Ctrl+X.

## Step 4: Start the Polling Service

Reload systemd to recognize the new service:

```bash
sudo systemctl daemon-reload
```

Start the polling service:

```bash
sudo systemctl start faceform-bot-polling
```

Enable the service to start at boot:

```bash
sudo systemctl enable faceform-bot-polling
```

## Step 5: Verify the Bot is Working

Check the status of the service:

```bash
sudo systemctl status faceform-bot-polling
```

View the bot logs:

```bash
sudo tail -f /opt/faceform/bot_polling.log
```

Or using journalctl:

```bash
sudo journalctl -u faceform-bot-polling -f
```

## Troubleshooting

### Bot Not Responding

1. Check if the service is running:
   ```bash
   sudo systemctl status faceform-bot-polling
   ```

2. Verify the bot token in your .env file is correct

3. Check the logs for specific errors:
   ```bash
   sudo tail -f /opt/faceform/bot_polling.log
   ```

### Permission Issues

If you encounter permission errors:

```bash
sudo chown -R www-data:www-data /opt/faceform
sudo chmod -R 755 /opt/faceform
sudo chmod 644 /opt/faceform/.env
```

### Polling and Webhook Mode Conflict

If you previously set up webhook mode, you might need to remove the webhook from Telegram's servers:

```bash
curl "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/deleteWebhook"
```

Replace `<YOUR_BOT_TOKEN>` with your actual bot token.

## Switching Between Modes

To switch from polling to webhook mode or vice versa:

1. Stop both bot services:
   ```bash
   sudo systemctl stop faceform-bot faceform-bot-polling
   ```

2. Update your .env file with the appropriate settings

3. Start the desired service:
   - For polling: `sudo systemctl start faceform-bot-polling`
   - For webhook: `sudo systemctl start faceform-bot`

## Additional Notes

- Polling mode uses more resources than webhook mode but is simpler to set up
- For production with many users, webhook mode is recommended when possible
- The polling mode service should not run simultaneously with the webhook mode service