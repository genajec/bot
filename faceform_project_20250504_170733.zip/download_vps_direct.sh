#!/bin/bash
#
# Скрипт для прямого скачивания архива FaceForm на VPS
# и автоматической установки
#

# Цвета для вывода
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Конфигурация VPS
VPS_IP="92.113.145.171"
VPS_USER="faceform"
VPS_DOMAIN="faceform.vps.webdock.cloud"

# URL для скачивания
DOWNLOAD_URL="https://14394011-38ca-4d04-b53f-b6b96d6f0d67-00-ypmzxq3ndxv2.kirk.replit.dev/download/vps/archive"
ARCHIVE_NAME="faceform_vps_deploy_full.tar.gz"

echo -e "${GREEN}[INFO]${NC} Скрипт прямого скачивания архива FaceForm на VPS"
echo -e "${GREEN}[INFO]${NC} IP VPS: $VPS_IP"
echo -e "${GREEN}[INFO]${NC} Домен: $VPS_DOMAIN"

# Проверяем наличие необходимых утилит
if ! command -v wget &> /dev/null && ! command -v curl &> /dev/null; then
    echo -e "${RED}[ERROR]${NC} Ни wget, ни curl не установлен."
    echo -e "${YELLOW}[INFO]${NC} Установите одну из этих утилит:"
    echo "sudo apt-get install -y wget"
    echo "или"
    echo "sudo apt-get install -y curl"
    exit 1
fi

# Создаем команду для выполнения на VPS
REMOTE_COMMANDS=$(cat << 'EOT'
cd ~
echo "[INFO] Скачивание архива FaceForm..."
if command -v wget &> /dev/null; then
    wget -O faceform_vps_deploy_full.tar.gz "https://14394011-38ca-4d04-b53f-b6b96d6f0d67-00-ypmzxq3ndxv2.kirk.replit.dev/download/vps/archive"
elif command -v curl &> /dev/null; then
    curl -o faceform_vps_deploy_full.tar.gz "https://14394011-38ca-4d04-b53f-b6b96d6f0d67-00-ypmzxq3ndxv2.kirk.replit.dev/download/vps/archive"
else
    echo "[ERROR] Ни wget, ни curl не найден. Установите одну из этих утилит."
    exit 1
fi

if [ ! -f faceform_vps_deploy_full.tar.gz ]; then
    echo "[ERROR] Не удалось скачать архив."
    exit 1
fi

echo "[INFO] Распаковка архива..."
tar -xzf faceform_vps_deploy_full.tar.gz

if [ -f ./setup.sh ]; then
    echo "[INFO] Запуск установочного скрипта..."
    chmod +x ./setup.sh
    sudo ./setup.sh
else
    echo "[ERROR] Установочный скрипт не найден в архиве."
fi
EOT
)

# Выводим команды для пользователя
echo -e "${YELLOW}[ИНСТРУКЦИЯ]${NC} Выполните следующие команды на вашем VPS:"
echo -e "${GREEN}----------------------------------------${NC}"
echo "$REMOTE_COMMANDS"
echo -e "${GREEN}----------------------------------------${NC}"

echo -e "${YELLOW}[ИНСТРУКЦИЯ]${NC} Или выполните одну команду для SSH:"
echo -e "${GREEN}----------------------------------------${NC}"
echo "ssh $VPS_USER@$VPS_IP 'bash -s' << 'ENDSSH'"
echo "$REMOTE_COMMANDS"
echo "ENDSSH"
echo -e "${GREEN}----------------------------------------${NC}"

echo -e "${GREEN}[INFO]${NC} После успешной установки сайт будет доступен по адресу:"
echo -e "${GREEN}[INFO]${NC} http://$VPS_DOMAIN"
echo -e "${GREEN}[INFO]${NC} Данные администратора:"
echo -e "${GREEN}[INFO]${NC} Логин: admin@$VPS_DOMAIN"
echo -e "${GREEN}[INFO]${NC} Пароль: faceform_admin2025"