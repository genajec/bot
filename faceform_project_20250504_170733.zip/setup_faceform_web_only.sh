#!/bin/bash
# FaceForm Web Only - VPS Installation Script
# Эта упрощенная версия скрипта устанавливает только веб-часть FaceForm без Telegram бота
# Создано: 29 апреля 2025

set -e

# Определения цветов для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # Без цвета

# Функция для отображения цветного текста
echo_color() {
    local color=$1
    local message=$2
    echo -e "${color}${message}${NC}"
}

# Функция для отображения заголовков разделов
section() {
    echo_color $BLUE "\n===== $1 ====="
}

# Функция для отображения сообщений об успехе
success() {
    echo_color $GREEN "✓ $1"
}

# Функция для отображения сообщений об ошибках
error() {
    echo_color $RED "✗ $1"
}

# Функция для отображения предупреждений
warning() {
    echo_color $YELLOW "! $1"
}

# Функция для отображения информационных сообщений
info() {
    echo_color $YELLOW "ℹ $1"
}

# Проверка, запущен ли скрипт от имени root
if [ "$EUID" -ne 0 ]; then
    error "Этот скрипт должен быть запущен от имени root или с sudo."
    exit 1
fi

# Отображение приветственного сообщения
section "Установка FaceForm Web на VPS"
echo "Этот скрипт автоматизирует установку веб-части FaceForm на ваш VPS сервер."
echo "Убедитесь, что у вас есть:"
echo "  - VPS сервер с Ubuntu 20.04 или новее"
echo "  - Минимум 2 ГБ оперативной памяти"
echo "  - Минимум 10 ГБ дискового пространства"
echo "  - Домен (опционально, но рекомендуется)"
echo

read -p "Хотите продолжить установку? (y/n): " confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo "Установка отменена."
    exit 0
fi

# Проверка наличия необходимого ПО
section "Проверка необходимого ПО"

# Обновление списка пакетов
info "Обновление списка пакетов..."
apt-get update -q

# Установка базовых зависимостей
info "Установка базовых зависимостей..."
apt-get install -y python3 python3-pip python3-dev python3-venv \
    build-essential libpq-dev nginx curl wget git

success "Базовые зависимости установлены."

# Создание директории проекта
section "Настройка директории проекта"
read -p "Введите путь для установки проекта FaceForm [/opt/faceform]: " project_dir
project_dir=${project_dir:-/opt/faceform}

if [ -d "$project_dir" ]; then
    warning "Директория $project_dir уже существует."
    read -p "Хотите удалить существующую директорию и продолжить? (y/n): " remove_dir
    if [[ "$remove_dir" == "y" || "$remove_dir" == "Y" ]]; then
        rm -rf "$project_dir"
        mkdir -p "$project_dir"
    else
        error "Установка отменена. Пожалуйста, выберите другую директорию."
        exit 1
    fi
else
    mkdir -p "$project_dir"
fi

success "Директория проекта создана в $project_dir"

# Выбор источника проекта
section "Получение файлов проекта FaceForm"
echo "Выберите способ получения файлов проекта FaceForm:"
echo "1. Скачать с GitHub (рекомендуется)"
echo "2. Использовать локальный архив"

read -p "Введите ваш выбор (1-2): " download_choice

case $download_choice in
    1)
        # Опция GitHub
        info "Скачивание с GitHub..."
        git_url="https://github.com/yourusername/faceform.git"
        read -p "Введите URL GitHub репозитория [$git_url]: " input_git_url
        git_url=${input_git_url:-$git_url}
        
        cd "$project_dir"
        git clone "$git_url" .
        if [ $? -ne 0 ]; then
            error "Не удалось клонировать репозиторий. Пожалуйста, проверьте URL и попробуйте снова."
            exit 1
        fi
        success "Файлы проекта загружены с GitHub."
        ;;
    2)
        # Опция локального архива
        info "Использование локального архива..."
        read -p "Введите путь к архиву проекта FaceForm: " archive_path
        
        if [ ! -f "$archive_path" ]; then
            error "Файл архива не найден по пути $archive_path"
            exit 1
        fi
        
        # Проверка типа архива и извлечение
        cd "$project_dir"
        if [[ "$archive_path" == *.zip ]]; then
            apt-get install -y unzip
            unzip "$archive_path" -d .
        elif [[ "$archive_path" == *.tar.gz ]]; then
            tar -xzf "$archive_path" -C .
        else
            error "Неподдерживаемый формат архива. Пожалуйста, используйте .zip или .tar.gz"
            exit 1
        fi
        
        success "Файлы проекта извлечены из локального архива."
        ;;
    *)
        error "Неверный выбор. Установка прервана."
        exit 1
        ;;
esac

# Настройка Python виртуального окружения
section "Настройка Python виртуального окружения"
cd "$project_dir"
python3 -m venv venv
source venv/bin/activate

# Установка Python зависимостей
info "Установка Python зависимостей..."
pip install --upgrade pip
pip install -r requirements.txt || {
    warning "requirements.txt не найден. Устанавливаем основные пакеты..."
    pip install flask flask-sqlalchemy flask-login flask-wtf flask-session gunicorn \
        werkzeug python-dotenv psycopg2-binary email-validator opencv-python numpy \
        pillow matplotlib requests sqlalchemy
}

success "Python виртуальное окружение настроено и зависимости установлены."

# Настройка PostgreSQL
section "Настройка базы данных PostgreSQL"
info "Установка PostgreSQL..."
apt-get install -y postgresql postgresql-contrib

# Создание пользователя базы данных и самой базы для FaceForm
db_name="faceform"
db_user="faceform_user"
db_password=$(openssl rand -base64 16 | tr -dc 'a-zA-Z0-9' | head -c 16)

info "Создание пользователя PostgreSQL и базы данных..."
sudo -u postgres psql -c "CREATE USER $db_user WITH PASSWORD '$db_password';"
sudo -u postgres psql -c "CREATE DATABASE $db_name OWNER $db_user;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $db_name TO $db_user;"

success "База данных PostgreSQL настроена."

# Создание файла .env
section "Настройка переменных окружения"
cat > "$project_dir/.env" << EOF
# Конфигурация базы данных
DATABASE_URL=postgresql://${db_user}:${db_password}@localhost:5432/${db_name}
PGUSER=${db_user}
PGPASSWORD=${db_password}
PGHOST=localhost
PGPORT=5432
PGDATABASE=${db_name}

# Конфигурация Flask
SECRET_KEY=$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9' | head -c 24)
FLASK_SECRET_KEY=$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9' | head -c 24)
SESSION_SECRET=$(openssl rand -base64 24 | tr -dc 'a-zA-Z0-9' | head -c 24)

# Конфигурация Stripe (замените на ваши реальные ключи)
STRIPE_PUBLIC_KEY=pk_test_your_key
STRIPE_SECRET_KEY=sk_test_your_key

# Серверная конфигурация
PORT=5000
FLASK_ENV=production
EOF

success "Переменные окружения настроены."

# Настройка Nginx
section "Настройка Nginx"
read -p "Хотите настроить Nginx как обратный прокси? (y/n): " setup_nginx
if [[ "$setup_nginx" == "y" || "$setup_nginx" == "Y" ]]; then
    read -p "Введите ваше доменное имя (например, faceform.example.com): " domain_name
    
    # Создание конфигурации Nginx
    cat > /etc/nginx/sites-available/faceform << EOF
server {
    listen 80;
    server_name ${domain_name};

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location /static {
        alias ${project_dir}/static;
        expires 30d;
    }
    
    # Увеличенный размер загрузки для изображений
    client_max_body_size 10M;
}
EOF

    # Включение сайта
    ln -sf /etc/nginx/sites-available/faceform /etc/nginx/sites-enabled/
    
    # Проверка конфигурации Nginx
    nginx -t
    
    # Перезапуск Nginx
    systemctl restart nginx
    
    success "Nginx настроен для домена $domain_name"
    
    # Настройка SSL с помощью Certbot
    read -p "Хотите настроить SSL с Let's Encrypt? (y/n): " setup_ssl
    if [[ "$setup_ssl" == "y" || "$setup_ssl" == "Y" ]]; then
        apt-get install -y certbot python3-certbot-nginx
        certbot --nginx --non-interactive --agree-tos --email admin@$domain_name -d $domain_name
        
        success "SSL сертификат установлен для $domain_name"
    else
        info "Настройка SSL пропущена. Вы можете настроить его позже с помощью: certbot --nginx -d $domain_name"
    fi
fi

# Создание systemd службы для Gunicorn
section "Настройка systemd службы"
cat > /etc/systemd/system/faceform.service << EOF
[Unit]
Description=FaceForm Gunicorn Service
After=network.target postgresql.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=${project_dir}
Environment="PATH=${project_dir}/venv/bin"
ExecStart=${project_dir}/venv/bin/gunicorn --workers 3 --bind 0.0.0.0:5000 --timeout 120 main:app

[Install]
WantedBy=multi-user.target
EOF

# Настройка прав доступа
chown -R www-data:www-data "$project_dir"
systemctl daemon-reload

# Запуск и активация службы
systemctl start faceform
systemctl enable faceform

success "Служба systemd создана и запущена."

# Финальные инструкции
section "Установка завершена"
echo "FaceForm Web успешно установлен на ваш VPS!"
echo
echo "Важная информация:"
echo "  - Директория проекта: $project_dir"
echo "  - Имя базы данных: $db_name"
echo "  - Пользователь базы данных: $db_user"
echo "  - Пароль базы данных: $db_password"
echo
echo "Следующие шаги:"
echo "  1. Отредактируйте $project_dir/.env, чтобы добавить ваши API-ключи и другие настройки"
echo "  2. Посетите http://$domain_name (или IP-адрес) для доступа к приложению"
echo
echo "Для проверки статуса приложения:"
echo "  - systemctl status faceform"
echo "  - journalctl -u faceform"
echo
echo "Спасибо за использование FaceForm!"