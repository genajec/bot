#!/bin/bash
#
# Скрипт для установки FaceForm на VPS (Ubuntu 24.04.2 LTS)
#
# Запуск: ./create_vps_setup.sh
#

set -e

# Цвета для вывода
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Конфигурация
APP_NAME="faceform"
APP_USER="faceform"
APP_DIR="/home/$APP_USER/faceform_app"
DOMAIN="faceform.vps.webdock.cloud"
IP_ADDRESS="92.113.145.171"

# Функции
echo_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

echo_error() {
    echo -e "${RED}[ERROR]${NC} $1" >&2
}

echo_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Проверка окружения
if [[ $(whoami) != "faceform" && $(whoami) != "root" ]]; then
    echo_error "Скрипт должен запускаться от имени пользователя 'faceform' или 'root'"
    exit 1
fi

# Проверка наличия необходимых утилит
REQUIRED_UTILS=("python3" "pip3" "virtualenv" "postgresql" "nginx")
for util in "${REQUIRED_UTILS[@]}"; do
    if ! command -v $util &> /dev/null; then
        echo_warning "Утилита $util не установлена. Попытка установки..."
        
        # Установка необходимых утилит
        if [ $(whoami) == "root" ]; then
            apt-get update && apt-get install -y $util
        else
            echo_warning "У вас нет прав суперпользователя. Установите $util вручную:"
            echo "sudo apt-get update && sudo apt-get install -y $util"
            exit 1
        fi
    fi
done

echo_status "Все необходимые утилиты установлены"

# Создание директорий для приложения
echo_status "Создание директорий для приложения..."
mkdir -p "$APP_DIR"
mkdir -p "$APP_DIR/logs"
mkdir -p "$APP_DIR/uploads"
mkdir -p "$APP_DIR/flask_session"

# Создание виртуального окружения
echo_status "Создание виртуального окружения..."
cd "$APP_DIR"
python3 -m virtualenv venv
source venv/bin/activate

# Установка зависимостей
echo_status "Установка зависимостей..."
pip install -r requirements.txt

# Настройка .env файла
echo_status "Настройка .env файла..."
if [ -f ".env.example" ]; then
    cp .env.example .env
    echo "DATABASE_URL=postgresql://faceform:faceform_password@localhost/faceform" >> .env
    echo "FLASK_SECRET_KEY=faceform_secure_secret_key_for_production_environment" >> .env
    echo "HOST=$DOMAIN" >> .env
    echo "PORT=5000" >> .env
    echo "LOG_LEVEL=INFO" >> .env
    echo "LIGHTX_API_KEYS=af1fde54...,d4bd48c9...,4d2c3274...,a271d490...,eeee6d2b..." >> .env
else
    echo_error "Файл .env.example не найден"
    exit 1
fi

# Настройка PostgreSQL
echo_status "Настройка PostgreSQL..."
if [ $(whoami) == "root" ]; then
    # Создание пользователя и базы данных PostgreSQL
    su - postgres -c "psql -c \"CREATE USER faceform WITH PASSWORD 'faceform_password';\""
    su - postgres -c "psql -c \"CREATE DATABASE faceform OWNER faceform;\""
    echo_status "База данных PostgreSQL успешно настроена"
else
    echo_warning "У вас нет прав суперпользователя. Настройте PostgreSQL вручную:"
    echo "sudo -u postgres psql -c \"CREATE USER faceform WITH PASSWORD 'faceform_password';\""
    echo "sudo -u postgres psql -c \"CREATE DATABASE faceform OWNER faceform;\""
fi

# Настройка службы systemd
echo_status "Настройка службы systemd..."
if [ $(whoami) == "root" ]; then
    cat > /etc/systemd/system/$APP_NAME.service << EOF
[Unit]
Description=FaceForm Application
After=network.target postgresql.service

[Service]
User=$APP_USER
Group=$APP_USER
WorkingDirectory=$APP_DIR
Environment="PATH=$APP_DIR/venv/bin"
ExecStart=$APP_DIR/venv/bin/gunicorn --workers 4 --bind 0.0.0.0:5000 main:app
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable $APP_NAME
    systemctl start $APP_NAME
    echo_status "Служба systemd успешно настроена"
else
    echo_warning "У вас нет прав суперпользователя. Создайте службу systemd вручную:"
    cat > $APP_NAME.service << EOF
[Unit]
Description=FaceForm Application
After=network.target postgresql.service

[Service]
User=$APP_USER
Group=$APP_USER
WorkingDirectory=$APP_DIR
Environment="PATH=$APP_DIR/venv/bin"
ExecStart=$APP_DIR/venv/bin/gunicorn --workers 4 --bind 0.0.0.0:5000 main:app
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
    echo_warning "Скопируйте файл $APP_NAME.service в /etc/systemd/system/ и выполните:"
    echo "sudo systemctl daemon-reload"
    echo "sudo systemctl enable $APP_NAME"
    echo "sudo systemctl start $APP_NAME"
fi

# Настройка Nginx
echo_status "Настройка Nginx..."
if [ $(whoami) == "root" ]; then
    cat > /etc/nginx/sites-available/$DOMAIN << EOF
server {
    listen 80;
    server_name $DOMAIN $IP_ADDRESS;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_buffering off;
        client_max_body_size 100M;
    }

    location /static {
        alias $APP_DIR/static;
        expires 30d;
    }

    location /uploads {
        alias $APP_DIR/uploads;
        expires 30d;
    }

    error_log /var/log/nginx/$APP_NAME.error.log;
    access_log /var/log/nginx/$APP_NAME.access.log;
}
EOF

    ln -sf /etc/nginx/sites-available/$DOMAIN /etc/nginx/sites-enabled/
    systemctl restart nginx
    echo_status "Nginx успешно настроен"
else
    echo_warning "У вас нет прав суперпользователя. Настройте Nginx вручную:"
    cat > $DOMAIN << EOF
server {
    listen 80;
    server_name $DOMAIN $IP_ADDRESS;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_buffering off;
        client_max_body_size 100M;
    }

    location /static {
        alias $APP_DIR/static;
        expires 30d;
    }

    location /uploads {
        alias $APP_DIR/uploads;
        expires 30d;
    }

    error_log /var/log/nginx/$APP_NAME.error.log;
    access_log /var/log/nginx/$APP_NAME.access.log;
}
EOF
    echo_warning "Скопируйте файл $DOMAIN в /etc/nginx/sites-available/ и выполните:"
    echo "sudo ln -sf /etc/nginx/sites-available/$DOMAIN /etc/nginx/sites-enabled/"
    echo "sudo systemctl restart nginx"
fi

# Создание администратора
echo_status "Создание администратора..."
cd "$APP_DIR"
source venv/bin/activate
python create_admin.py --username admin --email admin@$DOMAIN --password faceform_admin2025

echo_status "Установка FaceForm завершена!"
echo_status "Сайт доступен по адресу: http://$DOMAIN и http://$IP_ADDRESS"
echo_status "Логин администратора: admin"
echo_status "Пароль администратора: faceform_admin2025"

# Альтернативный запуск без systemd
echo_warning "Если у вас нет прав для настройки systemd и nginx, вы можете запустить приложение вручную:"
echo "cd $APP_DIR"
echo "source venv/bin/activate"
echo "gunicorn --workers 4 --bind 0.0.0.0:5000 main:app"
echo_warning "Либо запустить в фоновом режиме:"
echo "cd $APP_DIR"
echo "source venv/bin/activate"
echo "nohup gunicorn --workers 4 --bind 0.0.0.0:5000 main:app > logs/gunicorn.log 2>&1 &"