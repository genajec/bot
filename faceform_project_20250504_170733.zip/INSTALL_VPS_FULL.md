# FaceForm VPS Comprehensive Installation Guide

This detailed guide covers the complete installation and configuration of the FaceForm application on a VPS server, including advanced configurations and integrations.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [System Preparation](#system-preparation)
3. [FaceForm Installation](#faceform-installation)
4. [Database Configuration](#database-configuration)
5. [Web Server Setup](#web-server-setup)
6. [External API Configuration](#external-api-configuration)
7. [Telegram Bot Setup](#telegram-bot-setup)
8. [Performance Optimization](#performance-optimization)
9. [Security Enhancements](#security-enhancements)
10. [Backup and Recovery](#backup-and-recovery)
11. [Monitoring and Maintenance](#monitoring-and-maintenance)
12. [Troubleshooting](#troubleshooting)

## Prerequisites

### Hardware Requirements

- VPS with at least 2GB RAM
- 2+ CPU cores
- 20+ GB SSD storage (recommended)
- Ubuntu 20.04 LTS or newer

### Software Requirements

- Python 3.8+
- PostgreSQL 12+
- Nginx
- UFW (Uncomplicated Firewall)
- Let's Encrypt SSL (if using a domain)

### Domain Requirements

- A registered domain name (recommended for production use)
- DNS configured to point to your VPS IP

## System Preparation

### Initial Server Setup

1. Update the system:

```bash
sudo apt update && sudo apt upgrade -y
```

2. Install essential packages:

```bash
sudo apt install -y python3 python3-pip python3-dev python3-venv \
    build-essential libpq-dev nginx curl wget git \
    libsm6 libxext6 libxrender-dev libfontconfig1 \
    libgl1-mesa-glx ffmpeg
```

3. Configure your timezone:

```bash
sudo timedatectl set-timezone UTC
```

4. Set up a basic firewall:

```bash
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

## FaceForm Installation

### Automated Installation

The simplest way to install FaceForm is using our automated script:

1. Transfer the installation files to your VPS:

```bash
scp faceform_vps_project.tar.gz setup_faceform_vps.sh username@your-vps-ip:/home/username/
```

2. Run the installation script:

```bash
sudo ./setup_faceform_vps.sh
```

3. Follow the on-screen prompts, selecting option 3 to use the local archive.

### Manual Installation

If you prefer a manual installation:

1. Create a project directory:

```bash
sudo mkdir -p /opt/faceform
```

2. Extract the project files:

```bash
sudo tar -xzf faceform_vps_project.tar.gz -C /opt/faceform
```

3. Create a Python virtual environment:

```bash
cd /opt/faceform
sudo python3 -m venv venv
sudo source venv/bin/activate
sudo pip install --upgrade pip
sudo pip install -r requirements.txt
```

4. Set proper permissions:

```bash
sudo chown -R www-data:www-data /opt/faceform
sudo chmod -R 755 /opt/faceform
```

## Database Configuration

### Setting Up PostgreSQL

1. Install PostgreSQL:

```bash
sudo apt install -y postgresql postgresql-contrib
```

2. Create a database and user:

```bash
sudo -u postgres psql -c "CREATE USER faceform_user WITH PASSWORD 'your_secure_password';"
sudo -u postgres psql -c "CREATE DATABASE faceform OWNER faceform_user;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE faceform TO faceform_user;"
```

3. Configure environment variables for database access:

```bash
cat > /opt/faceform/.env << EOF
# Database Configuration
DATABASE_URL=postgresql://faceform_user:your_secure_password@localhost:5432/faceform
PGUSER=faceform_user
PGPASSWORD=your_secure_password
PGHOST=localhost
PGPORT=5432
PGDATABASE=faceform
EOF
```

### Database Optimization

For improved performance:

1. Edit PostgreSQL configuration:

```bash
sudo nano /etc/postgresql/12/main/postgresql.conf
```

2. Add or modify these settings based on your VPS resources:

```
# Memory settings
shared_buffers = 512MB
work_mem = 16MB
maintenance_work_mem = 128MB

# Query planner
effective_cache_size = 1536MB
random_page_cost = 1.1

# Checkpoint settings
checkpoint_completion_target = 0.9
max_wal_size = 1GB
min_wal_size = 80MB
```

3. Restart PostgreSQL:

```bash
sudo systemctl restart postgresql
```

## Web Server Setup

### Configuring Nginx

1. Create an Nginx server block:

```bash
sudo nano /etc/nginx/sites-available/faceform
```

2. Add the following configuration:

```nginx
server {
    listen 80;
    server_name your-domain.com;  # Use your actual domain or VPS IP

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /static {
        alias /opt/faceform/static;
        expires 30d;
    }

    # Larger upload size for image uploads
    client_max_body_size 10M;
}
```

3. Enable the site:

```bash
sudo ln -s /etc/nginx/sites-available/faceform /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### SSL Configuration

If you have a domain name, secure your site with SSL:

1. Install Certbot:

```bash
sudo apt install -y certbot python3-certbot-nginx
```

2. Obtain and configure SSL certificates:

```bash
sudo certbot --nginx -d your-domain.com
```

3. Set up auto-renewal:

```bash
sudo systemctl status certbot.timer
```

## External API Configuration

### LightX API Setup

FaceForm relies on LightX API for AI image processing capabilities:

1. Add your LightX API keys to the .env file:

```bash
sudo nano /opt/faceform/.env
```

2. Add the following lines:

```
# LightX API Configuration
LIGHTX_API_KEY=your_main_lightx_api_key
LIGHTX_API_KEY_1=your_lightx_api_key_1
LIGHTX_API_KEY_2=your_lightx_api_key_2
LIGHTX_API_KEY_3=your_lightx_api_key_3
LIGHTX_API_KEY_4=your_lightx_api_key_4
```

3. Configure key rotation settings:

```
LIGHTX_KEY_ROTATION_ENABLED=true
LIGHTX_KEY_ROTATION_INTERVAL=300  # Rotate keys every 300 seconds
LIGHTX_KEY_ERROR_THRESHOLD=3      # Switch key after 3 errors
```

### Stripe Payment Integration

For payment processing:

1. Add your Stripe API keys:

```
STRIPE_PUBLIC_KEY=pk_live_your_stripe_public_key
STRIPE_SECRET_KEY=sk_live_your_stripe_secret_key
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret
```

2. Configure payment packages:

```
STRIPE_BASIC_PACKAGE_PRICE_ID=price_1xyz123
STRIPE_STANDARD_PACKAGE_PRICE_ID=price_2xyz456
STRIPE_PREMIUM_PACKAGE_PRICE_ID=price_3xyz789
```

## Telegram Bot Setup

### Webhook Mode (Recommended for Production)

1. Configure your Telegram bot token:

```
TELEGRAM_BOT_TOKEN=your_telegram_bot_token
TELEGRAM_WEBHOOK_URL=https://your-domain.com/webhook
```

2. Set up the bot service:

```bash
sudo systemctl start faceform-bot
sudo systemctl enable faceform-bot
```

### Polling Mode (Alternative)

If you don't have a domain with SSL:

1. Follow the instructions in [INSTALL_VPS_POLLING.md](INSTALL_VPS_POLLING.md) to set up polling mode.

## Performance Optimization

### Gunicorn Configuration

For better performance, customize your Gunicorn settings:

1. Edit the systemd service file:

```bash
sudo nano /etc/systemd/system/faceform.service
```

2. Update the ExecStart line:

```
ExecStart=/opt/faceform/venv/bin/gunicorn --workers 4 --worker-class=gthread --threads 2 --bind 0.0.0.0:5000 --timeout 120 main:app
```

Adjust the number of workers based on your VPS CPU cores (typically 2*cores + 1).

### Redis Cache (Optional)

For improved performance with high traffic:

1. Install Redis:

```bash
sudo apt install -y redis-server
```

2. Configure Flask to use Redis:

Add to .env:
```
REDIS_URL=redis://localhost:6379/0
```

## Security Enhancements

### Fail2Ban Setup

Protect against brute force attacks:

1. Install Fail2Ban:

```bash
sudo apt install -y fail2ban
```

2. Create a custom jail for Nginx:

```bash
sudo nano /etc/fail2ban/jail.d/nginx.conf
```

3. Add the following configuration:

```
[nginx-http-auth]
enabled = true
filter = nginx-http-auth
port = http,https
logpath = /var/log/nginx/error.log
maxretry = 5
bantime = 3600
```

4. Restart Fail2Ban:

```bash
sudo systemctl restart fail2ban
```

### Database Backup Automation

Set up automatic database backups:

1. Create a backup script:

```bash
sudo nano /opt/faceform/backup.sh
```

2. Add the following content:

```bash
#!/bin/bash
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="/opt/faceform/backups"
mkdir -p $BACKUP_DIR

# Backup the database
pg_dump -U faceform_user -h localhost faceform > $BACKUP_DIR/faceform_$TIMESTAMP.sql

# Compress the backup
gzip $BACKUP_DIR/faceform_$TIMESTAMP.sql

# Keep only the last 7 backups
ls -t $BACKUP_DIR/faceform_*.sql.gz | tail -n +8 | xargs -r rm
```

3. Make it executable:

```bash
sudo chmod +x /opt/faceform/backup.sh
```

4. Set up a cron job:

```bash
sudo crontab -e
```

5. Add this line to run daily backups at 3 AM:

```
0 3 * * * /opt/faceform/backup.sh
```

## Backup and Recovery

### Full System Backup

Periodically create a full backup of your FaceForm installation:

1. Create a backup script:

```bash
sudo nano /opt/faceform/full_backup.sh
```

2. Add the following content:

```bash
#!/bin/bash
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="/opt/faceform/backups"
mkdir -p $BACKUP_DIR

# Backup the database
pg_dump -U faceform_user -h localhost faceform > $BACKUP_DIR/faceform_db_$TIMESTAMP.sql
gzip $BACKUP_DIR/faceform_db_$TIMESTAMP.sql

# Backup the application files
tar -czf $BACKUP_DIR/faceform_app_$TIMESTAMP.tar.gz -C /opt faceform

# Backup the configuration files
tar -czf $BACKUP_DIR/faceform_config_$TIMESTAMP.tar.gz /etc/nginx/sites-available/faceform /etc/systemd/system/faceform*.service

# Keep only the last 5 full backups
for prefix in faceform_db_ faceform_app_ faceform_config_; do
    ls -t $BACKUP_DIR/${prefix}* | tail -n +6 | xargs -r rm
done
```

3. Make it executable and run monthly:

```bash
sudo chmod +x /opt/faceform/full_backup.sh
sudo crontab -e
```

4. Add this line:

```
0 2 1 * * /opt/faceform/full_backup.sh
```

### Disaster Recovery

To restore from backups:

1. Database restoration:

```bash
gunzip -c /opt/faceform/backups/faceform_db_TIMESTAMP.sql.gz | sudo -u postgres psql faceform
```

2. Application files restoration:

```bash
sudo tar -xzf /opt/faceform/backups/faceform_app_TIMESTAMP.tar.gz -C /opt
```

## Monitoring and Maintenance

### Log Rotation

Configure log rotation to prevent logs from filling your disk:

1. Create a log rotation configuration:

```bash
sudo nano /etc/logrotate.d/faceform
```

2. Add the following content:

```
/opt/faceform/logs/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 www-data www-data
    sharedscripts
    postrotate
        systemctl reload faceform.service
    endscript
}
```

### System Monitoring

Set up basic monitoring with Glances:

1. Install Glances:

```bash
sudo apt install -y glances
```

2. Start Glances in web server mode:

```bash
sudo glances -w -p 61208 -B 127.0.0.1
```

3. Add Nginx configuration for secure access:

```bash
sudo nano /etc/nginx/sites-available/glances
```

4. Add the following content:

```nginx
server {
    listen 80;
    server_name monitor.your-domain.com;

    auth_basic "Restricted";
    auth_basic_user_file /etc/nginx/.htpasswd;

    location / {
        proxy_pass http://127.0.0.1:61208;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

5. Create a password file:

```bash
sudo apt install -y apache2-utils
sudo htpasswd -c /etc/nginx/.htpasswd admin
```

## Troubleshooting

### Common Issues and Solutions

#### Application Won't Start

1. Check the logs:

```bash
sudo journalctl -u faceform -n 100
```

2. Verify the database connection in .env file

3. Make sure all required environment variables are set

#### Database Connection Errors

1. Verify PostgreSQL is running:

```bash
sudo systemctl status postgresql
```

2. Check database credentials in .env file

3. Test the connection manually:

```bash
psql -U faceform_user -h localhost -d faceform -W
```

#### Telegram Bot Issues

1. Check the bot logs:

```bash
sudo journalctl -u faceform-bot -n 100
```

2. Verify your bot token is correct

3. For webhook mode, ensure SSL is properly configured

4. Try switching to polling mode temporarily to test

#### NGINX Configuration Issues

1. Check NGINX configuration for errors:

```bash
sudo nginx -t
```

2. Verify logs for specific errors:

```bash
sudo tail -f /var/log/nginx/error.log
```

#### Memory/CPU Issues

If the application is slow or unresponsive:

1. Check system resources:

```bash
top
```

2. Consider adding swap space:

```bash
sudo fallocate -l 1G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

## Support and Resources

If you encounter any issues not covered in this guide, please contact our support team or refer to the following resources:

- FaceForm Documentation: https://faceform.example.com/docs
- GitHub Repository: https://github.com/yourusername/faceform
- Support Email: support@faceform.example.com