#!/usr/bin/env python
"""
Скрипт для создания полного архива проекта FaceForm.
Создает tar.gz архив со всеми файлами проекта, который можно скачать.
"""

import os
import sys
import tarfile
import shutil
import datetime
import tempfile
import logging
import time
import io

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_full_project_archive(output_dir=None):
    """
    Создает полный архив проекта, включающий все исходные файлы.
    
    Args:
        output_dir (str, optional): Директория для сохранения архива.
            По умолчанию используется ~/faceform_archives
            
    Returns:
        str: Путь к созданному архиву или None в случае ошибки
    """
    try:
        # Определение корневой директории проекта (текущая директория)
        project_root = os.path.abspath(os.getcwd())
        logger.info(f"Корневая директория проекта: {project_root}")
        
        # Определение директории для сохранения архива
        if output_dir is None:
            output_dir = os.path.expanduser("~/faceform_archives")
        
        # Создаем директорию для архивов, если она не существует
        os.makedirs(output_dir, exist_ok=True)
        
        # Имя архива с временной меткой
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        archive_name = f"faceform_full_project_{timestamp}.tar.gz"
        archive_path = os.path.join(output_dir, archive_name)
        
        # Создаем копию faceform_full_project.tar.gz для использования в веб-интерфейсе
        web_archive_path = os.path.join(output_dir, "faceform_full_project.tar.gz")
        
        logger.info(f"Создание архива: {archive_path}")
        
        # Файлы и директории, которые нужно исключить из архива
        exclude_patterns = [
            "__pycache__",
            "*.pyc",
            "*.pyo",
            "*.pyd",
            ".git",
            ".env",
            "venv",
            ".venv",
            "node_modules",
            "faceform_archives",
            "*.tar.gz",
            "*.zip",
            "tmp"
        ]
        
        # Создаем README для архива
        readme_content = """# FaceForm - Полный архив проекта

Создан: {0}

Этот архив содержит все исходные файлы проекта FaceForm.
Для запуска проекта:
1. Установите необходимые зависимости: pip install -r requirements.txt
2. Настройте переменные окружения согласно .env.example
3. Настройте базу данных PostgreSQL
4. Запустите сервер: python main.py или gunicorn main:app

Примечание: этот архив не содержит переменные окружения и базу данных.
Для полного переноса проекта используйте скрипт export_db_and_env.py.
""".format(datetime.datetime.now())
            
        # Прямое добавление файлов в архив без использования временной директории
        with tarfile.open(archive_path, "w:gz") as tar:
            # Добавляем README напрямую из строки
            readme_info = tarfile.TarInfo(name="faceform_project/README.txt")
            readme_bytes = readme_content.encode('utf-8')
            readme_info.size = len(readme_bytes)
            readme_info.mtime = int(time.time())
            tar.addfile(readme_info, io.BytesIO(readme_bytes))
            
            # Добавляем файлы из текущей директории, исключая ненужные
            for item in os.listdir(project_root):
                # Проверяем, нужно ли исключить этот файл или директорию
                skip = False
                for pattern in exclude_patterns:
                    if pattern.startswith("*") and item.endswith(pattern[1:]):
                        skip = True
                        break
                    elif pattern == item:
                        skip = True
                        break
                
                if skip:
                    logger.info(f"Пропускаем: {item}")
                    continue
                
                # Добавляем файл или директорию в архив
                item_path = os.path.join(project_root, item)
                arcname = os.path.join("faceform_project", item)
                
                try:
                    if os.path.isfile(item_path):
                        tar.add(item_path, arcname=arcname)
                    elif os.path.isdir(item_path):
                        # Для директорий добавляем файлы внутри рекурсивно
                        for dirpath, dirnames, filenames in os.walk(item_path):
                            # Исключаем ненужные поддиректории из списка, чтобы не обходить их
                            dirnames[:] = [d for d in dirnames if d not in exclude_patterns and not any(
                                p.startswith("*") and d.endswith(p[1:]) for p in exclude_patterns
                            )]
                            
                            for filename in filenames:
                                # Исключаем файлы с ненужными расширениями
                                if not any(filename.endswith(p[1:]) for p in exclude_patterns if p.startswith("*")):
                                    file_path = os.path.join(dirpath, filename)
                                    rel_path = os.path.relpath(file_path, project_root)
                                    arc_path = os.path.join("faceform_project", rel_path)
                                    tar.add(file_path, arcname=arc_path)
                except Exception as e:
                    logger.warning(f"Не удалось добавить {item} в архив: {str(e)}")
        
        # Создаем копию для веб-интерфейса
        shutil.copy2(archive_path, web_archive_path)
        
        logger.info(f"Архив успешно создан: {archive_path}")
        logger.info(f"Копия архива для веб-интерфейса: {web_archive_path}")
        
        return archive_path
    
    except Exception as e:
        logger.error(f"Ошибка при создании архива проекта: {str(e)}")
        return None

if __name__ == "__main__":
    # Если указана директория в аргументах командной строки, используем её
    output_dir = sys.argv[1] if len(sys.argv) > 1 else None
    
    archive_path = create_full_project_archive(output_dir)
    
    if archive_path:
        print(f"Архив успешно создан: {archive_path}")
        print(f"Вы можете скачать его по адресу: /download_full_project")
    else:
        print("Не удалось создать архив проекта")