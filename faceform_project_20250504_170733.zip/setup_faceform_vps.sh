#!/bin/bash
# Скрипт установки FaceForm на VPS faceform.vps.webdock.cloud (92.113.145.171)

set -e

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Функции для форматированного вывода
info() { echo -e "${YELLOW}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; }
warn() { echo -e "${RED}[WARNING]${NC} $1"; }

# Параметры установки
PROJECT_NAME="faceform"
PROJECT_DIR="/opt/${PROJECT_NAME}"
SYSTEM_USER="${PROJECT_NAME}"
DOMAIN="faceform.vps.webdock.cloud"
IP_ADDRESS="92.113.145.171"

# Проверка прав root
if [ "$(id -u)" -ne 0 ]; then
   error "Этот скрипт должен быть запущен с правами root"
   exit 1
fi

info "Начинаем установку FaceForm на VPS $DOMAIN ($IP_ADDRESS)..."

# Обновление системы и установка зависимостей
info "Обновление системы и установка зависимостей..."
apt-get update
apt-get install -y python3 python3-pip python3-venv postgresql postgresql-contrib nginx supervisor git

# Создание пользователя и директории проекта
info "Создание пользователя и директории проекта..."
id -u $SYSTEM_USER &>/dev/null || adduser --system --group --no-create-home $SYSTEM_USER
mkdir -p $PROJECT_DIR
chown -R $SYSTEM_USER:$SYSTEM_USER $PROJECT_DIR

# Копирование файлов проекта
info "Копирование файлов проекта..."
if [ -d "faceform_project" ]; then
    cp -r faceform_project/* $PROJECT_DIR/ || { error "Не удалось скопировать файлы проекта"; exit 1; }
    success "Файлы проекта скопированы из faceform_project"
else
    error "Директория faceform_project не найдена. Пожалуйста, убедитесь, что вы распаковали архив проекта."
    exit 1
fi

# Создание директорий для загрузок и сессий
mkdir -p $PROJECT_DIR/uploads
mkdir -p $PROJECT_DIR/flask_session
chown -R $SYSTEM_USER:$SYSTEM_USER $PROJECT_DIR/uploads
chown -R $SYSTEM_USER:$SYSTEM_USER $PROJECT_DIR/flask_session

# Создание виртуального окружения
info "Создание виртуального окружения Python..."
python3 -m venv $PROJECT_DIR/venv
source $PROJECT_DIR/venv/bin/activate

# Установка зависимостей Python
info "Установка зависимостей Python..."
pip install --upgrade pip

if [ -f "$PROJECT_DIR/requirements.txt" ]; then
    pip install -r $PROJECT_DIR/requirements.txt || { error "Не удалось установить зависимости Python"; exit 1; }
else
    pip install flask flask-sqlalchemy gunicorn psycopg2-binary Flask-Login Flask-WTF email-validator python-dotenv
    warn "Файл requirements.txt не найден. Установлены базовые зависимости."
fi

# Настройка PostgreSQL
info "Настройка базы данных PostgreSQL..."
DB_NAME="faceform"
DB_USER="faceform_user"
DB_PASS=$(openssl rand -hex 8)

sudo -u postgres psql -c "CREATE DATABASE $DB_NAME WITH ENCODING 'UTF8';"
sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"

# Создание .env файла
info "Создание .env файла..."
if [ -f "$PROJECT_DIR/.env.example" ]; then
    cp $PROJECT_DIR/.env.example $PROJECT_DIR/.env
    sed -i "s#DATABASE_URL=postgresql://username:password@localhost/faceform#DATABASE_URL=postgresql://$DB_USER:$DB_PASS@localhost/$DB_NAME#g" $PROJECT_DIR/.env
    sed -i "s#SECRET_KEY=your_secret_key_here#SECRET_KEY=$(openssl rand -hex 16)#g" $PROJECT_DIR/.env
    sed -i "s#SERVER_NAME=localhost:5000#SERVER_NAME=$DOMAIN#g" $PROJECT_DIR/.env 2>/dev/null || echo "SERVER_NAME not found in .env.example"
else
    cat > $PROJECT_DIR/.env << EOL
FLASK_APP=main.py
FLASK_ENV=production
SECRET_KEY=$(openssl rand -hex 16)
DATABASE_URL=postgresql://$DB_USER:$DB_PASS@localhost/$DB_NAME
SERVER_NAME=$DOMAIN
EOL
fi

# Настройка Gunicorn systemd service
info "Настройка Gunicorn как systemd сервиса..."
cat > /etc/systemd/system/faceform.service << EOL
[Unit]
Description=Gunicorn instance to serve FaceForm
After=network.target postgresql.service

[Service]
User=$SYSTEM_USER
Group=$SYSTEM_USER
WorkingDirectory=$PROJECT_DIR
Environment="PATH=$PROJECT_DIR/venv/bin"
EnvironmentFile=$PROJECT_DIR/.env
ExecStart=$PROJECT_DIR/venv/bin/gunicorn --workers 3 --bind 0.0.0.0:5000 --access-logfile /var/log/faceform/access.log --error-logfile /var/log/faceform/error.log main:app

[Install]
WantedBy=multi-user.target
EOL

# Создание директории для логов
mkdir -p /var/log/faceform
chown -R $SYSTEM_USER:$SYSTEM_USER /var/log/faceform

# Копирование конфигурации Nginx
if [ -f "nginx_faceform_vps.conf" ]; then
    cp nginx_faceform_vps.conf /etc/nginx/sites-available/faceform
    success "Использована специализированная конфигурация Nginx"
else
    # Настройка Nginx (если нет конфигурационного файла)
    info "Настройка Nginx..."
    cat > /etc/nginx/sites-available/faceform << EOL
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN $IP_ADDRESS;

    access_log /var/log/nginx/faceform_access.log;
    error_log /var/log/nginx/faceform_error.log;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location /static {
        alias $PROJECT_DIR/static;
        expires 30d;
    }

    location /uploads {
        alias $PROJECT_DIR/uploads;
        expires 30d;
    }
}
EOL
fi

# Активация Nginx конфигурации
ln -sf /etc/nginx/sites-available/faceform /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
systemctl restart nginx

# Инициализация базы данных
info "Инициализация базы данных..."
cd $PROJECT_DIR
source venv/bin/activate
if [ -f "$PROJECT_DIR/db.py" ]; then
    python -c "from db import Base; from models import *; from app import app; with app.app_context(): Base.metadata.create_all()" || { warn "Не удалось автоматически инициализировать базу данных."; }
fi
deactivate

# Старт и активация сервиса
info "Запуск FaceForm..."
systemctl daemon-reload
systemctl start faceform
systemctl enable faceform

success "Установка FaceForm завершена успешно!"
echo "Вы можете проверить работу сайта по адресам:"
echo "- http://$DOMAIN"
echo "- http://$IP_ADDRESS"
echo ""
echo "Настройки базы данных:"
echo "  База данных: $DB_NAME"
echo "  Пользователь: $DB_USER"
echo "  Пароль: $DB_PASS"
echo "  URL: postgresql://$DB_USER:$DB_PASS@localhost/$DB_NAME"
echo ""
echo "Настройки проекта сохранены в файле $PROJECT_DIR/.env"
echo ""
echo "Полезные команды:"
echo "  Проверить статус сервиса: sudo systemctl status faceform"
echo "  Перезапустить сервис: sudo systemctl restart faceform"
echo "  Просмотр логов: sudo journalctl -u faceform"