#!/bin/bash

# Скрипт для установки приложения FaceForm на VPS сервер
# Автоматически настраивает все необходимые компоненты

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Функция для вывода сообщений
log() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Проверка доступа sudo
check_sudo() {
    log "Проверка прав администратора..."
    if ! [ -x "$(command -v sudo)" ]; then
        error "Sudo не установлен. Установите sudo и запустите скрипт снова."
        exit 1
    fi
    
    # Проверка доступа sudo без пароля
    if sudo -n true 2>/dev/null; then
        success "Права администратора доступны"
    else
        warn "Для выполнения некоторых команд потребуется ввод пароля"
    fi
}

# Обновление системы
update_system() {
    log "Обновление списка пакетов..."
    sudo apt-get update -y || { error "Не удалось обновить список пакетов"; exit 1; }
    
    log "Обновление установленных пакетов..."
    sudo apt-get upgrade -y || warn "Не удалось обновить некоторые пакеты"
    
    success "Система обновлена"
}

# Установка необходимых пакетов
install_dependencies() {
    log "Установка необходимых зависимостей..."
    
    packages=(
        "python3"
        "python3-pip"
        "python3-dev"
        "python3-venv"
        "postgresql"
        "postgresql-contrib"
        "libpq-dev"
        "nginx"
        "certbot"
        "python3-certbot-nginx"
        "git"
        "build-essential"
        "libssl-dev"
        "libffi-dev"
        "supervisor"
    )
    
    for package in "${packages[@]}"; do
        log "Установка пакета: $package"
        sudo apt-get install -y "$package" || warn "Не удалось установить $package"
    done
    
    # Установка OpenCV и MediaPipe зависимостей
    log "Установка зависимостей для OpenCV и MediaPipe..."
    sudo apt-get install -y cmake libsm6 libxext6 libxrender-dev libgl1-mesa-glx || warn "Не удалось установить некоторые зависимости OpenCV"
    
    success "Установлены основные зависимости"
}

# Создание папки проекта
create_project_directory() {
    PROJECT_DIR="/opt/faceform"
    log "Создание директории проекта в $PROJECT_DIR..."
    
    sudo mkdir -p "$PROJECT_DIR" || { error "Не удалось создать директорию проекта"; exit 1; }
    sudo chown -R $(whoami):$(whoami) "$PROJECT_DIR" || { error "Не удалось изменить владельца директории"; exit 1; }
    
    success "Директория проекта создана: $PROJECT_DIR"
    
    # Создание директорий для файлов сессий и загрузок
    log "Создание дополнительных директорий..."
    mkdir -p "$PROJECT_DIR/flask_session" || warn "Не удалось создать директорию для сессий"
    mkdir -p "$PROJECT_DIR/uploads" || warn "Не удалось создать директорию для загрузок"
    mkdir -p "$PROJECT_DIR/static/uploads" || warn "Не удалось создать директорию для статических загрузок"
    
    success "Созданы необходимые директории"
}

# Создание виртуального окружения Python
setup_virtualenv() {
    log "Создание виртуального окружения Python..."
    
    cd "$PROJECT_DIR" || { error "Не удалось перейти в директорию проекта"; exit 1; }
    python3 -m venv venv || { error "Не удалось создать виртуальное окружение"; exit 1; }
    
    success "Виртуальное окружение создано"
}

# Копирование файлов проекта
copy_project_files() {
    log "Копирование файлов проекта..."
    
    # Здесь должна быть ваша логика копирования файлов
    # Например, через rsync, scp, git clone и т.д.
    
    # Можно загрузить файлы проекта с GitHub или другого репозитория
    # git clone [ссылка на репозиторий] $PROJECT_DIR
    
    # Или копировать файлы из текущей директории
    # cp -r * $PROJECT_DIR/
    
    # В этом скрипте мы предполагаем, что файлы уже загружены на сервер
    # и находятся в директории /tmp/faceform
    
    if [ -d "/tmp/faceform" ]; then
        cp -r /tmp/faceform/* "$PROJECT_DIR/" || { error "Не удалось скопировать файлы проекта"; exit 1; }
        success "Файлы проекта скопированы из /tmp/faceform"
    else
        warn "Директория /tmp/faceform не найдена. Пожалуйста, загрузите файлы проекта вручную в $PROJECT_DIR"
    fi
}

# Установка зависимостей Python
install_python_requirements() {
    log "Установка зависимостей Python..."
    
    cd "$PROJECT_DIR" || { error "Не удалось перейти в директорию проекта"; exit 1; }
    
    # Активация виртуального окружения
    source venv/bin/activate || { error "Не удалось активировать виртуальное окружение"; exit 1; }
    
    # Обновление pip
    pip install --upgrade pip || warn "Не удалось обновить pip"
    
    # Установка основных зависимостей
    pip install flask flask-login flask-sqlalchemy flask-wtf flask-session sqlalchemy email-validator python-dotenv psycopg2-binary gunicorn || { error "Не удалось установить основные зависимости"; exit 1; }
    
    # Установка зависимостей для работы с изображениями и видео
    pip install opencv-python-headless mediapipe numpy matplotlib pillow || { error "Не удалось установить зависимости для обработки изображений"; exit 1; }
    
    # Установка зависимостей для API интеграций
    pip install requests stripe sendgrid pytelegrambotapi twilio || warn "Не удалось установить некоторые зависимости для API интеграций"
    
    # Установка дополнительных зависимостей
    pip install werkzeug oauthlib flask-dance trafilatura pyjwt || warn "Не удалось установить некоторые дополнительные зависимости"
    
    # Если есть requirements.txt, устанавливаем из него
    if [ -f "requirements.txt" ]; then
        pip install -r requirements.txt || warn "Не удалось установить некоторые зависимости из requirements.txt"
    fi
    
    # Деактивация виртуального окружения
    deactivate
    
    success "Зависимости Python установлены"
}

# Настройка PostgreSQL
setup_postgresql() {
    log "Настройка PostgreSQL..."
    
    # Проверка, запущен ли PostgreSQL
    if ! systemctl is-active --quiet postgresql; then
        log "Запуск сервиса PostgreSQL..."
        sudo systemctl start postgresql || { error "Не удалось запустить PostgreSQL"; exit 1; }
    fi
    
    # Включение автозапуска PostgreSQL
    sudo systemctl enable postgresql || warn "Не удалось включить автозапуск PostgreSQL"
    
    # Создание пользователя и базы данных
    DB_NAME="faceform"
    DB_USER="faceform"
    DB_PASS=$(openssl rand -base64 12)  # Генерируем случайный пароль
    
    log "Создание пользователя PostgreSQL: $DB_USER"
    sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';" || warn "Пользователь $DB_USER уже существует или произошла ошибка"
    
    log "Создание базы данных: $DB_NAME"
    sudo -u postgres psql -c "CREATE DATABASE $DB_NAME WITH OWNER $DB_USER;" || warn "База данных $DB_NAME уже существует или произошла ошибка"
    
    log "Предоставление привилегий..."
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;" || warn "Не удалось предоставить привилегии"
    
    # Настройка подключения к БД в .env файле
    log "Обновление конфигурации подключения к БД..."
    cd "$PROJECT_DIR" || { error "Не удалось перейти в директорию проекта"; exit 1; }
    
    # Создаем или обновляем .env файл
    touch .env
    
    # Добавляем или обновляем настройки БД в .env
    if grep -q "DATABASE_URL" .env; then
        # Обновляем существующие настройки
        sed -i "s|DATABASE_URL=.*|DATABASE_URL=postgresql://$DB_USER:$DB_PASS@localhost:5432/$DB_NAME|g" .env
    else
        # Добавляем новые настройки
        echo "DATABASE_URL=postgresql://$DB_USER:$DB_PASS@localhost:5432/$DB_NAME" >> .env
    fi
    
    # Добавляем другие переменные окружения
    echo "PGUSER=$DB_USER" >> .env
    echo "PGPASSWORD=$DB_PASS" >> .env
    echo "PGHOST=localhost" >> .env
    echo "PGPORT=5432" >> .env
    echo "PGDATABASE=$DB_NAME" >> .env
    
    success "PostgreSQL настроен. Информация сохранена в .env файле"
    
    # Сохраняем данные для пользователя
    echo "База данных PostgreSQL создана:"
    echo "  Имя БД: $DB_NAME"
    echo "  Пользователь: $DB_USER"
    echo "  Пароль: $DB_PASS"
    echo "  URL: postgresql://$DB_USER:$DB_PASS@localhost:5432/$DB_NAME"
    echo
    echo "Эти данные также сохранены в файле $PROJECT_DIR/.env"
}

# Настройка Gunicorn
setup_gunicorn() {
    log "Настройка Gunicorn..."
    
    # Создание файла сервиса systemd для Gunicorn
    SERVICE_FILE="/etc/systemd/system/faceform.service"
    
    log "Создание файла сервиса: $SERVICE_FILE"
    
    sudo bash -c "cat > $SERVICE_FILE << 'EOL'
[Unit]
Description=FaceForm Gunicorn daemon
After=network.target postgresql.service

[Service]
User=$(whoami)
Group=$(whoami)
WorkingDirectory=$PROJECT_DIR
Environment=\"PATH=$PROJECT_DIR/venv/bin\"
ExecStart=$PROJECT_DIR/venv/bin/gunicorn --workers 4 --bind 0.0.0.0:5000 --log-level info main:app
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOL"
    
    # Перезагрузка systemd
    sudo systemctl daemon-reload || { error "Не удалось перезагрузить systemd"; exit 1; }
    
    # Запуск и включение автозапуска сервиса
    sudo systemctl enable faceform.service || { error "Не удалось включить автозапуск сервиса faceform"; exit 1; }
    sudo systemctl start faceform.service || { error "Не удалось запустить сервис faceform"; exit 1; }
    
    success "Gunicorn настроен и запущен"
}

# Настройка Nginx
setup_nginx() {
    log "Настройка Nginx..."
    
    # Получаем домен или используем IP адрес
    read -p "Введите домен для сайта (оставьте пустым для использования IP адреса): " DOMAIN
    
    if [ -z "$DOMAIN" ]; then
        # Если домен не указан, используем IP адрес
        DOMAIN=$(curl -s ipinfo.io/ip)
        if [ -z "$DOMAIN" ]; then
            # Если не удалось получить IP, используем localhost
            DOMAIN="localhost"
        fi
        warn "Домен не указан. Будет использован IP адрес: $DOMAIN"
    fi
    
    # Создание файла конфигурации Nginx
    NGINX_CONF="/etc/nginx/sites-available/faceform"
    
    log "Создание конфигурации Nginx: $NGINX_CONF"
    
    sudo bash -c "cat > $NGINX_CONF << 'EOL'
server {
    listen 80;
    server_name $DOMAIN;

    # Логи
    access_log /var/log/nginx/faceform.access.log;
    error_log /var/log/nginx/faceform.error.log;

    # Максимальный размер загружаемых файлов
    client_max_body_size 10M;

    # Статические файлы
    location /static/ {
        alias $PROJECT_DIR/static/;
        expires 30d;
    }

    # Загруженные файлы
    location /uploads/ {
        alias $PROJECT_DIR/uploads/;
        expires 30d;
    }

    # Проксирование запросов к Gunicorn
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 90;
    }
}
EOL"
    
    # Создание символической ссылки для активации сайта
    sudo ln -sf $NGINX_CONF /etc/nginx/sites-enabled/faceform || { error "Не удалось создать символическую ссылку"; exit 1; }
    
    # Проверка конфигурации Nginx
    sudo nginx -t || { error "Ошибка конфигурации Nginx"; exit 1; }
    
    # Перезапуск Nginx
    sudo systemctl restart nginx || { error "Не удалось перезапустить Nginx"; exit 1; }
    
    success "Nginx настроен"
    
    # Если указан домен (не IP), предлагаем настроить SSL
    if [[ ! $DOMAIN =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        log "Обнаружен домен. Хотите настроить SSL с помощью Let's Encrypt? (y/n)"
        read -p "Введите выбор: " setup_ssl
        
        if [[ $setup_ssl =~ ^[Yy]$ ]]; then
            log "Настройка SSL с помощью Let's Encrypt..."
            sudo certbot --nginx -d $DOMAIN || warn "Не удалось настроить SSL"
        else
            log "Пропуск настройки SSL"
        fi
    fi
}

# Настройка файлов конфигурации
setup_config_files() {
    log "Настройка файлов конфигурации..."
    
    cd "$PROJECT_DIR" || { error "Не удалось перейти в директорию проекта"; exit 1; }
    
    # Создаем или обновляем .env файл с дополнительными параметрами
    cat >> .env << EOL

# Общие настройки приложения
FLASK_APP=main.py
FLASK_ENV=production
FLASK_SECRET_KEY=$(openssl rand -hex 24)
SESSION_SECRET=$(openssl rand -hex 24)

# Stripe интеграция (замените на реальные ключи)
STRIPE_PUBLIC_KEY=pk_test_51RFWPbIXP9qWqMx9jUPze8X6mvkTwL0yi1qwkENB3c3cgxfq7dgqDG9NW367wz9q9I8u96IbjfVC6Mb1N1g3m3LT00j8y2YL84
STRIPE_SECRET_KEY=sk_test_51RFWPbIXP9qWqMx9w2YoZngd6scIJLNeq5iA430UStr6z5LYbkSjpDKdhhwkWuQvKBmfzDttXRgjQXNL81vmngnV00Onnf0Xxr
STRIPE_WEBHOOK_SECRET=

# Настройки Google OAuth (замените на реальные ключи)
GOOGLE_OAUTH_CLIENT_ID=
GOOGLE_OAUTH_CLIENT_SECRET=

# LightX API ключи (замените на реальные ключи)
LIGHTX_API_KEY=
EOL
    
    success "Файлы конфигурации настроены"
    
    # Напоминание о замене ключей API
    warn "Не забудьте заменить ключи API в файле .env на реальные!"
}

# Создание пользователя-администратора
create_admin_user() {
    log "Создание пользователя-администратора..."
    
    cd "$PROJECT_DIR" || { error "Не удалось перейти в директорию проекта"; exit 1; }
    
    # Активация виртуального окружения
    source venv/bin/activate || { error "Не удалось активировать виртуальное окружение"; exit 1; }
    
    # Создание скрипта для создания пользователя-администратора
    cat > create_admin.py << EOL
import os
import sys
from dotenv import load_dotenv
load_dotenv()

# Добавляем текущую директорию в sys.path
sys.path.insert(0, os.getcwd())

from app import app
from db import db
from models import User
from werkzeug.security import generate_password_hash

def create_admin_user(username, email, password):
    with app.app_context():
        # Проверяем, существует ли пользователь с таким email
        user = User.query.filter_by(email=email).first()
        
        if user:
            print(f"Пользователь с email {email} уже существует")
            # Обновляем права администратора
            user.is_admin = True
            db.session.commit()
            print(f"Пользователь {email} назначен администратором")
            return
        
        # Создаем нового пользователя-администратора
        user = User(
            username=username,
            email=email,
            password_hash=generate_password_hash(password),
            verified=True,
            is_admin=True
        )
        
        db.session.add(user)
        db.session.commit()
        
        print(f"Пользователь-администратор {username} ({email}) успешно создан")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Использование: python create_admin.py <username> <email> <password>")
        sys.exit(1)
    
    username = sys.argv[1]
    email = sys.argv[2]
    password = sys.argv[3]
    
    create_admin_user(username, email, password)
EOL
    
    # Запрос данных пользователя
    read -p "Введите имя пользователя-администратора: " ADMIN_USERNAME
    read -p "Введите email пользователя-администратора: " ADMIN_EMAIL
    read -p "Введите пароль пользователя-администратора: " ADMIN_PASSWORD
    
    # Создание пользователя-администратора
    python create_admin.py "$ADMIN_USERNAME" "$ADMIN_EMAIL" "$ADMIN_PASSWORD" || warn "Не удалось создать пользователя-администратора"
    
    # Деактивация виртуального окружения
    deactivate
    
    # Удаление временного скрипта
    rm create_admin.py
    
    success "Пользователь-администратор создан"
}

# Настройка файрвола
setup_firewall() {
    log "Настройка файрвола UFW..."
    
    # Проверка установки UFW
    if ! [ -x "$(command -v ufw)" ]; then
        log "Установка UFW..."
        sudo apt-get install -y ufw || { error "Не удалось установить UFW"; exit 1; }
    fi
    
    # Настройка правил файрвола
    sudo ufw default deny incoming || warn "Не удалось установить политику по умолчанию"
    sudo ufw default allow outgoing || warn "Не удалось установить политику по умолчанию"
    
    # Разрешаем SSH, HTTP и HTTPS
    sudo ufw allow ssh || warn "Не удалось разрешить SSH"
    sudo ufw allow http || warn "Не удалось разрешить HTTP"
    sudo ufw allow https || warn "Не удалось разрешить HTTPS"
    
    # Активация файрвола
    log "Активация файрвола..."
    echo "y" | sudo ufw enable || warn "Не удалось активировать файрвол"
    
    success "Файрвол настроен"
}

# Финальная проверка
final_check() {
    log "Проверка состояния сервисов..."
    
    # Проверка PostgreSQL
    if systemctl is-active --quiet postgresql; then
        success "PostgreSQL активен"
    else
        warn "PostgreSQL не запущен"
    fi
    
    # Проверка Gunicorn
    if systemctl is-active --quiet faceform.service; then
        success "Gunicorn активен"
    else
        warn "Gunicorn не запущен"
    fi
    
    # Проверка Nginx
    if systemctl is-active --quiet nginx; then
        success "Nginx активен"
    else
        warn "Nginx не запущен"
    fi
    
    log "Приложение FaceForm установлено и настроено."
    log "Директория проекта: $PROJECT_DIR"
    
    # Получение URL для доступа к сайту
    SITE_URL=""
    if grep -q "server_name" /etc/nginx/sites-enabled/faceform; then
        DOMAIN=$(grep "server_name" /etc/nginx/sites-enabled/faceform | sed 's/server_name\s*//g' | sed 's/;//g' | xargs)
        if [[ "$DOMAIN" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            SITE_URL="http://$DOMAIN"
        elif [[ -f /etc/letsencrypt/live/$DOMAIN/fullchain.pem ]]; then
            SITE_URL="https://$DOMAIN"
        else
            SITE_URL="http://$DOMAIN"
        fi
    else
        IP=$(curl -s ipinfo.io/ip)
        if [ -n "$IP" ]; then
            SITE_URL="http://$IP"
        else
            SITE_URL="http://localhost"
        fi
    fi
    
    success "Установка завершена!"
    echo "Сайт должен быть доступен по адресу: $SITE_URL"
    echo "Рекомендуется перезагрузить сервер для применения всех настроек."
    
    read -p "Хотите перезагрузить сервер сейчас? (y/n): " REBOOT_NOW
    if [[ $REBOOT_NOW =~ ^[Yy]$ ]]; then
        log "Перезагрузка сервера..."
        sudo reboot
    else
        log "Пропуск перезагрузки. Не забудьте перезагрузить сервер позднее."
    fi
}

# Основная функция
main() {
    log "Начало установки FaceForm..."
    
    check_sudo
    update_system
    install_dependencies
    create_project_directory
    setup_virtualenv
    copy_project_files
    install_python_requirements
    setup_postgresql
    setup_config_files
    setup_gunicorn
    setup_nginx
    create_admin_user
    setup_firewall
    final_check
    
    success "Установка FaceForm завершена успешно!"
}

# Запуск установки
main