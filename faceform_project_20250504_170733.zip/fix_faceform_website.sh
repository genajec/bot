#!/bin/bash

# Скрипт для исправления проблем с веб-сайтом FaceForm
# Использование: bash fix_faceform_website.sh

set -e  # Остановить скрипт при любой ошибке
echo "=== Начинаем исправление проблем с веб-сайтом FaceForm ==="

# Переменные конфигурации
PROJECT_DIR=~/faceform/faceform_project
SERVICE_NAME=faceform-web

# Функция для логирования
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1"
}

# 1. Создание скрипта для исправления CSRF
log "Создаем файл исправления CSRF..."
cat > $PROJECT_DIR/fix_csrf.py << 'EOL'
from app import app

# Настройка CSRF для работы с прокси
with app.app_context():
    app.config['WTF_CSRF_SSL_STRICT'] = False
    app.config['WTF_CSRF_TIME_LIMIT'] = None
    app.config['WTF_CSRF_CHECK_DEFAULT'] = False  # Отключаем для тестирования
    
    # Обновление конфигурации
    print("CSRF настройки обновлены:")
    print(f"WTF_CSRF_SSL_STRICT: {app.config.get('WTF_CSRF_SSL_STRICT')}")
    print(f"WTF_CSRF_TIME_LIMIT: {app.config.get('WTF_CSRF_TIME_LIMIT')}")
    print(f"WTF_CSRF_CHECK_DEFAULT: {app.config.get('WTF_CSRF_CHECK_DEFAULT')}")

print("Запустите приложение с обновленными настройками")
EOL

# 2. Исправление файла app.py для настройки CSRF
log "Создаем резервную копию app.py..."
cp $PROJECT_DIR/app.py $PROJECT_DIR/app.py.bak

log "Добавляем настройки CSRF в app.py..."
# Ищем строку создания приложения Flask и добавляем настройки CSRF
sed -i '/app = Flask/a\
# Отключаем проверку CSRF для упрощения работы через прокси\
app.config["WTF_CSRF_SSL_STRICT"] = False\
app.config["WTF_CSRF_TIME_LIMIT"] = None\
app.config["WTF_CSRF_CHECK_DEFAULT"] = False  # Временно отключаем для тестирования' $PROJECT_DIR/app.py

# 3. Исправление и отключение Google OAuth в шаблонах
log "Исправляем шаблоны для отключения Google OAuth..."

# Создаем резервные копии шаблонов
cp $PROJECT_DIR/templates/auth/login.html $PROJECT_DIR/templates/auth/login.html.bak
cp $PROJECT_DIR/templates/auth/register.html $PROJECT_DIR/templates/auth/register.html.bak

# Исправляем шаблон входа
log "Исправляем шаблон login.html..."
sed -i '/<a href="{{ url_for.*google_login/,/<\/a>/c\
<!-- Google OAuth временно отключен -->\
<!--<a href="{{ url_for(\"google_auth.login\") }}" class="btn btn-outline-danger btn-lg d-block">\
    <i class="bi bi-google"></i> Войти через Google\
</a>-->' $PROJECT_DIR/templates/auth/login.html

# Исправляем шаблон регистрации
log "Исправляем шаблон register.html..."
sed -i '/<a href="{{ url_for.*google_login/,/<\/a>/c\
<!-- Google OAuth временно отключен -->\
<!--<a href="{{ url_for(\"google_auth.login\") }}" class="btn btn-outline-danger btn-lg d-block">\
    <i class="bi bi-google"></i> Войти через Google\
</a>-->' $PROJECT_DIR/templates/auth/register.html

# 4. Настройка Nginx для правильной обработки статических файлов
log "Настраиваем Nginx для статических файлов..."
sudo tee /etc/nginx/sites-available/faceform << 'EOL'
server {
    listen 80;
    server_name 92.113.145.171;  # IP вашего сервера

    # Путь к статическим файлам
    location /static {
        alias /home/face/faceform/faceform_project/static;
        add_header Cache-Control "public, max-age=3600";
        autoindex off;
    }

    # Проксирование запросов к Flask приложению
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOL

log "Проверяем конфигурацию Nginx..."
sudo nginx -t

log "Перезапускаем Nginx..."
sudo systemctl restart nginx

# 5. Настраиваем правильные права доступа для статических файлов
log "Устанавливаем правильные права доступа для статических файлов..."
sudo chmod -R 755 $PROJECT_DIR/static
sudo chown -R face:www-data $PROJECT_DIR/static

# 6. Создание фиксированного секретного ключа для безопасности форм
log "Создаем фиксированный секретный ключ..."
cat > $PROJECT_DIR/secret_key.py << 'EOL'
import os
from app import app

with app.app_context():
    # Установка фиксированного секретного ключа
    app.config['SECRET_KEY'] = 'faceform_fixed_secret_key_for_forms'
    print(f"SECRET_KEY установлен: {app.config.get('SECRET_KEY')}")
EOL

# 7. Перезапуск приложения с новыми настройками
log "Останавливаем текущие процессы Gunicorn..."
pkill -f gunicorn || true
sudo systemctl stop $SERVICE_NAME || true

log "Запускаем приложение с обновленными настройками..."
cd $PROJECT_DIR
source venv/bin/activate

log "Применяем исправления CSRF..."
python fix_csrf.py

log "Применяем фиксированный секретный ключ..."
python secret_key.py

log "Перезапускаем службу..."
sudo systemctl daemon-reload
sudo systemctl restart $SERVICE_NAME

log "=== Исправления завершены ==="
log "Проверьте доступность сайта по адресу: http://92.113.145.171"
log "Попробуйте войти или зарегистрироваться в системе"