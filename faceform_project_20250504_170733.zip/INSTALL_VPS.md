# Инструкция по установке FaceForm бота на VPS

## Системные требования
- Python 3.11 или выше
- Nginx (для настройки прокси и SSL)
- Supervisor (для управления процессами)

## Установка

### 1. Установка зависимостей системы

```bash
sudo apt update
sudo apt install -y python3-pip python3-dev build-essential libssl-dev libffi-dev python3-setuptools python3-venv nginx supervisor
```

### 2. Распаковка и настройка проекта

```bash
# Создаем директорию для проекта
mkdir -p /opt/faceform_bot
cd /opt/faceform_bot

# Распаковываем архив
unzip /путь/к/архиву/faceform_bot.zip -d .

# Создаем и активируем виртуальное окружение
python3 -m venv venv
source venv/bin/activate

# Устанавливаем зависимости
pip install -r vps_requirements.txt
```

### 3. Настройка переменных окружения

```bash
# Копируем пример файла с переменными окружения
cp .env.example .env

# Открываем файл для редактирования
nano .env
```

Отредактируйте файл `.env`, указав:
- Ваш токен Telegram API
- URL вашего домена для вебхука
- Опционально: API ключ PerfectCorp, если планируете использовать эту функциональность

### 4. Настройка Supervisor

Создайте файл конфигурации для supervisor:

```bash
sudo nano /etc/supervisor/conf.d/faceform_bot.conf
```

Добавьте следующее содержимое:

```
[program:faceform_bot]
directory=/opt/faceform_bot
command=/opt/faceform_bot/venv/bin/gunicorn --workers 2 --bind 0.0.0.0:5000 main:app
autostart=true
autorestart=true
stderr_logfile=/var/log/faceform_bot/stderr.log
stdout_logfile=/var/log/faceform_bot/stdout.log
user=www-data
environment=PYTHONUNBUFFERED=1
```

Создайте директорию для логов:

```bash
sudo mkdir -p /var/log/faceform_bot
sudo chown www-data:www-data /var/log/faceform_bot
```

Обновите supervisor:

```bash
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start faceform_bot
```

### 5. Настройка Nginx

Создайте файл конфигурации Nginx:

```bash
sudo nano /etc/nginx/sites-available/faceform_bot
```

Добавьте следующее содержимое (замените your-domain.com на ваш домен):

```
server {
    listen 80;
    server_name your-domain.com;

    location / {
        include proxy_params;
        proxy_pass http://127.0.0.1:5000;
    }
}
```

Включите сайт:

```bash
sudo ln -s /etc/nginx/sites-available/faceform_bot /etc/nginx/sites-enabled
sudo nginx -t
sudo systemctl restart nginx
```

### 6. Настройка SSL с Let's Encrypt

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

### 7. Проверка работы

Перейдите в браузере по адресу `https://your-domain.com/health` для проверки статуса бота.

## Устранение неполадок

### Логи

Для просмотра логов приложения:
```bash
sudo tail -f /var/log/faceform_bot/stderr.log
sudo tail -f /var/log/faceform_bot/stdout.log
```

### Перезапуск сервиса

```bash
sudo supervisorctl restart faceform_bot
```

### Проверка статуса

```bash
sudo supervisorctl status faceform_bot
```