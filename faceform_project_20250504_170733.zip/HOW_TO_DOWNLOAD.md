# Как скачать файлы и подготовить архив для VPS

## Шаг 1: Скачивание файлов из Replit

### Основные файлы Python:
Скачайте следующие файлы Python:
- main.py
- bot.py
- config.py
- database.py
- face_analyzer.py
- stripe_payment.py
- crypto_bot_payment.py
- background_fallback.py
- models.py
- lightx_client.py (если есть)
- lightx_key_manager.py (если есть)

### Папка templates:
- Скачайте всю директорию templates или отдельно все HTML файлы:
  - templates/index.html
  - templates/base.html
  - templates/features.html
  - templates/pricing.html
  - templates/about.html
  - templates/checkout.html
  - templates/payment-complete.html
  - templates/cancel.html
  - templates/error.html
  - templates/success.html

### Папка static:
- Скачайте всю директорию static или отдельно все CSS и изображения:
  - static/css/main.css
  - static/images/logo.svg
  - static/images/hero-bg.svg

### Дополнительные файлы:
- Скачайте созданные специально для VPS файлы:
  - ENV_IP_ADDRESS.env (переименуйте в .env)
  - NGINX_CONFIG_IP.conf
  - VPS_SETUP_SCRIPT.sh
  - DEPLOY_GUIDE.md
  - INSTALL_VPS_FULL.md
  - WEBHOOKS_SETUP.md
  - SECURITY_MEASURES.md

## Шаг 2: Подготовка архива

1. Создайте на вашем компьютере следующую структуру директорий:
```
faceform_deploy/
├── templates/
├── static/
│   ├── css/
│   ├── images/
├── deployment/
```

2. Разместите скачанные файлы в соответствующих папках:
   - Python файлы в корне faceform_deploy/
   - HTML файлы в папке templates/
   - CSS в папке static/css/
   - Изображения в папке static/images/
   - Переименуйте ENV_IP_ADDRESS.env в .env и поместите в корень
   - Поместите NGINX_CONFIG_IP.conf в папку deployment/
   - Поместите VPS_SETUP_SCRIPT.sh в корень и сделайте его исполняемым

3. Создайте файл requirements_vps.txt в корне со следующим содержимым:
```
flask
flask-sqlalchemy
gunicorn
python-dotenv
pytelegrambotapi
stripe
opencv-python
numpy
mediapipe
psycopg2-binary
requests
pillow
```

4. Создайте архив:
```bash
zip -r faceform_deploy.zip faceform_deploy/
```

## Шаг 3: Перенос на VPS

1. Скопируйте архив на VPS:
```bash
scp faceform_deploy.zip faceform@92.113.145.171:~/
```

2. Подключитесь к VPS:
```bash
ssh faceform@92.113.145.171
```

3. Распакуйте архив и запустите скрипт установки:
```bash
unzip faceform_deploy.zip
cd faceform_deploy
chmod +x VPS_SETUP_SCRIPT.sh
./VPS_SETUP_SCRIPT.sh
```

## Шаг 4: Проверка установки

После установки проверьте:
1. Доступность сайта по адресу: http://92.113.145.171
2. Работу Telegram бота: напишите сообщение @Faceform_bot
3. Логи сервера: `sudo tail -f /var/log/faceform/faceform.out.log`