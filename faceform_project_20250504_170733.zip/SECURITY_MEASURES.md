# Меры безопасности для FaceForm на VPS

## Защита API ключей и секретов

API ключи и секреты, которые вы используете в проекте, являются конфиденциальной информацией. Их компрометация может привести к несанкционированному доступу к вашим сервисам и финансовым потерям. Вот рекомендации по обеспечению их безопасности:

### 1. Правильное хранение переменных окружения

Файл `.env` содержит все ваши секретные ключи. Защитите его:

```bash
# Ограничьте права доступа только владельцем
chmod 600 /home/faceform/faceform_bot/.env

# Убедитесь, что файл имеет правильного владельца
chown faceform:faceform /home/faceform/faceform_bot/.env
```

### 2. Резервное копирование ключей

Создайте защищенную резервную копию ключей:

```bash
# Создайте зашифрованную копию файла с ключами
sudo apt install -y gpg
gpg -c /home/faceform/faceform_bot/.env
# (вам будет предложено создать пароль)

# Сохраните защищенную копию в безопасном месте
cp /home/faceform/faceform_bot/.env.gpg /path/to/backup/location/
```

### 3. Защита сервера

Базовые меры по защите сервера:

```bash
# Установите и настройте файрвол
sudo apt install -y ufw
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw enable

# Установите fail2ban для защиты от брутфорс-атак
sudo apt install -y fail2ban
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

### 4. Регулярное обновление системы

Настройте автоматические обновления безопасности:

```bash
sudo apt install -y unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades
```

### 5. Ротация ключей

Регулярно меняйте API ключи и пароли:

1. Создавайте новые ключи в панелях управления сервисов (Stripe, LightX и т.д.)
2. Обновляйте файл `.env` новыми ключами
3. Перезапускайте сервис: `sudo supervisorctl restart faceform`

### 6. Мониторинг доступа

Настройте логирование и мониторинг доступа:

```bash
# Установите инструмент для мониторинга
sudo apt install -y logwatch

# Настройте ежедневную отправку отчетов
sudo nano /etc/cron.daily/00logwatch
```

Добавьте следующую строку:
```
/usr/sbin/logwatch --output mail --mailto your-email@example.com --detail high
```

### 7. Резервное копирование базы данных

Регулярно создавайте резервные копии базы данных:

```bash
# Создайте скрипт для резервного копирования
sudo nano /home/faceform/backup_db.sh
```

Содержимое скрипта:
```bash
#!/bin/bash
BACKUP_DIR="/home/faceform/backups"
mkdir -p $BACKUP_DIR
DATE=$(date +%Y-%m-%d_%H-%M-%S)
cp /home/faceform/faceform_bot/faceform_bot.db $BACKUP_DIR/faceform_bot_$DATE.db
find $BACKUP_DIR -name "faceform_bot_*.db" -mtime +7 -delete
```

Сделайте скрипт исполняемым и добавьте в cron:
```bash
chmod +x /home/faceform/backup_db.sh
(crontab -l 2>/dev/null; echo "0 2 * * * /home/faceform/backup_db.sh") | crontab -
```

## Рекомендации по поддержке безопасности

1. **Регулярно проверяйте активность в панелях управления** Stripe, Telegram Bot API и других сервисов на предмет подозрительной активности.

2. **Включите двухфакторную аутентификацию** для всех сервисов, где это возможно (Stripe, GitHub и т.д.).

3. **Следите за уведомлениями о безопасности** от провайдеров API и своевременно обновляйте ключи в случае инцидентов.

4. **Ограничьте IP-адреса** для доступа к API, где это возможно.

5. **Используйте SSH-ключи** вместо паролей для доступа к серверу.