#!/bin/bash
# Скрипт для создания архива веб-части проекта FaceForm
# Создан: 29 апреля 2025

# Определения цветов для лучшего вывода
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # Без цвета

echo -e "${BLUE}===== Создание архива веб-части проекта FaceForm для установки на VPS =====${NC}"

# Создание выходной директории, если она не существует
OUTPUT_DIR="."
ARCHIVE_NAME="faceform_web_only.tar.gz"
FULL_PATH="$OUTPUT_DIR/$ARCHIVE_NAME"

echo -e "${YELLOW}Создание архива по пути: ${FULL_PATH}${NC}"

# Список необходимых файлов и директорий для включения в архив
# Только веб-компоненты, без файлов Telegram бота
INCLUDE_FILES=(
    "app.py"              # Основной файл приложения
    "main.py"             # Точка входа
    "db.py"               # Конфигурация базы данных
    "models.py"           # Модели базы данных
    "auth.py"             # Аутентификация
    "config.py"           # Конфигурация
    "payments.py"         # Обработка платежей
    "translations.py"     # Переводы
    "templates/"          # HTML шаблоны
    "static/"             # Статические файлы (CSS, JS, изображения)
    "routes/"             # Модули маршрутов
    "requirements.txt"    # Зависимости
    ".env.example"        # Пример файла окружения
    "README.md"           # Документация
    "flask_session/"      # Хранилище сессий (пустая директория)
    "session_middleware.py"   # Middleware для сессий
    "forms.py"            # Формы
    "face_analyzer.py"    # Анализатор лиц (используется и в веб-версии)
    "lightx_client.py"    # Клиент для LightX API
    "lightx_key_manager.py" # Менеджер ключей LightX
    "database.py"         # Дополнительные функции для базы данных
    "google_auth.py"      # Google Auth (если используется)
)

# Создание временной директории для архива
TEMP_DIR=$(mktemp -d)
echo -e "${YELLOW}Создана временная директория: ${TEMP_DIR}${NC}"

# Копирование необходимых файлов во временную директорию
echo -e "${YELLOW}Копирование файлов...${NC}"
for file in "${INCLUDE_FILES[@]}"; do
    # Убедимся, что целевая директория существует
    if [[ "$file" == */ ]]; then
        mkdir -p "${TEMP_DIR}/${file}"
    fi
    
    # Копирование файлов
    cp -r --parents "$file" "$TEMP_DIR" 2>/dev/null || true
done

# Создание директории routes, если она не была скопирована
mkdir -p "${TEMP_DIR}/routes"

# Копирование только необходимых роутов (без роутов бота)
ROUTES_FILES=(
    "routes/__init__.py"
    "routes/face_analysis.py"
    "routes/api.py"
    "routes/advanced_features.py"
    "routes/language.py"
    "routes/download.py"
    "routes/faceform_download.py"
    "routes/download_essential.py"
    "routes/download_file.py"
    "routes/download_files.py"
    "routes/download_all_files.py"
    "routes/generate_download_script.py"
)

for route_file in "${ROUTES_FILES[@]}"; do
    cp "$route_file" "${TEMP_DIR}/$route_file" 2>/dev/null || true
done

# Генерация requirements.txt, если он не существует
if [ ! -f "requirements.txt" ]; then
    echo -e "${YELLOW}Создание requirements.txt...${NC}"
    cat > "${TEMP_DIR}/requirements.txt" << EOF
flask==2.3.3
flask-sqlalchemy==3.1.1
flask-login==0.6.2
flask-wtf==1.1.1
flask-session==0.5.0
email-validator==2.0.0
gunicorn==23.0.0
werkzeug==2.3.7
python-dotenv==1.0.0
psycopg2-binary==2.9.7
opencv-python==4.8.0.76
numpy==1.25.2
stripe==8.0.0
pillow==10.0.1
matplotlib==3.8.0
requests==2.31.0
sqlalchemy==2.0.21
EOF
fi

# Создание пустого .env.example, если он не существует
if [ ! -f ".env.example" ]; then
    echo -e "${YELLOW}Создание .env.example...${NC}"
    cat > "${TEMP_DIR}/.env.example" << EOF
# Конфигурация базы данных
DATABASE_URL=postgresql://username:password@localhost:5432/faceform
PGUSER=faceform_user
PGPASSWORD=your_password
PGHOST=localhost
PGPORT=5432
PGDATABASE=faceform

# Конфигурация Flask
SECRET_KEY=your_secret_key
FLASK_SECRET_KEY=your_flask_secret_key
SESSION_SECRET=your_session_secret

# Конфигурация Stripe
STRIPE_PUBLIC_KEY=pk_test_your_key
STRIPE_SECRET_KEY=sk_test_your_key

# Конфигурация LightX API
LIGHTX_API_KEY=your_lightx_api_key

# Серверная конфигурация
PORT=5000
FLASK_ENV=production
EOF
fi

# Создание директории flask_session, если она не существует
mkdir -p "${TEMP_DIR}/flask_session"

# Создание базового README, если он не существует
if [ ! -f "README.md" ]; then
    echo -e "${YELLOW}Создание README.md...${NC}"
    cat > "${TEMP_DIR}/README.md" << EOF
# FaceForm Web

FaceForm Web - это веб-интерфейс платформы анализа лиц с искусственным интеллектом.

## Возможности
- Анализ формы лица
- Рекомендации по прическам
- Виртуальная примерка причесок
- Удаление фона
- Анализ привлекательности
- Анализ видео с лицом

## Установка
См. скрипт setup_faceform_web_only.sh для установки на VPS.

## Конфигурация
Отредактируйте файл .env, добавив ваши API-ключи и учетные данные базы данных.

## Лицензия
Все права защищены. Несанкционированное использование, воспроизведение или распространение запрещено.
EOF
fi

# Создание архива
echo -e "${YELLOW}Создание архива...${NC}"
cd "$TEMP_DIR"
tar -czf "$FULL_PATH" .
cd - > /dev/null

# Расчет размера в МБ
SIZE=$(du -m "$FULL_PATH" | cut -f1)

# Очистка
rm -rf "$TEMP_DIR"

echo -e "${GREEN}✓ Архив успешно создан: ${FULL_PATH} (${SIZE} МБ)${NC}"
echo -e "${GREEN}✓ Используйте этот архив с setup_faceform_web_only.sh для установки на ваш VPS${NC}"
echo -e "${GREEN}✓ Выберите опцию 2 (Использовать локальный архив) в процессе установки${NC}"