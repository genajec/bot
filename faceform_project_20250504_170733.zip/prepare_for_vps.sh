#!/bin/bash

# Скрипт для подготовки файлов проекта FaceForm к переносу на VPS
# Создает архив со всеми необходимыми файлами

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Функция для вывода сообщений
log() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Получение текущей директории
CURRENT_DIR=$(pwd)
OUTPUT_DIR="${CURRENT_DIR}/faceform_deploy"
TEMP_DIR="${OUTPUT_DIR}/temp"
ARCHIVE_NAME="faceform_project.tar.gz"

# Создание директорий для выходных файлов
create_output_dirs() {
    log "Создание директорий для выходных файлов..."
    
    mkdir -p "${OUTPUT_DIR}" || { error "Не удалось создать директорию ${OUTPUT_DIR}"; exit 1; }
    mkdir -p "${TEMP_DIR}" || { error "Не удалось создать директорию ${TEMP_DIR}"; exit 1; }
    
    success "Директории созданы"
}

# Копирование основных файлов проекта
copy_project_files() {
    log "Копирование файлов проекта..."
    
    # Список основных Python файлов
    python_files=(
        "main.py"
        "app.py"
        "db.py"
        "models.py"
        "auth.py"
        "forms.py"
        "config.py"
        "translations.py"
        "session_middleware.py"
        "face_analyzer.py"
        "lightx_client.py"
        "lightx_key_manager.py"
        "payments.py"
        "crypto_bot_payment.py"
        "stripe_payment.py"
        "background_fallback.py"
        "hairstyle_recommender.py"
        "hairstyle_overlay.py"
        "face_attractiveness.py"
        "process_video_with_grid.py"
        "bot.py"
    )
    
    # Копирование основных Python файлов
    for file in "${python_files[@]}"; do
        if [ -f "${CURRENT_DIR}/${file}" ]; then
            cp "${CURRENT_DIR}/${file}" "${TEMP_DIR}/" || warn "Не удалось скопировать файл ${file}"
        else
            warn "Файл ${file} не найден и будет пропущен"
        fi
    done
    
    # Копирование директорий
    directories=(
        "templates"
        "static"
        "routes"
        "flask_session"
        "uploads"
    )
    
    for dir in "${directories[@]}"; do
        if [ -d "${CURRENT_DIR}/${dir}" ]; then
            cp -r "${CURRENT_DIR}/${dir}" "${TEMP_DIR}/" || warn "Не удалось скопировать директорию ${dir}"
        else
            # Создаем пустую директорию, если она не существует
            mkdir -p "${TEMP_DIR}/${dir}" || warn "Не удалось создать директорию ${dir}"
        fi
    done
    
    # Копирование скрипта установки на VPS
    if [ -f "${CURRENT_DIR}/setup_vps.sh" ]; then
        cp "${CURRENT_DIR}/setup_vps.sh" "${OUTPUT_DIR}/" || warn "Не удалось скопировать скрипт setup_vps.sh"
        chmod +x "${OUTPUT_DIR}/setup_vps.sh" || warn "Не удалось сделать скрипт исполняемым"
    else
        error "Скрипт setup_vps.sh не найден"
    fi
    
    success "Файлы проекта скопированы"
}

# Создание файла requirements.txt
create_requirements_file() {
    log "Создание файла requirements.txt..."
    
    cat > "${TEMP_DIR}/requirements.txt" << EOL
# Основные зависимости Flask
Flask==2.3.3
Flask-Login==0.6.2
Flask-SQLAlchemy==3.1.1
Flask-WTF==1.2.1
Flask-Session==0.5.0
Flask-Dance==7.0.0
Flask-SocketIO==5.3.6
SQLAlchemy==2.0.25
Werkzeug==2.3.7
WTForms==3.1.1
email-validator==2.1.0
python-dotenv==1.0.0
gunicorn==21.2.0

# Зависимости для работы с базой данных
psycopg2-binary==2.9.9

# Зависимости для обработки изображений и видео
opencv-python-headless==4.8.1.78
mediapipe==0.10.9
numpy==1.26.2
matplotlib==3.8.2
Pillow==10.1.0

# Зависимости для API интеграций
stripe==7.11.0
requests==2.31.0
sendgrid==6.10.0
pyTelegramBotAPI==4.14.0
twilio==8.10.0
anthropic==0.8.1
openai==1.10.0

# Дополнительные зависимости
PyJWT==2.8.0
oauthlib==3.2.2
trafilatura==1.6.1
psutil==5.9.6
EOL
    
    success "Файл requirements.txt создан"
}

# Создание примера файла .env
create_env_example() {
    log "Создание примера файла .env..."
    
    cat > "${TEMP_DIR}/.env.example" << EOL
# База данных PostgreSQL
DATABASE_URL=postgresql://faceform:password@localhost:5432/faceform
PGUSER=faceform
PGPASSWORD=password
PGHOST=localhost
PGPORT=5432
PGDATABASE=faceform

# Общие настройки приложения
FLASK_APP=main.py
FLASK_ENV=production
FLASK_SECRET_KEY=your_secure_secret_key_here
SESSION_SECRET=your_session_secret_key_here

# Stripe интеграция
STRIPE_PUBLIC_KEY=pk_test_your_stripe_public_key
STRIPE_SECRET_KEY=sk_test_your_stripe_secret_key
STRIPE_WEBHOOK_SECRET=whsec_your_stripe_webhook_secret

# Google OAuth
GOOGLE_OAUTH_CLIENT_ID=your_google_oauth_client_id
GOOGLE_OAUTH_CLIENT_SECRET=your_google_oauth_client_secret

# LightX API ключи
LIGHTX_API_KEY=your_lightx_api_key

# Telegram Bot Token
TELEGRAM_BOT_TOKEN=your_telegram_bot_token
EOL
    
    success "Файл .env.example создан"
}

# Создание файла README
create_readme() {
    log "Создание файла README.md..."
    
    cat > "${OUTPUT_DIR}/README.md" << EOL
# FaceForm - Установка на VPS

Это руководство поможет вам установить приложение FaceForm на VPS сервер.

## Предварительные требования

- Ubuntu 22.04 или новее
- Права sudo
- Доступ к серверу по SSH

## Быстрая установка

1. Загрузите архив с файлами проекта на сервер:

\`\`\`bash
scp faceform_project.tar.gz user@your_server_ip:/tmp/
\`\`\`

2. Подключитесь к серверу по SSH:

\`\`\`bash
ssh user@your_server_ip
\`\`\`

3. Создайте директорию для файлов проекта и распакуйте архив:

\`\`\`bash
sudo mkdir -p /tmp/faceform
sudo tar -xzf /tmp/faceform_project.tar.gz -C /tmp/faceform
\`\`\`

4. Запустите скрипт установки:

\`\`\`bash
chmod +x setup_vps.sh
./setup_vps.sh
\`\`\`

5. Следуйте инструкциям в скрипте установки.

## Ручная установка

Если вы предпочитаете установить приложение вручную, выполните следующие шаги:

1. Обновите систему:

\`\`\`bash
sudo apt-get update -y
sudo apt-get upgrade -y
\`\`\`

2. Установите необходимые пакеты:

\`\`\`bash
sudo apt-get install -y python3 python3-pip python3-dev python3-venv postgresql postgresql-contrib libpq-dev nginx certbot python3-certbot-nginx git build-essential libssl-dev libffi-dev supervisor
\`\`\`

3. Создайте директорию проекта:

\`\`\`bash
sudo mkdir -p /opt/faceform
sudo chown -R $(whoami):$(whoami) /opt/faceform
\`\`\`

4. Распакуйте файлы проекта:

\`\`\`bash
cp -r /tmp/faceform/* /opt/faceform/
\`\`\`

5. Создайте виртуальное окружение и установите зависимости:

\`\`\`bash
cd /opt/faceform
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
deactivate
\`\`\`

6. Настройте PostgreSQL и создайте базу данных...

Дальнейшие шаги описаны в скрипте \`setup_vps.sh\`.

## Настройка API ключей

Для полноценной работы FaceForm необходимо настроить API ключи:

1. Создайте файл \`.env\` на основе \`.env.example\`
2. Заполните все необходимые API ключи
3. Перезапустите приложение: \`sudo systemctl restart faceform\`

## Поддержка

Если у вас возникли проблемы с установкой, обращайтесь по адресу support@faceform.ru
EOL
    
    success "Файл README.md создан"
}

# Создание архива с файлами проекта
create_archive() {
    log "Создание архива с файлами проекта..."
    
    cd "${TEMP_DIR}" || { error "Не удалось перейти в директорию ${TEMP_DIR}"; exit 1; }
    tar -czf "${OUTPUT_DIR}/${ARCHIVE_NAME}" * || { error "Не удалось создать архив"; exit 1; }
    
    success "Архив ${ARCHIVE_NAME} создан в директории ${OUTPUT_DIR}"
}

# Инструкции по SFTP загрузке
create_sftp_instructions() {
    log "Создание инструкций по SFTP загрузке..."
    
    cat > "${OUTPUT_DIR}/sftp_instructions.txt" << EOL
Инструкции по загрузке файлов на сервер с помощью SFTP
=====================================================

1. Загрузка архива с файлами проекта с локального компьютера на сервер:

   scp faceform_project.tar.gz user@your_server_ip:/tmp/

   Замените user@your_server_ip на ваши данные для доступа к серверу.

2. Загрузка скрипта установки:

   scp setup_vps.sh user@your_server_ip:~/

3. Подключение к серверу по SSH:

   ssh user@your_server_ip

4. Создание временной директории для файлов проекта и распаковка архива:

   mkdir -p /tmp/faceform
   tar -xzf /tmp/faceform_project.tar.gz -C /tmp/faceform

5. Запуск скрипта установки:

   chmod +x ~/setup_vps.sh
   ~/setup_vps.sh

6. Следуйте инструкциям скрипта установки для завершения процесса.
EOL
    
    success "Инструкции по SFTP загрузке созданы"
}

# Очистка временных файлов
cleanup() {
    log "Очистка временных файлов..."
    
    rm -rf "${TEMP_DIR}" || warn "Не удалось удалить временную директорию"
    
    success "Временные файлы удалены"
}

# Вывод итоговой информации
show_summary() {
    log "Подготовка файлов для VPS завершена!"
    echo
    echo "В директории ${OUTPUT_DIR} созданы следующие файлы:"
    echo "- ${ARCHIVE_NAME} - архив с файлами проекта"
    echo "- setup_vps.sh - скрипт для установки на VPS"
    echo "- README.md - инструкции по установке"
    echo "- sftp_instructions.txt - инструкции по загрузке файлов на сервер"
    echo
    echo "Для установки на VPS выполните следующие шаги:"
    echo "1. Загрузите файлы на сервер с помощью SFTP или SCP (см. инструкции в sftp_instructions.txt)"
    echo "2. Запустите скрипт setup_vps.sh на сервере"
    echo "3. Следуйте инструкциям скрипта установки"
    echo
    echo "При запросе параметров в скрипте установки:"
    echo "- Для домена укажите доменное имя, если оно есть, или оставьте пустым для использования IP адреса"
    echo "- Укажите данные администратора для создания учетной записи"
    echo
    echo "После установки не забудьте настроить API ключи в файле .env!"
}

# Основная функция
main() {
    log "Начало подготовки файлов для VPS..."
    
    create_output_dirs
    copy_project_files
    create_requirements_file
    create_env_example
    create_readme
    create_archive
    create_sftp_instructions
    cleanup
    show_summary
    
    success "Подготовка файлов для VPS завершена успешно!"
}

# Запуск подготовки
main