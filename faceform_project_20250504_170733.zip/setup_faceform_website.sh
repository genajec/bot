#!/bin/bash

# Скрипт для автоматической установки и настройки веб-сайта FaceForm на VPS
# Использование: bash setup_faceform_website.sh

set -e  # Остановить скрипт при любой ошибке
echo "=== Начинаем установку веб-сайта FaceForm на VPS ==="

# Переменные конфигурации
PROJECT_DIR=~/faceform/faceform_project
VENV_DIR=$PROJECT_DIR/venv
SERVICE_NAME=faceform-web
DB_NAME=faceform
DB_USER=faceform
DB_PASSWORD=secure_password  # В реальном сценарии используйте более безопасный пароль

# Проверка существования проекта
if [ ! -d "$PROJECT_DIR" ]; then
    echo "Ошибка: Директория проекта $PROJECT_DIR не найдена."
    exit 1
fi

# Функция для логирования
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1"
}

# 1. Создание и активация виртуального окружения
log "Создаем виртуальное окружение Python..."
if [ ! -d "$VENV_DIR" ]; then
    python3 -m venv $VENV_DIR
fi
source $VENV_DIR/bin/activate

# 2. Установка необходимых пакетов
log "Устанавливаем зависимости проекта..."
# Базовые пакеты
pip install flask gunicorn python-dotenv requests Werkzeug

# Telegram бот
pip install pyTelegramBotAPI python-telegram-bot

# Обработка изображений
pip install opencv-python numpy pillow mediapipe

# Платежные системы
pip install stripe

# БД и ORM
pip install SQLAlchemy psycopg2-binary

# Дополнительные пакеты
pip install python-dateutil ujson loguru psutil

# Авторизация и сессии
pip install oauthlib flask-dance flask-login flask-session flask-wtf

# 3. Настройка базы данных PostgreSQL
log "Настраиваем базу данных PostgreSQL..."
if ! sudo -u postgres psql -lqt | cut -d \| -f 1 | grep -qw $DB_NAME; then
    log "Создаем базу данных и пользователя..."
    sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD';"
    sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;"
    log "База данных успешно создана."
else
    log "База данных $DB_NAME уже существует."
fi

# 4. Создание файла конфигурации .env (если отсутствует)
if [ ! -f "$PROJECT_DIR/.env" ]; then
    log "Создаем файл .env с настройками..."
    cat > $PROJECT_DIR/.env << EOL
FLASK_SECRET_KEY=e52549886473b788e178d6ad69bf2568
SQLALCHEMY_DATABASE_URI=postgresql://$DB_USER:$DB_PASSWORD@localhost/$DB_NAME
SESSION_SECRET=48626befee696278477733aaced25820
EOL
    log "Файл .env успешно создан."
else
    log "Файл .env уже существует."
fi

# 5. Исправление шаблона регистрации
log "Проверяем шаблон регистрации..."
REGISTER_TEMPLATE=$PROJECT_DIR/templates/auth/register.html
if [ -f "$REGISTER_TEMPLATE" ]; then
    # Создаем резервную копию
    cp $REGISTER_TEMPLATE ${REGISTER_TEMPLATE}.bak
    
    # Заменяем строку с Google авторизацией на условное отображение
    sed -i 's/<a href="{{ url_for('\''google_auth.login'\'') }}" class="btn btn-outline-danger btn-lg d-block">/{% if config.get("GOOGLE_OAUTH_ENABLED", False) %}<a href="{{ url_for('\''google_auth.login'\'') }}" class="btn btn-outline-danger btn-lg d-block">{% endif %}/g' $REGISTER_TEMPLATE
    sed -i 's/<i class="bi bi-google"><\/i> Войти через Google/<i class="bi bi-google"><\/i> Войти через Google{% endif %}/g' $REGISTER_TEMPLATE
    
    log "Шаблон регистрации успешно обновлен."
fi

# 6. Создание службы systemd
log "Создаем службу systemd..."
sudo tee /etc/systemd/system/$SERVICE_NAME.service << 'EOL'
[Unit]
Description=FaceForm Web Application
After=network.target postgresql.service

[Service]
User=face
Group=face
WorkingDirectory=/home/face/faceform/faceform_project
Environment="PATH=/home/face/faceform/faceform_project/venv/bin"
ExecStart=/home/face/faceform/faceform_project/venv/bin/gunicorn --bind 0.0.0.0:5000 main:app
Restart=always

[Install]
WantedBy=multi-user.target
EOL

# 7. Настройка и запуск службы
log "Настраиваем и запускаем службу..."
sudo systemctl daemon-reload
sudo systemctl enable $SERVICE_NAME
sudo systemctl restart $SERVICE_NAME

# 8. Проверка работы службы
log "Проверяем статус службы..."
sudo systemctl status $SERVICE_NAME

# 9. Проверка соединения с сервером
log "Проверяем соединение с веб-сервером..."
curl -s -o /dev/null -w "%{http_code}" http://localhost:5000 || echo "Ошибка при подключении к серверу"

log "=== Установка завершена ==="
log "Веб-сайт должен быть доступен по адресу: http://$(hostname -I | awk '{print $1}'):5000"
log "Если вы используете Nginx, настройте его для проксирования запросов на порт 5000."

# Советы по Nginx
log "Совет: Для настройки Nginx создайте файл /etc/nginx/sites-available/faceform с таким содержанием:"
cat << 'EOL'
server {
    listen 80;
    server_name ваш_домен_или_IP;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
EOL
log "Затем выполните:"
log "sudo ln -s /etc/nginx/sites-available/faceform /etc/nginx/sites-enabled/"
log "sudo nginx -t && sudo systemctl restart nginx"