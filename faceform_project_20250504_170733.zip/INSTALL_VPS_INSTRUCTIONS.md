# FaceForm VPS Installation Guide

This guide will help you install the FaceForm application on your VPS server. Follow these steps carefully to ensure a successful installation.

## Prerequisites

Before starting the installation, make sure your VPS meets the following requirements:

- Ubuntu 20.04 or newer
- At least 2GB RAM
- At least 10GB of free disk space
- SSH access with root privileges
- A domain name (optional, but recommended for SSL and webhook functionality)

## Step 1: Prepare the Files

You need to transfer three important files to your VPS:

1. **faceform_vps_project.tar.gz** - The complete project archive
2. **setup_faceform_vps.sh** - The installation script
3. **INSTALL_VPS_INSTRUCTIONS.md** - This instruction document

You can transfer these files using `scp` or any SFTP client like FileZilla:

```bash
# Example using scp
scp faceform_vps_project.tar.gz setup_faceform_vps.sh INSTALL_VPS_INSTRUCTIONS.md username@your-vps-ip:/home/username/
```

## Step 2: Run the Installation Script

1. Connect to your VPS through SSH:

```bash
ssh username@your-vps-ip
```

2. Navigate to the directory where you uploaded the files:

```bash
cd /home/username/
```

3. Make the installation script executable:

```bash
chmod +x setup_faceform_vps.sh
```

4. Run the installation script with sudo:

```bash
sudo ./setup_faceform_vps.sh
```

5. Follow the prompts in the installation script:
   - Choose a directory to install FaceForm (default: /opt/faceform)
   - Select option 3 "Use a local archive" when asked about the project source
   - Provide the path to the faceform_vps_project.tar.gz file
   - Choose whether to set up Nginx as a reverse proxy
   - If using Nginx, provide your domain name
   - Choose whether to set up SSL with Let's Encrypt
   - Choose whether to set up the Telegram bot service

## Step 3: Configure Environment Variables

After installation, you need to edit the .env file to add your API keys and other configuration:

```bash
sudo nano /opt/faceform/.env
```

Configure the following essential variables:

- **TELEGRAM_BOT_TOKEN**: Your Telegram bot token (get it from BotFather)
- **STRIPE_PUBLIC_KEY** and **STRIPE_SECRET_KEY**: Your Stripe API keys
- **LIGHTX_API_KEY**: Your LightX API key for AI features

Save the file by pressing Ctrl+O, Enter, then Ctrl+X.

## Step 4: Start the Services

Restart the FaceForm services to apply your configuration changes:

```bash
sudo systemctl restart faceform
sudo systemctl restart faceform-bot  # If you set up the bot service
```

## Step 5: Verify the Installation

1. Check if the services are running properly:

```bash
sudo systemctl status faceform
sudo systemctl status faceform-bot  # If you set up the bot service
```

2. Check the application logs for any errors:

```bash
sudo journalctl -u faceform -n 50
sudo journalctl -u faceform-bot -n 50  # If you set up the bot service
```

3. Access the web interface:
   - If you set up Nginx with a domain: https://your-domain.com
   - If not using a domain: http://your-vps-ip:5000

## Troubleshooting

### Database Errors

If you encounter database errors, check the PostgreSQL service:

```bash
sudo systemctl status postgresql
```

And verify the database connection settings in the .env file.

### Web Server Issues

If Nginx is not working properly:

```bash
sudo nginx -t  # Test Nginx configuration
sudo systemctl restart nginx  # Restart Nginx
```

### Telegram Bot Issues

If the bot is not responding:

1. Verify the bot token in the .env file
2. Check if the bot service is running
3. For webhook mode, ensure your domain has SSL configured

### Permission Issues

If you encounter permission errors:

```bash
sudo chown -R www-data:www-data /opt/faceform
sudo chmod -R 755 /opt/faceform
```

## Updating the Application

To update the application in the future:

1. Create a new project archive and upload it to your VPS
2. Extract it to a temporary directory
3. Back up your .env file and any custom configurations
4. Replace the files in your installation directory
5. Restore your .env file
6. Restart the services

## Security Recommendations

For a production environment, consider these additional security measures:

1. Set up a firewall (UFW) to restrict access
2. Configure fail2ban to prevent brute force attacks
3. Regularly update your system with `apt update` and `apt upgrade`
4. Set up regular database backups
5. Use strong, unique passwords for all services

## Support

If you encounter any issues during installation or operation, please contact our support team for assistance.