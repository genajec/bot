# Руководство по переносу проекта FaceForm

Это руководство содержит подробные инструкции по переносу проекта FaceForm на другой аккаунт, включая все необходимые данные, ключи и параметры.

## 1. Общая информация

FaceForm - это веб-приложение, построенное на следующих технологиях:
- Python + Flask (бэкенд)
- HTML, CSS, JavaScript (фронтенд)
- PostgreSQL (база данных)
- Google OAuth (авторизация через Google)
- LightX API (для обработки изображений)

## 2. Необходимые секретные ключи и учетные данные

При переносе проекта необходимо настроить следующие секретные ключи и переменные окружения:

### Основные переменные окружения:
- `DATABASE_URL` - URL подключения к базе данных PostgreSQL
- `SESSION_SECRET` - секретный ключ для сессий Flask
- `SMTP_USERNAME` и `SMTP_PASSWORD` - учетные данные для отправки email (сброс пароля и уведомления)

### OAuth и внешние API:
- `GOOGLE_OAUTH_CLIENT_ID` и `GOOGLE_OAUTH_CLIENT_SECRET` - учетные данные для Google OAuth
- LightX API Keys (хранятся в базе данных, таблица `api_keys`)

### Платежные системы (если используются):
- `STRIPE_SECRET_KEY` и `STRIPE_PUBLISHABLE_KEY` - для интеграции со Stripe
- `SENDGRID_API_KEY` - для отправки email через SendGrid (опционально)
- `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN` и `TWILIO_PHONE_NUMBER` - для SMS уведомлений (опционально)

## 3. Шаги по переносу

### Шаг 1: Экспорт базы данных
1. Экспортируйте базу данных PostgreSQL из исходного проекта:
```bash
pg_dump -U username -d your_database > faceform_backup.sql
```

### Шаг 2: Клонирование репозитория
1. Создайте новый проект на целевом аккаунте
2. Нажмите "Share" (поделиться) на исходном проекте, и импортируйте его в новый проект целевого аккаунта
3. Или клонируйте проект вручную с помощью Git

### Шаг 3: Настройка базы данных
1. Создайте новую базу данных PostgreSQL в целевом проекте
2. Импортируйте данные из резервной копии:
```bash
psql -U username -d your_new_database < faceform_backup.sql
```

### Шаг 4: Настройка переменных окружения
1. Скопируйте файл `.env` из исходного проекта или создайте новый:
```
DATABASE_URL=postgresql://username:password@localhost:5432/your_database
SESSION_SECRET=your_secret_key
SMTP_USERNAME=your_email_username
SMTP_PASSWORD=your_email_password
GOOGLE_OAUTH_CLIENT_ID=your_google_client_id
GOOGLE_OAUTH_CLIENT_SECRET=your_google_client_secret
```

2. При необходимости обновите значения переменных для нового окружения

### Шаг 5: Настройка Google OAuth
1. Создайте новый проект в [Google Cloud Console](https://console.cloud.google.com)
2. Настройте OAuth 2.0 учетные данные
3. Добавьте URL перенаправления для вашего нового проекта:
   - `https://YOUR_REPLIT_DOMAIN/google_login/callback`
4. Скопируйте полученные Client ID и Client Secret в переменные окружения

### Шаг 6: Проверка API ключей
1. Убедитесь, что ключи LightX API корректно перенесены в базу данных
2. Если необходимо, обновите ключи в базе данных:
```sql
UPDATE api_keys SET api_key = 'new_key' WHERE service = 'lightx';
```

### Шаг 7: Установка зависимостей
1. Убедитесь, что все необходимые пакеты установлены:
```bash
pip install -r requirements.txt
```

### Шаг 8: Запуск и тестирование
1. Запустите веб-приложение:
```bash
gunicorn --bind 0.0.0.0:5000 main:app
```
2. Проверьте работу основных функций:
   - Регистрация/вход (включая Google OAuth)
   - Загрузка и анализ изображений
   - Системы оплаты (если используются)

## 4. Структура проекта и ключевые компоненты

### Основные файлы:
- `app.py` - настройка приложения Flask
- `main.py` - точка входа в приложение
- `database.py` - инициализация базы данных
- `models.py` - модели SQLAlchemy
- `auth.py` - аутентификация и авторизация
- `google_auth.py` - интеграция с Google OAuth

### Blueprints:
- `/auth` - аутентификация и управление пользователями
- `/face_analysis` - анализ формы лица
- `/advanced_features` - дополнительные функции
- `/payments` - платежная система
- `/language` - управление локализацией

### Папки с шаблонами:
- `templates/` - HTML-шаблоны 
- `static/` - статические файлы (CSS, JS, изображения)
- `translations/` - файлы локализации

## 5. Устранение распространенных проблем

### Проблемы с базой данных
- Проверьте, что строка подключения `DATABASE_URL` корректна
- Убедитесь, что все миграции базы данных применены
- Проверьте права доступа к базе данных

### Проблемы с Google OAuth
- Убедитесь, что URL перенаправления настроен правильно в Google Cloud Console
- Проверьте, что Client ID и Client Secret правильно указаны в переменных окружения

### Проблемы с LightX API
- Проверьте работоспособность ключей API
- Используйте ротацию ключей при необходимости

## 6. Контакты для поддержки

При возникновении проблем с переносом проекта, обратитесь к разработчикам:
- Email: support@faceform.example.com
- Telegram: @faceform_support
