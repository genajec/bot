# Инструкции по установке и запуску бота на VPS

## Проверка настройки Supervisor

1. Проверьте конфигурацию supervisor:

```bash
sudo supervisorctl status
```

Если вы не видите программу `faceform_bot` в списке, значит конфигурация не установлена или имеет другое имя.

2. Проверьте файлы конфигурации supervisor:

```bash
sudo ls -la /etc/supervisor/conf.d/
```

Вы должны увидеть файл с именем `faceform_bot.conf` или похожим.

3. Если вы нашли этот файл, проверьте его содержимое:

```bash
sudo cat /etc/supervisor/conf.d/faceform_bot.conf
```

Файл должен содержать информацию о запуске бота с правильными путями.

## Настройка если файла нет или нужно обновить

1. Скопируйте файл конфигурации в нужную директорию:

```bash
sudo cp ~/faceform/faceform_bot_export/faceform_bot_supervisor.conf /etc/supervisor/conf.d/faceform_bot.conf
```

2. Обновите конфигурацию supervisor:

```bash
sudo supervisorctl reread
sudo supervisorctl update
```

3. Перезапустите программу:

```bash
sudo supervisorctl restart faceform_bot
```

## Проверка логов

1. Проверьте логи supervisor:

```bash
sudo supervisorctl tail -f faceform_bot
```

2. Или проверьте непосредственно файлы логов (в зависимости от настройки путей в конфигурации):

```bash
# Если пути указаны как в faceform_bot_supervisor.conf
tail -f ~/faceform_bot/logs/stdout.log
tail -f ~/faceform_bot/logs/stderr.log

# Или если используется другой путь
sudo tail -f /var/log/faceform_bot/stdout.log
sudo tail -f /var/log/faceform_bot/stderr.log
```

## Проверка переменных окружения

1. Убедитесь, что файл `.env` содержит правильный токен API:

```bash
cat ~/faceform/faceform_bot_export/.env
```

Убедитесь, что переменная `TELEGRAM_API_TOKEN` настроена правильно.

2. Если файла нет или вам нужно его обновить, создайте его:

```bash
nano ~/faceform/faceform_bot_export/.env
```

Добавьте следующую строку:
```
TELEGRAM_API_TOKEN=8099204689:AAGXF_Y-GXxlsOR-WcT9aYZV781pj_NOTFY
```

## Ручной запуск для проверки

Если вы хотите запустить бота вручную для проверки:

```bash
cd ~/faceform/faceform_bot_export
python run_vps.py
```

Это запустит бота в интерактивном режиме, и вы сможете увидеть все ошибки на экране.