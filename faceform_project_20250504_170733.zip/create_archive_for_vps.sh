#!/bin/bash
# Script to create a complete archive of the FaceForm project for VPS installation
# Created: April 29, 2025

# Color definitions for better output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}===== Creating Archive of FaceForm Project for VPS Installation =====${NC}"

# Create output directory if it doesn't exist
OUTPUT_DIR="."
ARCHIVE_NAME="faceform_vps_project.tar.gz"
FULL_PATH="$OUTPUT_DIR/$ARCHIVE_NAME"

echo -e "${YELLOW}Creating archive at: ${FULL_PATH}${NC}"

# List of essential files and directories to include
# Edit this list to include all needed files
INCLUDE_FILES=(
    "*.py"                # All Python files in root dir
    "app.py"              # Main application file
    "main.py"             # Entry point
    "bot.py"              # Telegram bot
    "db.py"               # Database configuration
    "models.py"           # Database models
    "auth.py"             # Authentication
    "config.py"           # Configuration
    "payments.py"         # Payment processing
    "translations.py"     # Translations
    "templates/"          # HTML templates
    "static/"             # Static files (CSS, JS, images)
    "routes/"             # Route modules
    "requirements.txt"    # Dependencies
    ".env.example"        # Example environment file
    "run_bot.py"          # Bot runner
    "README.md"           # Documentation
    "flask_session/"      # Session storage (empty dir)
)

# Create a temporary directory for the archive
TEMP_DIR=$(mktemp -d)
echo -e "${YELLOW}Created temporary directory: ${TEMP_DIR}${NC}"

# Copy the required files to the temp directory
echo -e "${YELLOW}Copying files...${NC}"
for file in "${INCLUDE_FILES[@]}"; do
    # Make sure the target directory exists
    if [[ "$file" == */ ]]; then
        mkdir -p "${TEMP_DIR}/${file}"
    fi
    
    # Copy files
    cp -r --parents "$file" "$TEMP_DIR" 2>/dev/null || true
done

# Generate requirements.txt if it doesn't exist
if [ ! -f "requirements.txt" ]; then
    echo -e "${YELLOW}Creating requirements.txt...${NC}"
    cat > "${TEMP_DIR}/requirements.txt" << EOF
flask==2.3.3
flask-sqlalchemy==3.1.1
flask-login==0.6.2
flask-wtf==1.1.1
flask-session==0.5.0
email-validator==2.0.0
gunicorn==23.0.0
werkzeug==2.3.7
python-dotenv==1.0.0
psycopg2-binary==2.9.7
opencv-python==4.8.0.76
numpy==1.25.2
mediapipe==0.10.7
stripe==8.0.0
pytelegrambotapi==4.14.0
pillow==10.0.1
matplotlib==3.8.0
requests==2.31.0
sqlalchemy==2.0.21
EOF
fi

# Create an empty .env.example file if it doesn't exist
if [ ! -f ".env.example" ]; then
    echo -e "${YELLOW}Creating .env.example...${NC}"
    cat > "${TEMP_DIR}/.env.example" << EOF
# Database Configuration
DATABASE_URL=postgresql://username:password@localhost:5432/faceform
PGUSER=faceform_user
PGPASSWORD=your_password
PGHOST=localhost
PGPORT=5432
PGDATABASE=faceform

# Flask Configuration
SECRET_KEY=your_secret_key
FLASK_SECRET_KEY=your_flask_secret_key
SESSION_SECRET=your_session_secret

# Stripe Configuration
STRIPE_PUBLIC_KEY=pk_test_your_key
STRIPE_SECRET_KEY=sk_test_your_key

# Bot Configuration
TELEGRAM_BOT_TOKEN=your_telegram_bot_token
TELEGRAM_WEBHOOK_URL=https://your-domain.com/webhook

# LightX API Keys
LIGHTX_API_KEY=your_lightx_api_key

# Server Configuration
PORT=5000
FLASK_ENV=production
EOF
fi

# Create flask_session directory if it doesn't exist
mkdir -p "${TEMP_DIR}/flask_session"

# Create basic README if it doesn't exist
if [ ! -f "README.md" ]; then
    echo -e "${YELLOW}Creating README.md...${NC}"
    cat > "${TEMP_DIR}/README.md" << EOF
# FaceForm

FaceForm is an AI-powered face analysis platform with both Telegram bot and web interface.

## Features
- Face shape analysis
- Hairstyle recommendations
- Virtual hairstyle try-on
- Background removal
- Beauty analysis
- Video face analysis

## Installation
See the setup_faceform_vps.sh script for VPS installation.

## Configuration
Edit the .env file with your API keys and database credentials.

## License
All rights reserved. Unauthorized use, reproduction, or distribution is prohibited.
EOF
fi

# Create the archive
echo -e "${YELLOW}Creating archive...${NC}"
cd "$TEMP_DIR"
tar -czf "$FULL_PATH" .
cd - > /dev/null

# Calculate size in MB
SIZE=$(du -m "$FULL_PATH" | cut -f1)

# Clean up
rm -rf "$TEMP_DIR"

echo -e "${GREEN}✓ Archive successfully created at: ${FULL_PATH} (${SIZE} MB)${NC}"
echo -e "${GREEN}✓ Use this archive with setup_faceform_vps.sh to install on your VPS${NC}"
echo -e "${GREEN}✓ Choose option 3 (Use a local archive) during the setup process${NC}"