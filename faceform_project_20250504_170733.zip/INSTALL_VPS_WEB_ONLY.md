# Установка FaceForm Web на VPS (только веб-сайт)

Данная инструкция предназначена для установки только веб-интерфейса FaceForm на VPS сервер, без настройки Telegram бота.

## Системные требования

Для корректной работы FaceForm Web требуется:
- Ubuntu 20.04 или новее
- Минимум 2 ГБ оперативной памяти
- Минимум 10 ГБ дискового пространства
- Доступ к серверу по SSH с правами root
- Домен (опционально, но рекомендуется для SSL)

## Шаг 1: Подготовка файлов

Прежде всего, вам потребуется загрузить на VPS:
1. **faceform_vps_project.tar.gz** - архив проекта
2. **setup_faceform_vps.sh** - скрипт установки

Вы можете загрузить эти файлы на сервер с помощью SCP:

```bash
scp faceform_vps_project.tar.gz setup_faceform_vps.sh пользователь@ваш-сервер:/home/пользователь/
```

## Шаг 2: Установка базовых компонентов

1. Подключитесь к серверу по SSH:
   ```bash
   ssh пользователь@ваш-сервер
   ```

2. Обновите систему:
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

3. Установите необходимые пакеты:
   ```bash
   sudo apt install -y python3 python3-pip python3-dev python3-venv \
       build-essential libpq-dev nginx curl wget git \
       libsm6 libxext6 libxrender-dev libfontconfig1
   ```

## Шаг 3: Запуск скрипта установки

1. Сделайте скрипт установки исполняемым:
   ```bash
   chmod +x setup_faceform_vps.sh
   ```

2. Запустите скрипт:
   ```bash
   sudo ./setup_faceform_vps.sh
   ```

3. Во время установки:
   - Выберите директорию для установки (по умолчанию: `/opt/faceform`)
   - При выборе источника проекта, выберите опцию 3 "Use a local archive"
   - Укажите путь к файлу `faceform_vps_project.tar.gz`
   - Выберите настройку Nginx, если нужен веб-сервер
   - Укажите ваш домен, если он есть
   - Выберите настройку SSL, если нужно
   - **Важно**: Когда скрипт спросит о настройке Telegram-бота, ответьте "n" (нет)

## Шаг 4: Настройка переменных окружения

Создайте или отредактируйте файл .env с минимальными настройками для веб-сайта:

```bash
sudo nano /opt/faceform/.env
```

Добавьте/отредактируйте следующие параметры:

```
# Database Configuration
DATABASE_URL=postgresql://faceform_user:ваш_пароль@localhost:5432/faceform
PGUSER=faceform_user
PGPASSWORD=ваш_пароль
PGHOST=localhost
PGPORT=5432
PGDATABASE=faceform

# Flask Configuration
SECRET_KEY=ваш_секретный_ключ
FLASK_SECRET_KEY=ваш_flask_секретный_ключ
SESSION_SECRET=ваш_session_секретный_ключ

# Stripe Configuration (если используется)
STRIPE_PUBLIC_KEY=ваш_stripe_public_key
STRIPE_SECRET_KEY=ваш_stripe_secret_key

# LightX API Keys (если используются)
LIGHTX_API_KEY=ваш_lightx_api_key

# Server Configuration
PORT=5000
FLASK_ENV=production
```

## Шаг 5: Запуск веб-сервера

Перезапустите службу для применения изменений:

```bash
sudo systemctl restart faceform
```

## Шаг 6: Проверка установки

1. Проверьте статус службы:
   ```bash
   sudo systemctl status faceform
   ```

2. Проверьте журналы на наличие ошибок:
   ```bash
   sudo journalctl -u faceform -n 50
   ```

3. Откройте сайт:
   - Если вы настроили Nginx с доменом: https://ваш-домен.com
   - Если вы используете только IP: http://ваш-ip-адрес:5000

## Устранение неполадок

### Ошибки базы данных

Если вы видите ошибки, связанные с базой данных:

1. Проверьте статус PostgreSQL:
   ```bash
   sudo systemctl status postgresql
   ```

2. Убедитесь, что параметры подключения в `.env` корректны

3. Проверьте создание базы данных:
   ```bash
   sudo -u postgres psql -c "\l" | grep faceform
   ```

### Ошибки доступа к файлам

Если возникают ошибки с правами доступа:

```bash
sudo chown -R www-data:www-data /opt/faceform
sudo chmod -R 755 /opt/faceform
sudo chmod 644 /opt/faceform/.env
```

### Проблемы с Nginx

Если сайт не открывается:

1. Проверьте конфигурацию Nginx:
   ```bash
   sudo nginx -t
   ```

2. Проверьте статус Nginx:
   ```bash
   sudo systemctl status nginx
   ```

3. Проверьте журналы Nginx:
   ```bash
   sudo tail -f /var/log/nginx/error.log
   ```

## Обслуживание

### Резервное копирование

Настройте автоматическое резервное копирование базы данных:

1. Создайте скрипт резервного копирования:
   ```bash
   sudo nano /opt/faceform/backup_db.sh
   ```

2. Добавьте следующий код:
   ```bash
   #!/bin/bash
   TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
   BACKUP_DIR="/opt/faceform/backups"
   mkdir -p $BACKUP_DIR
   
   # Backup the database
   pg_dump -U faceform_user -h localhost faceform > $BACKUP_DIR/faceform_$TIMESTAMP.sql
   
   # Compress the backup
   gzip $BACKUP_DIR/faceform_$TIMESTAMP.sql
   
   # Keep only the last 7 backups
   ls -t $BACKUP_DIR/faceform_*.sql.gz | tail -n +8 | xargs -r rm
   ```

3. Сделайте скрипт исполняемым:
   ```bash
   sudo chmod +x /opt/faceform/backup_db.sh
   ```

4. Добавьте его в cron:
   ```bash
   sudo crontab -e
   ```
   
5. Добавьте строку для запуска ежедневно в 3 часа ночи:
   ```
   0 3 * * * /opt/faceform/backup_db.sh
   ```

## Обновление сайта

Для обновления сайта в будущем:

1. Создайте новый архив проекта и загрузите его на VPS
2. Сделайте резервную копию текущей установки:
   ```bash
   sudo cp -r /opt/faceform /opt/faceform_backup_$(date +"%Y%m%d")
   ```
3. Распакуйте новую версию:
   ```bash
   sudo tar -xzf новый_архив.tar.gz -C /tmp/faceform_update
   sudo cp -r /tmp/faceform_update/* /opt/faceform/
   ```
4. Перезапустите службу:
   ```bash
   sudo systemctl restart faceform
   ```

## Завершение

После выполнения всех шагов, ваш FaceForm Web должен быть доступен через веб-браузер. Если у вас возникли проблемы в процессе установки, обратитесь к подробным журналам или свяжитесь с поддержкой.