#!/usr/bin/env python3
import os
import sys
import logging
import telebot
import time

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)

# Пути
current_dir = os.path.dirname(os.path.abspath(__file__))
logger.info(f"Текущая директория: {current_dir}")

# Импортируем модули
try:
    sys.path.insert(0, current_dir)
    from bot import FaceShapeBot
    logger.info("Бот успешно импортирован")
except Exception as e:
    logger.error(f"Ошибка импорта бота: {e}")
    import traceback
    logger.error(traceback.format_exc())
    sys.exit(1)

# Читаем токен бота
token = None
env_path = os.path.join(current_dir, '.env')
try:
    if os.path.exists(env_path):
        with open(env_path, 'r') as f:
            for line in f:
                if line.startswith('BOT_TOKEN='):
                    token = line.strip().split('=', 1)[1].strip('\'"')
                    break
except Exception as e:
    logger.error(f"Ошибка чтения .env файла: {e}")

if not token:
    logger.error("Токен бота не найден в .env файле")
    sys.exit(1)

# Удаляем вебхук перед запуском
try:
    logger.info("Удаляем вебхук...")
    bot = telebot.TeleBot(token)
    bot.delete_webhook()
    logger.info("Вебхук успешно удален")
    time.sleep(1)  # Даем время на обработку запроса API
except Exception as e:
    logger.error(f"Ошибка удаления вебхука: {e}")
    logger.info("Продолжаем запуск...")

# Запускаем бота
try:
    logger.info("Создаем экземпляр FaceShapeBot...")
    bot_instance = FaceShapeBot(use_webhook=False)
    
    # Регистрируем обработчик команды /video
    @bot_instance.bot.message_handler(commands=['video'])
    def handle_video_command(message):
        logger.info(f"Получена команда /video от пользователя {message.from_user.id}")
        # Проверяем наличие метода video_command
        if hasattr(bot_instance, 'video_command'):
            bot_instance.video_command(message)
        elif hasattr(bot_instance, 'process_video'):
            bot_instance.process_video(message)
        else:
            # Если метод не найден, отправляем сообщение пользователю
            bot_instance.bot.send_message(
                message.chat.id, 
                "Функция анализа видео временно недоступна. Пожалуйста, попробуйте позже."
            )
    
    logger.info("Регистрация обработчика команды /video выполнена успешно")
    logger.info("Запускаем бота в режиме polling...")
    bot_instance.run()
except Exception as e:
    logger.error(f"Ошибка запуска бота: {e}")
    import traceback
    logger.error(traceback.format_exc())
    sys.exit(1)