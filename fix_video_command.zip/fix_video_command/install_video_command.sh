#!/bin/bash

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}Установка команды /video в Telegram бот...${NC}"

# Переходим в директорию бота
cd ~/faceform_bot

# Останавливаем текущий процесс бота
echo -e "${YELLOW}Останавливаем текущий процесс бота...${NC}"
sudo supervisorctl stop faceform_bot_polling

# Копируем скрипт запуска
echo -e "${YELLOW}Копируем скрипт запуска run_polling.py...${NC}"
cp run_polling.py run_polling.py.bak 2>/dev/null
wget -q https://replit.com/run_polling.py -O run_polling.py

# Делаем скрипт исполняемым
chmod +x run_polling.py

# Копируем конфигурацию supervisor
echo -e "${YELLOW}Обновляем конфигурацию supervisor...${NC}"
sudo wget -q https://replit.com/faceform_bot.conf -O /etc/supervisor/conf.d/faceform_bot_polling.conf

# Перезагружаем конфигурацию supervisor
echo -e "${YELLOW}Перезагружаем конфигурацию supervisor...${NC}"
sudo supervisorctl reread
sudo supervisorctl update

# Запускаем бота
echo -e "${YELLOW}Запускаем бота...${NC}"
sudo supervisorctl start faceform_bot_polling

# Ждем запуска бота
echo -e "${YELLOW}Ждем запуска бота...${NC}"
sleep 5

# Проверяем статус бота
STATUS=$(sudo supervisorctl status faceform_bot_polling)
echo -e "${GREEN}Статус бота: ${STATUS}${NC}"

if [[ $STATUS == *"RUNNING"* ]]; then
    echo -e "${GREEN}Бот успешно запущен!${NC}"
    echo -e "${GREEN}Команда /video теперь должна работать в вашем Telegram боте.${NC}"
else
    echo -e "${RED}Возникли проблемы при запуске бота.${NC}"
    echo -e "${YELLOW}Проверяем логи:${NC}"
    sudo tail -n 20 /var/log/faceform_bot/stderr.log
fi

echo -e "${GREEN}Установка завершена!${NC}"
echo -e "${YELLOW}Для просмотра логов используйте:${NC}"
echo -e "${YELLOW}sudo tail -f /var/log/faceform_bot/stderr.log${NC}"