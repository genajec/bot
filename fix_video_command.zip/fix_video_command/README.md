# Инструкция по настройке команды /video в Telegram боте

## Обзор
Данный архив содержит файлы для добавления и настройки команды `/video` в Telegram боте FaceForm. Команда `/video` позволяет пользователям отправлять видео для анализа формы лица.

## Содержимое архива
- `run_polling.py` - Скрипт для запуска бота в режиме polling с поддержкой команды /video
- `faceform_bot.conf` - Файл конфигурации для supervisor
- `install_video_command.sh` - Скрипт для автоматической установки и настройки
- `README.md` - Данная инструкция

## Важная информация
В файле `bot.py` уже присутствует метод `video_command` и обработчик команды `/video`, поэтому нам нужно только настроить правильный запуск бота в режиме polling.

## Метод 1: Автоматическая установка

1. Загрузите архив на VPS сервер
2. Распакуйте архив:
   ```
   unzip fix_video_command.zip
   ```
3. Перейдите в директорию с распакованными файлами:
   ```
   cd fix_video_command
   ```
4. Сделайте установочный скрипт исполняемым:
   ```
   chmod +x install_video_command.sh
   ```
5. Запустите скрипт установки:
   ```
   ./install_video_command.sh
   ```
6. Проверьте статус бота:
   ```
   sudo supervisorctl status faceform_bot_polling
   ```

## Метод 2: Ручная установка

1. Скопируйте файл `run_polling.py` в директорию бота:
   ```
   cp run_polling.py ~/faceform_bot/
   ```
2. Сделайте скрипт исполняемым:
   ```
   chmod +x ~/faceform_bot/run_polling.py
   ```
3. Остановите текущий процесс бота:
   ```
   sudo supervisorctl stop faceform_bot_polling
   ```
4. Скопируйте файл конфигурации supervisor:
   ```
   sudo cp faceform_bot.conf /etc/supervisor/conf.d/faceform_bot_polling.conf
   ```
5. Перезагрузите конфигурацию supervisor:
   ```
   sudo supervisorctl reread
   sudo supervisorctl update
   ```
6. Запустите бота:
   ```
   sudo supervisorctl start faceform_bot_polling
   ```

## Проверка работы
После установки отправьте команду `/video` в вашем Telegram боте. Бот должен ответить с инструкциями по отправке видео для анализа.

## Решение проблем
Если возникли проблемы:
1. Проверьте логи бота:
   ```
   sudo tail -f /var/log/faceform_bot/stderr.log
   ```
2. Убедитесь, что файл `.env` содержит корректный токен бота
3. Проверьте права доступа к файлам в директории бота

## Поддержка
Если у вас возникли проблемы с установкой, обратитесь за поддержкой.