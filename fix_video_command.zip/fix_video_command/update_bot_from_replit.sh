#!/bin/bash

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}Обновление бота с новым файлом bot.py из архива...${NC}"

# Проверка аргументов
if [ "$#" -ne 1 ]; then
    echo -e "${RED}Ошибка: Необходимо указать путь к архиву с новой версией бота${NC}"
    echo -e "Использование: $0 /path/to/archive.zip"
    exit 1
fi

ARCHIVE_PATH="$1"

# Проверка существования архива
if [ ! -f "$ARCHIVE_PATH" ]; then
    echo -e "${RED}Ошибка: Архив $ARCHIVE_PATH не найден${NC}"
    exit 1
fi

# Определение временной директории
TEMP_DIR=$(mktemp -d)
echo -e "${YELLOW}Создана временная директория: $TEMP_DIR${NC}"

# Распаковка архива
echo -e "${YELLOW}Распаковка архива $ARCHIVE_PATH...${NC}"
unzip -q "$ARCHIVE_PATH" -d "$TEMP_DIR"

# Проверка наличия файла bot.py в архиве
if [ ! -f "$TEMP_DIR/bot.py" ]; then
    echo -e "${RED}Ошибка: Файл bot.py не найден в архиве${NC}"
    rm -rf "$TEMP_DIR"
    exit 1
fi

# Остановка текущего процесса бота
echo -e "${YELLOW}Останавливаем бота...${NC}"
sudo supervisorctl stop faceform_bot_polling

# Создание резервной копии текущего bot.py
echo -e "${YELLOW}Создание резервной копии текущего bot.py...${NC}"
cd ~/faceform_bot
if [ -f "bot.py" ]; then
    cp bot.py bot.py.backup_$(date +%Y%m%d_%H%M%S)
    echo -e "${GREEN}Резервная копия создана${NC}"
fi

# Копирование нового bot.py
echo -e "${YELLOW}Копирование нового bot.py...${NC}"
cp "$TEMP_DIR/bot.py" ~/faceform_bot/bot.py
echo -e "${GREEN}Новый bot.py успешно скопирован${NC}"

# Перезапуск бота
echo -e "${YELLOW}Перезапуск бота...${NC}"
sudo supervisorctl start faceform_bot_polling

# Проверка статуса бота
sleep 5
STATUS=$(sudo supervisorctl status faceform_bot_polling)
echo -e "${GREEN}Статус бота: ${STATUS}${NC}"

# Удаление временной директории
echo -e "${YELLOW}Удаление временной директории...${NC}"
rm -rf "$TEMP_DIR"

echo -e "${GREEN}Обновление завершено успешно!${NC}"
echo -e "${YELLOW}Для просмотра логов бота используйте:${NC}"
echo -e "${YELLOW}sudo tail -f /var/log/faceform_bot/stderr.log${NC}"